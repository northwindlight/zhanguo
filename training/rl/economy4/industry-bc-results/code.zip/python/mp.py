# -*- coding: utf-8 -*-
"""多国引擎（MP）。

多个国家共存于同一张地图，各自经营（规则对所有国家一致，无作弊入口）：
  - 每国独立 国库(黄金)/战略储备/电网(不存储)/军队/国土/信箱；
  - 无人地带的视野内地块由「野人」把守，打赢即拓疆；国家间打赢即夺地，
    空城被敌军队踏入即陷（无防即失）；
  - 移动/攻击受国家关系约束：中立（非同盟非交战）不能入境、不能攻击；
  - 外交：联盟(起名结盟·全体创始成员同意·单方面退盟·共享视野·成员间外交免费·
    进攻战争须投票·议和由盟主投票·同战线自动归还核心领土)/保障独立/共同防御/
    宣战(对方必须接受，其**直接**保障国/直接共同防御伙伴自动参战——一对实体只走一跳；
         唯一不限跳数的是联盟：打盟员=全盟一起上)/求和(可赔款/索款/白和)；
  - 信箱：任何内容，下回合到信。
  - 看海：world.history 记下每个行动/每封信/每场战/每桩外交，Observer 全可见；
    各国 agent 只见「自己该知道」的（自己的面板/信箱/视野内事件）。

坐标 0-based；对外（面板/tool 入参）用 1-based。
"""

from __future__ import annotations

import copy
import json
import math
import random
from pathlib import Path

from game import (
    letter_cost,
    ARMY_HEAL_PER_TURN,
    BANK_LOAN_GDP_MULT,
    BANK_LOAN_TURNS,
    BANK_RATE_MAX,
    BANK_RATE_MIN,
    BANK_SPREAD,
    ARMY_MAX_HP,
    ARMY_STARVE_DAMAGE,
    BUILDINGS,
    building_effect,
    COMBAT_DIE_MOD,
    DIPLO_CENTER_MIN_COST,
    MARKET,
    MARKET_DEPTH,
    MARKET_ELASTICITY,
    MARKET_FLOW,
    MARKET_MAX_PRICE,
    MARKET_MIN_PRICE,
    MARKET_REFILL,
    MARKET_SPREAD,
    MAX_SLOTS,
    RETREAT_ATK_PENALTY,
    RETREAT_RANGE,
    TERRAIN_CHARS,
    TERRAIN_STATS,
    TRADEABLE,
    UNIT_TYPES,
    army_name,
    unit_atk,
    unit_kind,
    unit_max_hp,
    unit_move_cost,
    unit_speed,
    unit_supply,
)
# 屏障地形（不可通行/占领/建造）——地图算法与移动/落点共用这一份口径
from balance import BARRIER_TERRAINS

# 数值表在 balance.py（**唯一调参入口**）；这里原样转口，`mp.X` 的老引用照旧。
from balance import (
    ARRIVE_ATTEMPTS,
    ARRIVE_MARGIN_DIV,
    ARRIVE_MARGIN_MIN,
    BLOC_NAME_MAX,
    BUY_REPORT_COST,
    DIPLO_COST,
    EXTRA_PROMPT_TURNS,
    FALL_TRUCE_TURNS,
    HUNS_RING_RATIO,
    MOVE_COST,
    PLAN_MAX_TURNS,
    POLITY,
    REPORT_EVERY,
    RES_KEYS,
    RES_LABEL,
    RETREAT_DEF_COVER,
    SPY_COST,
    SPY_TURNS,
    START_RES,
    SUMMARY_MIN_CHARS,
    ACADEMY_AMORT_TURNS,
    TOWNHALL_SLOT_BONUS,
)


CROSS = [(0, 0), (0, -1), (0, 1), (-1, 0), (1, 0)]

# 引擎机制常量（非数值表，就近放在引擎里，杜绝魔法数）
ARMY_GID_BASE = 100_000_000   # 军队全局唯一 gid = 国家码 × 该值 + 序列（对 AI 不可见）
KEEP_MAPS = 3                 # 各国地图快照只留最近 N 份（控体积）
KEEP_SAVES = 2                # 间谍经济情报快照只留最近 N 份（控体积）

# 总消费（累计，按当时市价折金）——终局结算按它排名。只计「被消耗掉的资源」，
# 市场买卖/馈赠不计（买来的物资在真正被消耗时才入账），避免重复计数。
SPEND_FIELDS = ("build",    # 建造实付金 + 木×市价（含城堡升级）
                "recruit",  # 征兵消耗（粮/装备/金）× 市价
                "supply")   # 军费：军队吃掉的补给 × 市价
# 本期经济账本字段（按国累计，结完报表清零；全部按当时市价折金）
LEDGER_FIELDS = ("prod_value",      # 采集/工厂 产出 × 市价（军屯 2026-09-18 起不产，不在此列）
                 "mid_value",       # 工厂中间投入 × 市价
                 "fuel_value",      # 能源厂燃料 × 市价
                 "gold_in",         # 金矿 + 市政厅 入国库的金
                 "supply_eaten",    # 军队实际吃掉的补给（单位）——军费口径，不看来源
                 "heal_value",      # 军队回血消耗的装备 × 市价（HEAL_EQUIP_COST）
                 "import_gold",     # 市场买入总额
                 "export_gold",     # 市场卖出总额
                 "invest_gold",     # 建造实付金
                 "invest_wood_value")  # 建造耗木 × 当时市价

# ---- 存档契约：**追加式**（只加字段、不删字段）----
# 2026-09-19 政策改动（用户口径：「这个档允许追加，而不是重开，只加银行不能删硬件，
# 就是为了增量更新存档」）。此前是"版本锁死、零旧格式兼容"，现在改成：
#   · **加字段**：登记 SAVE_KEYS + 在 SAVE_DEFAULTS 给默认（save/load 各一行搬运）。
#     老档缺这个键 ⇒ **按默认补齐**，整档不作废、不用重开。⇒ **加字段不需要 bump 版本**。
#   · **不许删字段、不许改已有字段的语义**（那才需要 SAVE_VERSION +1 让旧档作废，
#     并把 SAVE_MIN_VERSION 抬到新版本）。
#   · 版本闸门：`SAVE_MIN_VERSION ≤ 档内版本 ≤ SAVE_VERSION` 才放行——
#     **比代码新的档依旧拒载**（未来格式我们读不懂），无版本号的古董档也拒。
#   · 覆盖不到的区域仍旧拒载：缺"非追加字段"（截断/手改坏）直接报错，不带病续局。
# save() 写前仍断言键集合与 SAVE_KEYS 严丝合缝——新增字段忘了登记，第一次存档就炸，
# 而不是静默丢字段（历史上"幽灵地块"就是 save/load 人肉对齐 50 键漏出来的病）。
# v2（2026-09-15）：地图生成换成蓝噪声 + 密度图调制（`mapgen.py`）。**必须**bump：
#   已物化格子的 terrain/resources 是**字面量存在档里**的，不拒载就会出现
#   "已占格=旧算法、新占格=新算法"的混图（比整档作废更糟——它不报错）。
# v3（2026-09-18）：外交主体上移到「外交实体」（独立国家 | 联盟）——保障/共同防御/
#   宣战/议和一律以实体为签约方，在盟国家不再持有个人条约。**必须**bump：旧的
#   alliances/defense_pacts/guarantees 是**国家级**的，读进来就会出现"成员国还留着
#   个人条约"这种新规则下不可能存在的状态（比整档作废更糟——它不报错）。
# v4（2026-09-19）：加「世界央行」（`bank`：开关/储蓄利率/未还贷款）。
#   ★ 按新的追加式政策，这一笔**本来不必 bump**（旧档缺 bank 就按默认补齐）；
#     留 4 只是记录"bank 是哪一版进来的"。**v2/v3 那两次是真破坏性变更**（删过字段、
#     改过语义）⇒ SAVE_MIN_VERSION 卡在 3：比它老的档不认（读进来会静默丢条约）。
SAVE_VERSION = 4
SAVE_MIN_VERSION = 3

# 追加式存档的**默认值表**：老档缺这些键时就按这里补齐（只列"追加进来的"字段）。
# 加字段时：SAVE_KEYS 登记 + 这里给默认 + save/load 各一行搬运 —— 三处齐了就不用 bump。
SAVE_DEFAULTS: dict = {
    "pacts": [],                                      # v3 起：实体级条约表
    "bank": {"on": False, "rate": 0.0, "loans": {}},  # v4 起：世界央行
    # 《开局指南》开关（mp_ai.opening_guide）。旧档缺它 → 按 True 补齐：实际无影响，
    # 因为挂载窗口是"前 EXTRA_PROMPT_TURNS 回合"，而现存老档早已远超这个回合数。
    "opening_guide": True,
    # v4 起：每回合的 GDP run-rate（央行授信按它算）。旧档缺 → 空表，
    # 由 `nation_gdp` 退回"最新一期经济报表的 GDP"，不会把授信算成 0。
    "gdp_run": {},
    # 全期累计 token 用量（**纯统计**）。旧档缺 → 空表；load 时按存档里的国家补零起步。
    # 默认必须是**空**的表，不能写成含"秦楚齐"的模板：八国档读进来会多出三个不存在的国家。
    "token_usage": {},
    # 市场找零余额（不足 1 金的小数，见 `World._settle_gold`）。旧档缺 → 空表，
    # 从头攒零钱即可：影响仅仅是"跨国界续档时那不到 1 金的零头"，不是语义变更。
    "gold_carry": {},
}
# `World.token_usage` 每国一格的字段清单。**save 与 load 共用这一份**：
# save 按它补齐国家键，load 按它重建骨架 ⇒ 两边顺序、字段名必然一致，
# 存档往返（save→load→save）才可能字节级相等（见 test_save_load_save_is_byte_identical）。
USAGE_FIELDS = ("calls", "prompt", "hit", "miss", "out", "reason", "est_calls", "real_calls")
SAVE_KEYS = ("version", "size", "seed", "turn", "rng_state", "nations", "order",
             "tiles", "armies", "next_army_seq", "diplo_built", "nation_code",
             "guard_once", "wars", "war_id", "truce", "blocs",
             "votes", "vote_id", "pacts", "bank", "mail_pending",
             "mailbox", "summaries", "summary_blocks", "long_memory", "turn_memory", "gift_pending",
             "map_pending", "maps", "spy_pending", "econ_intel", "plans", "polity",
             "extra_prompt", "opening_guide", "peace_offers", "proposals", "offer_id", "prices",
             "grid_short", "energy_report",
             "econ_summary", "econ_reports", "ledger", "spend", "gdp_run", "history",
             "history_seen", "token_usage", "gold_carry", "vassals",
                    "market_inv", "market_ref", "market_period", "market_trades", "market_volume")


class SaveFormatError(Exception):
    """存档版本/键集合不符：拒载，提示重开（不做任何回溯迁移）。"""


def _truce_key_id(x: str) -> str:
    """休战表键的规范化：裸国名 → 国家实体 id（`国:x`）；已经是实体 id 的原样返回。

    读档迁移用：2026-10-11 之前休战表按**裸国名**存，之后按**实体 id**存
    （联盟＝`盟:名字`、独立国＝`国:名字`，与条约表 `self.pacts` 同一口径）。
    """
    return x if ":" in x else ent_nation(x)


def _pair(a: str, b: str) -> frozenset:
    return frozenset((a, b))


# ---- 外交实体：本作**唯一**的对外签约主体（2026-09-18 外交改革）----
# 只有两种：**独立国家**（不在任何联盟中的国家）与**联盟**。
# 在盟的国家不是外交实体 —— 它的一切约束性外交（保障独立/共同防御/宣战/议和）
# 都由其联盟以实体身份出面，且须**联盟投票通过**。非约束动作（写信/馈赠/换图/间谍）
# 仍归国家自己（那是通信与物资，不是对外承诺）。
# 实体 id 是字符串（进存档、进日志、进面板）："国:<国名>" / "盟:<联盟名>"。
# 联盟改名时引用要整体同步 —— 见 World._rename_bloc_refs（votes 与 pacts 两处）。
ENT_NATION = "国:"
ENT_BLOC = "盟:"


def ent_nation(name: str) -> str:
    """国家实体的 id（独立国家才用它当签约方）。"""
    return ENT_NATION + name


def ent_bloc(name: str) -> str:
    """联盟实体的 id。"""
    return ENT_BLOC + name


def is_bloc_ent(ent: str) -> bool:
    return ent.startswith(ENT_BLOC)


def ent_key(ent: str) -> str:
    """去掉前缀的名字（国名或联盟名），供展示/查表。"""
    return ent[2:]


def retreat_note(defends: bool, cover: int) -> str:
    """撤退的攻/防档位文案 —— **一处定义，多处消费**（`retreat()` 的命令行回执、
    结算时三行落地日志、战斗面板上的 `⚑` 标记）。

    `defends`（是不是守方）与 `cover` 都由 `World.battle_sides` 的 `soak_elig`
    一次导出，不在各处重判。文案只陈述**事实**（这轮吃不吃减伤、输出打不打折），
    不替 AI 判断该不该撤——给事实不给判断。
    """
    if defends:
        return f"防御撤退，本回合结算减伤 {100 - cover}%"
    return "进攻撤退，本回合结算无减伤（输出 −80%）"


# ---- 游戏层 ROI 原语（原在 mp_ai._gval / _econ_building；提到这里免得规则 AI
#      反向依赖 LLM 层。LLM 面板与规则 AI v9 从此共用同一份数字，口径逐字一致，
#      与 feat/rl 的同名实现可互相 cherry-pick）----

def good_value(world: "World", good: str, amt: int, side: str = "mid") -> float:
    """把 amt 单位 good 折成金（黄金按 MARKET['黄金'] 折算）。

    side='mid' 用中间价；'buy'/'sell' 用含价差的实际成交单价（自用替代 / 外销口径）。
    """
    if amt <= 0:
        return 0.0
    if good == "黄金":
        return amt * MARKET["黄金"]
    if side in ("buy", "sell"):
        return amt * world.market_quote(good, 1, side)[0]
    p = world.prices.get(good)
    return amt * (p if p is not None else float(MARKET.get(good, 0)))


def build_econ(world: "World", building: str, tile=None) -> dict:
    """单个建筑的**数字版**经济核算（mp_ai 经济面板与规则 AI v9 共用这一份）。

    返回：
        {
          "building": 建筑名,
          "capex":    造价折金（金 + 木×现价；城堡取 L1）,
          "per_turn": 每回合净收益（金）—— 负 = 净支出,
          "payback":  capex / per_turn（per_turn ≤ 0 → None，永远回不了本）,
          "detail":   分项明细（给面板拼文案用）,
        }

    `kind == "townhall"`（市政厅）按**该格真实密度**算产出（`gold_base + 其他建筑位 × gold_per_slot`），
    与引擎 `resolve_turn` 那段逐字同式 —— 所以传 `tile` 与不传会得到不同答案（这就是"按格子效果选"）。

    ⚠️ **注意口径**：加工厂（补给厂/装备厂）的产出按"**自用替代**"（买价）计 ——
    即"这些产出替你去市场上买"。这个口径对**流量品**（补给：军队每回合都吃）成立，
    对**存量品**（装备：只在征兵时一次性消耗）会**高估** —— 你并不是每回合都去买装备。
    """
    info = BUILDINGS[building]
    wp = world.prices.get("木头", float(MARKET["木头"]))
    cost = info["cost"] if isinstance(info["cost"], int) else info["cost"][0]
    # ★ 传了地块就按**该格的实际造价**算（用户 2026-09-11：ROI 必须含地形成本）。
    #   公式与引擎 `World.build` 逐字对齐：地形施工惩罚只上浮**金价**（木材不变），
    #   工程院再减 25%（只认已落成的、且自己不享受自己的减免）。
    if tile is not None:
        t = world.tiles.get(tile)
        if t is not None:
            bp = TERRAIN_STATS[t["terrain"]]["build_penalty"]
            if bp:
                cost = cost * (100 + bp) // 100
            if t["buildings"].get("工程院") and building != "工程院":
                cost = cost * (100 - building_effect("工程院", "build_discount")) // 100
    capex = cost + info.get("wood", 0) * wp
    kind = info["kind"]
    detail: dict = {}

    if kind == "gold":
        per = sum(good_value(world, g, a) for g, a in info["outputs"].items())
        detail["net"] = per
    elif kind == "extract":
        per = sum(good_value(world, g, a, "sell") for g, a in info["outputs"].items())
        detail["net"] = per
    elif kind == "energy":
        fuel = sum(good_value(world, f, a, "buy") for f, a in info.get("fuel", {}).items())
        per = -fuel
        detail.update(fuel=fuel, energy_out=info["energy_out"])
    elif kind == "factory":
        inv = sum(good_value(world, f, a, "buy") for f, a in info.get("inputs", {}).items())
        out_buy = sum(good_value(world, g, a, "buy") for g, a in info.get("outputs", {}).items())
        out_sell = sum(good_value(world, g, a, "sell") for g, a in info.get("outputs", {}).items())
        # 电按"1 木发 2 电"的燃料成本估
        ec = info.get("energy", 0) * good_value(world, "木头", 1, "buy") / 2
        per = out_buy - inv - ec
        detail.update(inputs_value=inv, outputs_buy=out_buy, outputs_sell=out_sell,
                      energy_cost=ec, net=out_buy - inv)
    elif kind == "academy":
        # ★ 工程院（2026-09-16，用户：「工程院的收益会自然体现到 roi，自然密度建筑」＋
        #   「你只算了省的钱，没算未来更快的密度速度为市政厅赚来的钱，太短视了」）：
        #   效果 = **本格一切建造金价 −25%**。收益是**两笔，都要算**：
        #     ① **省下的钱**：每建一座省 `disc × 该座金价`（用本格已建楼的平均造价现读
        #        —— 采集楼 45~70、工厂/兵营/市政厅 175~500，越密越贵的格省得越多）；
        #     ② **密度红利（市政厅联动）**：楼便宜 ⇒ 这一格填得更快更满 ⇒ 本格市政厅的产出
        #        `gold_base + 本格其他建筑位 × gold_per_slot` 跟着涨 ——
        #        省下的钱折成"多买几座楼"，每多一座楼 ⇒ 厅**每回合**多 `gold_per_slot` 金
        #        （`disc × 本格建筑位 × gold_per_slot`）。本格还没厅但**够格建**时也算：
        #        那是"厅会来"。
        #   一次性那笔（①）按 `ACADEMY_AMORT_TURNS` 摊成每回合；②本来就是每回合的钱。
        disc = building_effect(building, "build_discount") / 100.0
        tt = world.tiles.get(tile) if tile is not None else None
        n_used = 0
        c_avg = 0.0
        hall_ok = False
        if tt is not None:
            n_used = sum(tt["buildings"].values())          # 不含它自己（还没建）
            costs = [BUILDINGS[b_]["cost"] if isinstance(BUILDINGS[b_]["cost"], int)
                     else BUILDINGS[b_]["cost"][0]
                     for b_, c_ in tt["buildings"].items() for _ in range(c_)]
            c_avg = (sum(costs) / len(costs)) if costs else 0.0
            hall_ok = bool(tt["buildings"].get("市政厅")) or n_used >= (
                BUILDINGS["市政厅"].get("min_slots") or 10 ** 6)
        saved = (disc * n_used * c_avg) / ACADEMY_AMORT_TURNS if c_avg else 0.0
        density_gain = (disc * n_used * building_effect("市政厅", "gold_per_slot")
                        if hall_ok else 0.0)
        per = saved + density_gain
        detail.update(discounts=disc, avg_cost=c_avg, per_turn_saved=saved,
                      per_turn_density=density_gain, hall_ok=hall_ok)
    elif kind == "townhall":
        # ★ 2026-09-16（用户）：「应该走正常的 roi 机制……有市政厅的 roi 自动高」：
        #   市政厅的产出是**该格真实密度**的函数 —— 引擎 `resolve_turn` 每回合给它
        #   `gold_base + 本格其他建筑位 × gold_per_slot` 金（见上面那段"市政厅：每座 =…"）。
        #   原先这里把它和兵营/城堡一起归到 `per = 0.0` ⇒ 回本 None ⇒ **任何按回本排序的
        #   地方都看不见它**（经济层的 ROI 榜、面板都看不见）⇒ 两代规则 AI 从未建过它。
        #   这里按**传进来的那一格**算真值：密度越高的格，回本越快、ROI 自动越高。
        base = building_effect(building, "gold_base")
        per_slot = building_effect(building, "gold_per_slot")
        tt = world.tiles.get(tile) if tile is not None else None
        others = sum(tt["buildings"].values()) if tt is not None else 1   # 不含它自己（还没建）
        others += TOWNHALL_SLOT_BONUS      # ★ 稍微乐观：那一格还会继续堆（用户 2026-09-16：+2~3）
        per = base + others * per_slot
        if info.get("energy"):
            per -= info["energy"] * good_value(world, "木头", 1, "buy") / 2   # 与工厂同款电耗估法
        detail.update(gold_base=base, gold_per_slot=per_slot, other_slots=others)
    else:                                   # castle / barracks / tower：不产出，回本无定义
        per = 0.0

    return {"building": building, "capex": capex, "per_turn": per,
            "payback": (capex / per) if per > 0 else None,
            "cost": cost, "wood": info.get("wood", 0), "wood_price": wp,
            "detail": detail}


_ADJ_CACHE: dict[int, tuple] = {}


def _adjacency(size: int) -> tuple:
    """每格的邻居（**整数下标** = `x * size + y`）：只与地图边长有关，按边长建一次全家共用。

    与 `World.neighbors` **同序**（`dx` 外层、`dy` 内层）。为什么要有它：`_reachable`
    每支军每回合都要跑，而旧内层每弹一格都要现建一个邻居列表。这张表是**纯几何**的
    （与局面无关），所以不存在"缓存陈旧"这个问题。`ruleai` 的代价场有一张同款的。
    """
    got = _ADJ_CACHE.get(size)
    if got is None:
        rows = []
        for x in range(size):
            for y in range(size):
                rows.append(tuple(
                    x2 * size + y2
                    for x2 in (x - 1, x, x + 1) for y2 in (y - 1, y, y + 1)
                    if (x2 != x or y2 != y) and 0 <= x2 < size and 0 <= y2 < size))
        got = tuple(rows)
        _ADJ_CACHE[size] = got
    return got


class World:
    def __init__(self, size: int = 80, seed: int | None = None, *,
                 nations: list[str] | None = None,
                 starts: dict[str, tuple[int, int]] | None = None,
                 res: dict[str, dict[str, int]] | None = None,
                 gen: bool = True,
                 max_turns: int = 200):
        self.size = size
        self.seed = seed if seed is not None else random.randrange(1 << 31)
        self.rng = random.Random(self.seed)
        self.turn = 0
        # ★**本局总回合数**（用户 2026-09-15：「v10 起，不设默认视野，恒等于回合数加 20」）。
        #   规则 AI 的规划窗口（`left = 视野 − world.turn`）从这里推，**不再有自己的
        #   `HORIZON` 常量** —— 那个常量必须由外部 `set_horizon()` 覆盖才对准，而
        #   "设了但没设上"是这个项目反复栽的坑（2026-09-15 一次：v11/v12 全程按 200 规划）。
        #   ⇒ 口径唯一：**视野 = `max_turns + 20`**。跑局的人只需把本局长度放进来
        #   （`mp_run` 按 `--turns`/配置设；`feat/rl` 分支的 `rl/env.py` 按 `max_turns` 设）。
        #   缺省 200 是**这场游戏的缺省长度**（与 `mp_config` 的 `max_turns` 同值），
        #   不是"缺省视野"。
        self.max_turns = int(max_turns)
        self._mapgen = None          # 整张图的生成器（惰性，见 mapgen 属性）
        self.tiles: dict[tuple[int, int], dict] = {}
        self.nations: dict[str, "Nation"] = {}
        self.order: list[str] = []
        self.wars: list[dict] = []  # 战争冲突：{id, atk(进攻主导), def(防御主导), followers(跟随方), turn}
        self._war_id = 0   # 计数器先自增再取值 → 首个 id 为 1
        self.truce: dict[frozenset, int] = {}  # 休战期：边→ 生效至第 N 回合（含），期内不得再宣战
        # 联盟 = {name 联盟名, chief 盟主(发起方，可移交), members 成员(加入序), turn 创立回合}
        self.blocs: list[dict] = []
        # 联盟投票：{id, kind: 宣战|议和|入盟|缔约, bloc, proposer, payload, votes{国:bool}, turn}
        self.votes: list[dict] = []
        self._vote_id = 0  # 同上：首个投票 id 为 1
        # 条约表：保障（单向）/ 共同防御（对称）。**签约方一律是外交实体**（见 ent_* 助手）：
        #   条目 = {kind: "保障"|"共同防御", a: 实体id, b: 实体id, turn: 缔结回合}
        #   共同防御按 id 排序只存一条；保障按方向存（a 保障 b）。
        # 旧的「双边同盟」alliances 与**国家级**的 defense_pacts/guarantees 已随 v3 退休：
        #   国家不再是签约主体，成员手里不可能存在个人条约（入盟即作废）。
        self.pacts: list[dict] = []
        # 世界央行（2026-09-19）：**默认关**（`mp_config.json` 的 world_bank 打开才生效）。
        #   on   —— 开关
        #   rate —— 储蓄利率（观察者设，可为负；负则每回合按现金扣钱，**扣到 0 为止**）
        #   loans —— {国名: {principal, due, turns_left, taken_turn, rate}}，一国同时只有一笔
        # 开了之后：国库现金默认就是储蓄（不用存）；贷款利率 = rate + BANK_SPREAD。
        self.bank: dict = {"on": False, "rate": 0.0, "loans": {}}
        self.mail_pending: list[dict] = []
        self.mailbox: dict[str, list[dict]] = {}
        self.summaries: dict[str, list[dict]] = {}  # 各国回合小结纪事 [{turn,text}]（私有，本国 AI 记忆；全留，供旧回合汇总）
        self.summary_blocks: dict[str, list[dict]] = {}  # 各国阶段块总结 [{from,to,text,turn}]（滑出 replay 的回合经 LLM 压成一段，覆盖其小结）
        self.long_memory: dict[str, str] = {}     # 各国递归累积的长期记忆（酒馆式：压缩时以旧记忆为基础扩写，承载长程规划/盟约/教训）
        self.turn_memory: dict[str, list[dict]] = {}  # 各国完整回合记录（含思考 reasoning_content），按 ctx_window 预算动态保留最近若干回合
        self.gift_pending: list[dict] = []         # 馈赠在途（下回合到账）
        self.map_pending: list[dict] = []          # 交换地图在途（下回合到账）
        self.maps: dict[str, list[dict]] = {}      # 各国收到的地图情报（{from,turn,text}，留最近3张）
        self.spy_pending: list[dict] = []          # 间谍在途（3回合后回报）
        self.econ_intel: dict[str, list[dict]] = {}  # 各国收到的间谍情报（{from,turn,text}，留最近2份）
        self.plans: dict[str, dict] = {}           # 各国国策规划 {text, turn}——常驻上下文，每10回合须修订
        self.polity: dict[str, str] = {}           # 政体标记（"huns"=匈奴）→ 造价/征召/外交限制
        # 附庸（main 2026-11）：{subject: {"overlord": x, "kind": "ordinary"|"tributary",
        #   "tribute_percent": 15|10}}。普通附庸并入宗主外交实体、无独立外交权、
        #   上贡实际产出；唯一脱离途径是 independence_war。禁止成环/双层。
        self.vassals: dict[str, dict] = {}
        self.diplo_pending: list[dict] = []     # 本回合已提交、外交结算时统一生效的命令
        self.diplo_approved: list[dict] = []    # 联盟已表决通过、待外交结算执行的议案
        self._diplo_cmd_id = 0
        self._diplo_now = False                 # True=立即执行（外交结算中/干跑校验中）
        self._tribute_out: dict = {}               # 本回合扣下、待生产结束后划给宗主的贡品
        self.auto_rules: dict[str, dict[str, dict]] = {}   # 自动交易：{国: {商品: 规则}}
        self.auto_runs: dict[str, dict] = {}               # 各国最近一次自动交易执行（防同期重复）
        self._reval: list = []                     # 本回合待按收盘价重估的流量记账
        self.tribute_carry: dict[str, int] = {}   # 上贡小数余额（1/100 单位，跨期结转）
        self.extra_prompt: dict[str, dict] = {}    # 临时注入的额外上下文 {text, until}——塞入正常 system_prompt，until 后自动消失
        # 《开局指南》：前 EXTRA_PROMPT_TURNS 回合由 system_prompt 强行挂给**每一国**
        # （讲开局该做什么，见 mp_ai.opening_guide）。它是**引擎级的开局带教**，与
        # `extra_prompt` 那套"一国一条密谕"分开——八国剧本的常驻之志正占着 extra_prompt，
        # 两者各走各的路。开关走 mp_config 的 `opening_guide`（只能关、不能强开，见 mp_run）。
        self.opening_guide: bool = True
        self.peace_offers: list[dict] = []
        self.proposals: list[dict] = []
        self._offer_id = 0  # 同上：首个邀约 id 为 1
        # 市场（main 2026-11 库存引擎）：inventory 由买卖移动（可负），reference 是报价尺度
        # （每期按净流量漂移），prices 是**本期一价**（对所有人一致），carry 是各国零头金。
        self.market_inv: dict[str, int] = {g: int(MARKET_DEPTH[g]) for g in TRADEABLE}
        self.market_ref: dict[str, float] = {g: float(MARKET_DEPTH[g]) for g in TRADEABLE}
        self.prices: dict[str, float] = {g: float(MARKET[g]) for g in TRADEABLE}
        self.market_period: int = 0
        self.market_trades: list[dict] = []    # 本期成交；结算后清空
        self.market_volume: dict[tuple, int] = {}  # (owner, side, good) -> 本期已成交量
        # 空转追踪：本期同商品双向成交（从 market_trades 现算，不进存档）
        # **市场空转**追踪（2026-09-22）：{国: {商品: {buy_n, buy_gold, sell_n, sell_gold}}}——
        # 生命周期是**行动阶段**（一次结算到下一次结算之间），见 `_record_trade` / `resolve_turn` 末尾。
        # 派生的回合内暂态：**不进存档**（存档永远落在结算之后，那时它本来就是空的）。
        self.churn: dict[str, dict[str, dict[str, int]]] = {}
        # **市场找零余额**（2026-10-09）：{国: 不足 1 金的小数}——见 `_settle_gold`。
        # 它让"拆 n 笔单买"与"一笔批量买"的总价**逐分相同**（原先每笔各 `int(round())` 一次，
        # 便宜货每笔都被进位：实测粮×100 一笔付 171、拆 100 笔付 200）。**进存档**。
        self.gold_carry: dict[str, float] = {}
        self.armies: list[dict] = []
        # `troops` / `guardians`（非野人名单、野人按格索引）的惰性缓存 —— 派生量，**不进存档**
        self._troops: list[dict] = []
        self._guards: dict = {}
        self._army_key: tuple | None = None
        self.next_army_seq: dict[str, int] = {}  # 各国独立军队序列：从1递增、阵亡不回收
        self.diplo_built: dict[str, int] = {}    # 各国「自建」外交中心座数（夺地抢来的不计，不影响自建限额）
        self.nation_code: dict[str, int] = {}    # 国家码：军队全局唯一id = 码×1e8+序列（野人=0，秦=1→100000001）
        self._next_code = 1
        self._terr_grid = None      # ★ `tile_terrain` 的缓存（见那里；惰性，指向 MapGen._terrain）
        self.guard_once: set[tuple[int, int]] = set()  # 每格至多出生一支野人：死了就没了，不重生
        self._engage_seq = 0                     # 入场序号：军队每次 atk 参战取一个递增号（野地索取顺序）
        self.grid_short: dict[str, bool] = {}
        self.energy_report: dict[str, tuple[int, int, bool]] = {}
        self.econ_summary: dict[str, str] = {}   # 上一回合结算摘要（各国 agent 看）
        # 经济报表：每 REPORT_EVERY 回合自动结一期（第 11/21/31… 回合开局可查），AI 只读、不能手动跑
        self.econ_reports: dict[str, list[dict]] = {}   # {国: [期快照…]}
        self.ledger: dict[str, dict] = {}               # 本期累计账本（结完报表清零）
        # 每回合的 GDP run-rate（{国: 金/回合}）：报表每 REPORT_EVERY 回合才结一期，
        # 而央行授信要按"**当时**的 GDP"放款 ⇒ 每回合都记一份（与报表同一条公式）。
        self.gdp_run: dict[str, float] = {}
        self.spend: dict[str, dict] = {}                # 总消费（全期累计，不清零）：终局排名用
        self.history: list[dict] = []
        self.history_seen = 0
        # ★ 全期累计 token 用量（**只为统计**，不参与任何规则结算）。
        #   口径与 llm_provider 的 stats 对齐：hit+miss=输入总量、out 是输出、reason 是其中的思考。
        #   按国分、只认 `nations` 里的键（`add_usage` 会滤掉没有的国家）——
        #   绝不让"模型名"之类的外部字符串当键长进存档，否则存档契约断言会不定期炸。
        #   est_calls/real_calls 分开记：网关没报用量时走本地估算，那部分必须**可分辨**，
        #   不然汇总出来的"总用量"会把估算当真数用（用户 2026-09-20 的那条口径）。
        self.token_usage: dict[str, dict] = {}
        # gen=False：只为读档准备一个空壳（世界由存档整体还原）。默认 gen=True 才铺地图/野人——
        # 否则 load() 会先按默认「秦楚齐」建一遍，再逐格覆盖存档，留下存档里没有的**幽灵地块**
        # （国家数 ≠3 时必然发生：默认三国里没被覆盖的那些格子会留在图上）。
        if gen:
            names = list(nations or ["秦", "楚", "齐"])
            for nm in names:
                self.nations[nm] = Nation(nm, (res or {}).get(nm))
                self.order.append(nm)
                self.mailbox[nm] = []
                self.grid_short[nm] = False
                self._assign_code(nm)
            if starts:
                self._place_crosses(starts)
            else:
                self._place_ring(names)
            # 野人**不预置**（main 2026-11）：攻击无主格时才按需生成一支守军，
            # 见 `attack` / `_spawn_guardian`。读档/存档都不带野人，状态更小。
        # ★ 表必须在**国家建完之后**补齐：`nations=` 直传的国家是在上面这个 gen 块里
        #   才进 self.nations 的（此前只有空壳 {}）。若照上面那样提前建表，
        #   直传国家的世界会得到空表 ⇒ 跑一局什么都不记，还和 load 侧不对称。
        self.token_usage = {nm: {k: 0 for k in USAGE_FIELDS} for nm in self.nations}

    # ------------------------------------------------------------- 基建
    def alive(self) -> list[str]:
        return [n for n in self.order if n in self.nations]

    def _check(self, x: int, y: int) -> None:
        if not (0 <= x < self.size and 0 <= y < self.size):
            raise IndexError(f"坐标越界：({x+1},{y+1}) 超出地图（1..{self.size}）")

    def tile_terrain(self, x: int, y: int) -> str:
        """这一格的地形：**已物化的地块以它自己的 `terrain` 为准**（那是权威值——
        占地后写进地块、也写进存档），未物化的才现问 `mapgen`。

        （移动代价按地形算之后，这条从"纯函数"变成"以地块为准"很关键：
        测试里就地改地形、以及将来任何地形改造，都必须让可达性看得见。）
        """
        # ★ **2026-09-24 优化**：`mapgen` 是 `@property`（惰性建图），而 `MapGen._terrain`
        #   本来就是一张建好的二维数组 ⇒ 这里**直接缓存那张数组**，不再逐次过 property。
        #   cProfile 实测（两局）：`mapgen` 的 getter 被调 **456,844 次**，是 `_reachable`
        #   之后的第二大热点。语义不变（同一张数组、同一个惰性时机 —— 第一次问才建图）。
        t = self.tiles.get((x, y))
        if t is not None:
            return t["terrain"]
        g = self._terr_grid
        if g is None:
            g = self._terr_grid = self.mapgen._terrain
        return g[y][x]

    # ---- 移动可达性（2026-09-15：多格移动**逐格**判定，不再是一次跳跃）----
    def _mv_wall(self, name: str, x: int, y: int) -> str | None:
        """mv 走一步进这格的"墙"：`None` = 可通行。

        口径与旧版**目标格**判定逐条对齐（只是现在每步都要过这一关）：
        野地 / 自家 / 盟国可走；敌国与中立领土一律不可（要进占只能 atk）；
        野地上有与你交战的敌军驻守也不可（得先 atk）。
        """
        owner = self.owned_by(x, y)
        if owner is not None and owner != name and not self.allied_between(name, owner):
            # ★ 话术要"教学式"：光说"不行"会让模型换个姿势再撞（实测赵 连撞 5 次 battle 自家地，
            #   2026-09-20）。这里直接给三条出路：夺格用 atk / 靠近改走无主或自家地 / 查军队面板。
            return (f"({x + 1},{y + 1}) 是「{owner}」的领土，**mv 进不去**（mv 只走自己地/盟国地/"
                    f"无主地）。要夺这格：用 atk（那几支军会突入交战）；只是想靠近：改走相邻的"
                    f"无主地或自家地；先看清各军在哪、能不能动：query panel=army"
                    if self.war_between(name, owner)
                    else f"中立不可入境：({x + 1},{y + 1}) 是「{owner}」的领土——mv 只走自己地/"
                         f"盟国地/无主地；要进它的地，先结盟或先宣战（宣战后用 atk 夺格）")
        if owner is None and any(d["owner"] != name and d["owner"] != "野人"
                                 and (d["x"], d["y"]) == (x, y)
                                 and self.war_between(name, d["owner"])
                                 for d in self.troops):    # 谓词本就排除野人 ⇒ 只扫国家军队
            return f"({x + 1},{y + 1}) 有敌军驻守，不能 mv 过去；进攻请用 atk（会交战）"
        return None

    def _reachable(self, name: str, a: dict, *, for_attack: bool = False
                   ) -> dict[tuple[int, int], int]:
        """该军本回合**走得到**的格子 → 累计代价（一致代价搜索，代价是 1/2 的小整数）。

        规则（除了"逐格走"本身，其余与旧口径一致）：

        - 每步消耗 = `max(出发格代价, 目标格代价)`（用户 2026-09-15：**对称**——
          进森林/山地减速，**待在森林/山地里的那一回合也一样慢**，不存在
          "从山上冲出来跑更快"），总预算 `unit_speed(a)`
          ⇒ 骑兵平地 2 格；涉森林/山地一步吃满 ⇒ **只能 1 格、且不可能穿过山地**；
        - **中间格**必须可通行（`_mv_wall` 为 None）：野地/自家/盟国；
        - `for_attack=True` 时**终点**额外允许敌国领土与驻军格（那是要打的），
          但中途仍必须可通行 —— 所以"隔着一座山打到纵深"不再可能；
        - 起点以代价 0 计入（原地 atk 用得上；mv 到自己格照旧是"挪了个寂寞"）。

        返回 `{格子: 代价}`（不含预算之外的格子）。

        ★ 2026-09-16 换实现，**逐值等价**（同一套判定式、同样的松弛条件与"可攻终点只记不扩"）：
          预算只有 1~2（`unit_speed`）⇒ 用**桶队列**替掉堆（省掉每回合几万次 heapq 调用），
          邻居改用按边长预建的**整数下标表**（`_adjacency`，纯几何）替掉"每步现建列表"。
          这是 v11plus 每支军每回合都要走的路径（`best_step` 与 `marchable` 的前提）。
        """
        size = self.size
        adj = _adjacency(size)
        budget = unit_speed(a)
        start = a["x"] * size + a["y"]
        best = bytearray([255]) * (size * size)      # 索引 = x * size + y；255 = 还没到过
        best[start] = 0
        buckets: list = [[] for _ in range(budget + 1)]
        buckets[0].append(start)
        # ★ 碰过的格记一份**下标名单**：收尾只把这几格还原成坐标建 dict。
        #   （别去枚举整张 `best`：那是 O(全图)，实测比旧版还慢一倍。）
        touched: list = [start]
        terrain = self.tile_terrain
        wall = self._mv_wall
        move = MOVE_COST.get(unit_kind(a), {})
        for d in range(budget + 1):
            b = buckets[d]
            while b:
                i = b.pop()
                if best[i] != d:                     # 陈旧条目（后来有更近的路）
                    continue
                x, y = divmod(i, size)
                here = move.get(terrain(x, y), 1)
                if here is None:                     # 起点在屏障（不该发生）：不扩
                    continue
                for j in adj[i]:
                    jx, jy = divmod(j, size)
                    cj = move.get(terrain(jx, jy), 1)
                    if cj is None:                   # 目标格是高山/海洋：不可通行
                        continue
                    ncost = d + (here if here > cj else cj)
                    if ncost > budget or ncost >= best[j]:
                        continue
                    why = wall(name, jx, jy)
                    if why:
                        if for_attack and self._atk_target_ok(name, jx, jy):
                            best[j] = ncost          # 可攻：算**终点**，但不从它继续扩
                            touched.append(j)
                        continue                     # 走不进去 ⇒ 更不能穿过
                    best[j] = ncost
                    touched.append(j)
                    buckets[ncost].append(j)
        return {(i // size, i % size): best[i] for i in touched}

    def polity_rule(self, name: str, key: str, default):
        """取该国的政体修正项（数值全在 `balance.POLITY`；没有政体/没这一项 → `default`）。"""
        return POLITY.get(self.polity.get(name) or "", {}).get(key, default)

    def recruit_cost(self, name: str, kind: str) -> dict[str, int]:
        """该国征召一支 `kind` 实际要花的原料（**含政体特价**）。

        引擎（`recruit`）与 AI 文案（`mp_ai` 的征召工具描述）都走这一份口径 ——
        曾经两边各写一遍数字，改一处就漂一处。
        """
        return dict(self.polity_rule(name, "recruit", {}).get(kind)
                    or UNIT_TYPES[kind]["recruit"])

    def _atk_target_ok(self, name: str, x: int, y: int) -> bool:
        """这一格能不能当 atk 的**终点**（敌国领土 / 野地驻军）= "有东西可打/可占"。
        与 `attack` 里那套墙判定的"可攻"侧一致（不含"不抢别人的战斗"那条，那条在 attack 里）。"""
        owner = self.owned_by(x, y)
        if owner is not None:
            return owner != name and not self.allied_between(name, owner) \
                and self.war_between(name, owner)
        return any(d["owner"] != name and (d["x"], d["y"]) == (x, y) for d in self.armies)

    def _unreachable_msg(self, a: dict, x: int, y: int, *, for_attack: bool) -> str:
        """走不到目标格时的说法：能教人（平地几格、崎岖几格），但**不替玩家开图**
        ——地形只在视野内才点名（迷雾限眼不限手：盲推撞墙如实报"墙在视野外"）。"""
        label = UNIT_TYPES[unit_kind(a)]["label"]
        budget = unit_speed(a)
        ter = self.tile_terrain(x, y)
        here = self.tile_terrain(a["x"], a["y"])
        # ★ 一步的代价 = **max(出发格, 目标格)** —— 与 `_reachable` 的桶队列同口径
        #   （本文件 `ncost = d + (here if here > cj else cj)`）。
        #   曾经只取**目标格** ⇒ 站在崎岖地上时：① 报出的代价偏小；② "一步就吃满"
        #   那句该响不响（骑兵站山地→平原：真实 2≥2 吃满，旧算法算出 1<2 不报）。
        cost = max(unit_move_cost(a, here) or 0, unit_move_cost(a, ter) or 0)   # None = 不可通行（高山/海洋）
        acted = "冲不进去" if for_attack else "走不到"
        seen = self.visible_to(a["owner"], x, y)
        if seen:
            # ★ `budget > 1`：步兵移动力天然只有 1，"吃满"对它是恒真的废话
            #   （任何地形都报同一句）⇒ 只在**多格兵种**上才点破地形吃满。
            tip = (f"（{label}移动力 {budget}；自{here}进{ter}这一步要 {cost}"
                   f"{'，吃满 ⇒ 本回合只走得了这 1 格' if budget > 1 and cost >= budget else ''}）")
        else:
            tip = f"（{label}移动力 {budget}；沿路地形/敌情不明——盲推撞墙如实报告，但额度照烧）"
        return f"{a['name']} {acted} ({x + 1},{y + 1}){tip}"

    @property
    def mapgen(self):
        """整张图的生成器（`mapgen.MapGen`，**惰性**：第一次问地形/资源才建）。

        2026-09-15 起地图不再是逐格纯函数，而是**由 `(seed, size)` 决定的一整张图**
        （蓝噪声 + 密度图调制，见 `mapgen.py`）：逐格独立抽是泊松随机场，局部既结块
        又有孔洞，且"起步 5 格开什么牌"会被复利放大。对外接口没变
        （`tile_terrain` / `tile_resources` 签名与返回值照旧），调用点不用改。

        ★ **惰性**是有意的：读档（`gen=False`）连图都不用生成——存档里已物化的地块
        自带 `terrain`/`resources` 字面量，只有新占的格子才会问到这里。
        """
        if self._mapgen is None:
            from mapgen import MapGen
            self._mapgen = MapGen(self.seed, self.size)
        return self._mapgen

    def tile_resources(self, x: int, y: int) -> dict[str, int]:
        """该地块的矿藏/耕地布局（建采集建筑要看的就是它）——**静态属性**，
        跟谁先占、占之前打过几仗毫无关系（见 `mapgen`）。

        历史两坑（都已修，别再踩）：曾用**世界共享 RNG** `roll_resources(self.rng, …)`
        ⇒ 同一格摇出什么取决于轮到它时 RNG 走了多远（战斗掷骰也在那条流上），
        「种子可复现」形同虚设；命名同理（每建一格都消耗、撞名重试使消耗个数不定）。
        现在 `self.rng` 只剩战斗与开局布点在用。
        """
        return self.mapgen.resources(x, y)

    def ter_char(self, x: int, y: int) -> str:
        return TERRAIN_CHARS[self.tile_terrain(x, y)]

    def visible_buildings(self, name: str, x: int, y: int) -> dict:
        """name 在 (x,y) 上**看得见**的建筑（不含在建）——全作唯一口径，面板一律走这里。

        · **自家的地**：全部建筑（自己的工地当然清楚；在建不在此列，看 `pending`）。
        · **视野内的他国地**：**只有城堡与市政厅** —— 两样都是"从外面就看得出"的公共建筑：
          要塞（2026-09-19 用户：「不知道城堡很吃亏」）与**市政厅（国祚，2026-09-21）**。
          后者必须公开，否则"拔光市政厅即亡国"这条规则根本无从瞄准（看不见就打不着）。
          兵营/工厂/农田仍是内政底细，那是 `spy` / 换图才买得到的东西。
        · **视野内的无主故土**（前朝废墟，`owner is None` 且已物化）：**全部建筑** ——
          那条纪律护的是"**别国的**内政底细"，这里没有国（亡国才留下这种格），
          也就无机密可言。**它是唯一能产出 `owner is None` 的物化格的来源**
          （见 `_eliminate_if_dead`），所以这条分支不会误伤任何"正常的无主野地"
          （那些格根本没物化）。
        · **视野外**：空 dict（与 `visible_to` 同一条纪律）。

        （公开档位：2026-09-19 只放行城堡；2026-09-21 加市政厅（国祚）与无主故土全开。
        其余建筑与地块资源仍旧未探明。）
        """
        t = self.tiles.get((x, y))
        if not t:
            return {}
        if t["owner"] == name:
            return {b: n for b, n in t["buildings"].items() if n}
        if not self.visible_to(name, x, y):
            return {}
        if t["owner"] is None:
            return {b: n for b, n in t["buildings"].items() if n}
        return {b: t["buildings"][b] for b in ("城堡", "市政厅") if t["buildings"].get(b)}

    def owned_by(self, x: int, y: int) -> str | None:
        t = self.tiles.get((x, y))
        return t["owner"] if t else None

    def neighbors(self, x: int, y: int) -> list[tuple[int, int]]:
        out = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.size and 0 <= ny < self.size:
                    out.append((nx, ny))
        return out

    def own_tiles(self, name: str) -> list[tuple[int, int]]:
        return sorted((x, y) for (x, y), t in self.tiles.items() if t["owner"] == name)

    def frontier_of(self, name: str) -> set[tuple[int, int]]:
        fr = set()
        for (x, y), t in self.tiles.items():
            if t["owner"] != name:
                continue
            for nx, ny in self.neighbors(x, y):
                if (nx, ny) not in self.tiles:
                    fr.add((nx, ny))
        return fr

    def nation_building_count(self, name: str, building: str, *, include_pending: bool = False) -> int:
        """name 全部地块上某建筑的已落成座数（include_pending=True 含在建）。"""
        n = 0
        for t in self.tiles.values():
            if t["owner"] != name:
                continue
            n += t["buildings"].get(building, 0)
            if include_pending:
                n += (t.get("pending") or {}).get(building, 0) or 0
        return n

    def visible_to(self, name: str, x: int, y: int) -> bool:
        """name 是否看得见 (x,y)：它本身或相邻格（含对角）有自家的地。
        联盟共享视野：盟友的地块视同己方（自己+盟友地盘各带相邻一圈）。"""
        cand = [(x, y)] + self.neighbors(x, y)
        bloc = self.bloc_of(name)
        for cx, cy in cand:
            o = self.owned_by(cx, cy)
            if o == name:
                return True
            if bloc is not None and o in bloc["members"]:
                return True
        # 瞭望塔：己方/盟方任一瞭望塔半径（`effects.vision_radius`）圆（欧氏）内也可见（事件视野）
        # 半径**每次调用取一次**（效果是数据，可能被整体抖动）；这条路径调用极频繁，
        # 别把它塞进内层循环。
        _tower_r = building_effect("瞭望塔", "vision_radius")
        _tower_r2 = _tower_r * _tower_r
        for (tx, ty), t in self.tiles.items():
            if not t["buildings"].get("瞭望塔"):
                continue
            o = t["owner"]
            if o != name and not (bloc is not None and o in bloc["members"]):
                continue
            if (tx - x) ** 2 + (ty - y) ** 2 <= _tower_r2:
                return True
        return False

    # ------------------------------------------------------------- 联盟
    def bloc_of(self, name: str) -> dict | None:
        """name 所属联盟（一国同时只属一个联盟）；无则 None。"""
        for b in self.blocs:
            if name in b["members"]:
                return b
        return None

    def bloc_by_name(self, name: str) -> dict | None:
        for b in self.blocs:
            if b["name"] == name:
                return b
        return None

    def bloc_chief(self, bloc: dict | None) -> str | None:
        """联盟盟主。以 chief 字段为准；字段缺失/失效（旧档、盟主已不在）时退回最早加入者。"""
        if not bloc or not bloc.get("members"):
            return None
        c = bloc.get("chief")
        return c if c in bloc["members"] else bloc["members"][0]

    # ------------------------------------------------------------- 外交实体
    # 对外签约主体只有两种：**独立国家** 与 **联盟**。在盟国家不是实体（见模块头注释）；
    # 普通附庸**并入宗主**（main 2026-11），所以国家的实体 = 宗主所在的实体。
    def _vassal_chain(self, name: str) -> str:
        """沿附庸链上溯到宗主（防环：最多走到 seen 重复为止）。"""
        seen = set()
        cur = name
        while cur in self.vassals and cur not in seen:
            seen.add(cur)
            cur = self.vassals[cur]["overlord"]
        return cur

    def entity_of(self, name: str) -> str:
        """该国的外交实体：普通附庸 → 宗主；宗主在盟 → 其联盟；否则 → 自己。"""
        sovereign = self._vassal_chain(name)
        b = self.bloc_of(sovereign)
        return ent_bloc(b["name"]) if b is not None else ent_nation(sovereign)

    def entity_members(self, ent: str) -> list[str]:
        """实体包含的现存国家（含普通附庸；加入序）。"""
        return [m for m in self.alive() if self.entity_of(m) == ent]

    def entity_chief(self, ent: str) -> str | None:
        """实体的对外代表：联盟=盟主，独立国家=它自己。"""
        if is_bloc_ent(ent):
            return self.bloc_chief(self.bloc_by_name(ent_key(ent)))
        n = ent_key(ent)
        return n if n in self.nations else None

    def entity_label(self, ent: str) -> str:
        """日志/面板用的人话名。"""
        if is_bloc_ent(ent):
            b = self.bloc_by_name(ent_key(ent))
            return f"联盟「{ent_key(ent)}」" if b else f"联盟「{ent_key(ent)}」（已散）"
        return ent_key(ent)

    def entities(self) -> list[str]:
        """全部现存外交实体（独立国家 + 联盟），**sorted** —— 面板与闭包都不许裸集合迭代。"""
        out = [ent_nation(self._vassal_chain(n)) for n in self.alive()
               if self.bloc_of(self._vassal_chain(n)) is None]
        out += [ent_bloc(b["name"]) for b in self.blocs
                if self.entity_members(ent_bloc(b["name"]))]
        return sorted(out)

    def entity_at_war(self, ent: str) -> bool:
        """实体是否卷入战争（任一国在打就算）——战时锁死与缔约禁令都看它。"""
        return any(self.at_war(m) for m in self.entity_members(ent))

    def _war_brief_ent(self, ent: str) -> str:
        for m in self.entity_members(ent):
            if self.at_war(m):
                return self._war_brief(m)
        return f"{self.entity_label(ent)} 正在交战"

    def _same_camp(self, x: str, y: str) -> bool:
        """x、y 是否"该并肩"：同属一个实体，或有共同防御（宣战并入战线的判据）。"""
        ex, ey = self.entity_of(x), self.entity_of(y)
        return ex == ey or self.has_pact("共同防御", ex, ey)

    # ------------------------------------------------------------- 条约表（实体级）
    def has_pact(self, kind: str, a: str, b: str) -> bool:
        """a、b 都是**实体 id**。保障看方向（a 保障 b）；共同防御对称。"""
        if kind == "保障":
            return any(p["kind"] == kind and p["a"] == a and p["b"] == b for p in self.pacts)
        return any(p["kind"] == kind and {p["a"], p["b"]} == {a, b} for p in self.pacts)

    def pacts_of(self, ent: str) -> list[dict]:
        """与该实体有关的一切条约（面板/断约/亡国清理用）。"""
        return [p for p in self.pacts if ent in (p["a"], p["b"])]

    def guaranteed_by(self, ent: str) -> list[str]:
        """ent 保障的实体（**sorted**）。面板用。"""
        return sorted(p["b"] for p in self.pacts if p["kind"] == "保障" and p["a"] == ent)

    def guarantors_of(self, ent: str) -> list[str]:
        """保障 ent 的实体（**sorted**：闭包要按它迭代，裸集合序会毁复现性）。"""
        return sorted(p["a"] for p in self.pacts if p["kind"] == "保障" and p["b"] == ent)

    def defense_partners_of(self, ent: str) -> list[str]:
        """与 ent 有共同防御的实体（**sorted**，同上）。"""
        return sorted(p["b"] if p["a"] == ent else p["a"]
                      for p in self.pacts
                      if p["kind"] == "共同防御" and ent in (p["a"], p["b"]))

    def _add_pact(self, kind: str, a: str, b: str) -> None:
        x, y = (a, b) if kind == "保障" else tuple(sorted((a, b)))
        self.pacts.append({"kind": kind, "a": x, "b": y, "turn": self.turn})

    def _drop_pact(self, kind: str, a: str, b: str) -> bool:
        """删一条条约（a、b 是实体 id）。返回是否真删到。"""
        for p in list(self.pacts):
            if p["kind"] != kind:
                continue
            hit = (p["a"] == a and p["b"] == b) if kind == "保障" else ({p["a"], p["b"]} == {a, b})
            if hit:
                self.pacts.remove(p)
                return True
        return False

    def drop_pacts_of(self, ent: str) -> list[str]:
        """清掉与该实体有关的一切条约（入盟吞掉个人条约、国家灭亡）。返回人话描述。"""
        gone = []
        for p in list(self.pacts):
            if ent in (p["a"], p["b"]):
                self.pacts.remove(p)
                gone.append(f"{p['kind']}（{self.entity_label(p['a'])}—{self.entity_label(p['b'])}）")
        return gone

    def _pact_block(self, kind: str, A: str, B: str) -> str | None:
        """准入：两实体能否签这种条约。返回拒绝理由，None=可以签。"""
        if A == B:
            return (f"{self.entity_label(B)} 与你同属一个实体——盟内互通领土/互不攻击/互卫"
                    "是联盟自带效果，无须也无法单独缔约")
        if kind == "保障":
            if self.has_pact("保障", A, B):
                return f"{self.entity_label(A)} 已保障 {self.entity_label(B)}，无须重复"
            if self.has_pact("共同防御", A, B):
                return f"两实体已有共同防御（更高一档），无须再保障"
            return None
        if self.has_pact("共同防御", A, B):
            return "两实体已是共同防御"
        return None

    def _conclude_pact(self, kind: str, A: str, B: str) -> tuple[bool, str]:
        """真正落条约（双方实体都已同意）。缔结共同防御时自动解除低档的保障。"""
        low = []
        if kind == "共同防御":
            for x, y in ((A, B), (B, A)):
                if self._drop_pact("保障", x, y):
                    low.append(f"{self.entity_label(x)} 对 {self.entity_label(y)} 的保障")
        self._add_pact(kind, A, B)
        up = f"（自动解除低档：{'、'.join(low)}）" if low else ""
        self.proclaim(f"🕊 {self.entity_label(A)} 与 {self.entity_label(B)} 缔结{kind}{up}")
        return True, f"{self.entity_label(A)} 与 {self.entity_label(B)} 缔结{kind}{up}"

    def _break_pacts_between(self, e1: str, e2: str) -> list[str]:
        """开战前清约束：解除两实体之间的一切保障/共同防御（含双向保障）。"""
        out = []
        for kind, x, y in (("共同防御", e1, e2), ("保障", e1, e2), ("保障", e2, e1)):
            if self._drop_pact(kind, x, y):
                out.append(f"解除 {self.entity_label(x)} 与 {self.entity_label(y)} 的{kind}")
        for line in out:
            self.proclaim(f"💔 {line}（双方开战，自动解除）")
        return out

    def _pact_exit_wars(self, side: list[str], other: list[str]) -> list[dict]:
        """断约退战：跟随方不想打的退出通道——昔日盟友参与的战线，其跟随方身份随之解除。
        side/other 是**国家名单**（实体成员）；名单序来自联盟成员序，不做集合迭代。"""
        exited = []
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if not any(o in atk + dfs for o in other):
                continue
            hit = False
            for m in side:
                if m in w["followers"]:
                    w["followers"].remove(m)
                    hit = True
                if m in w.get("atk_followers", []):
                    w["atk_followers"].remove(m)
                    hit = True
            if hit:
                exited.append(w)
        for m in side:      # 已不属任何战线 → 解除交战，回合末自动遣返
            still = any(m in ([x["atk"]] + list(x.get("atk_followers", []))
                              + [x["def"]] + list(x["followers"])) for x in self.wars)
            if not still:
                for u in self.armies:
                    if u["owner"] == m and u.get("engaged"):
                        u["engaged"] = False
        return exited

    def at_war(self, name: str) -> bool:
        """该国是否正卷入任何战争（进攻/防御主导者或跟随方）。"""
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if name in atk or name in dfs:
                return True
        return False

    def set_truce(self, a: str, b: str, until: int) -> bool:
        """写一条休战（**唯一写入口**）。a/b 给**国名**（按它所在的实体存）或**实体 id**。

        **只许延长、不许缩短**（`max`）：全天下强制休战是防雪球的地基，不该被一纸短约抹掉。
        同实体（盟内）不写，返回 False。
        """
        ea = self.entity_of(a) if a in self.nations else _truce_key_id(a)
        eb = self.entity_of(b) if b in self.nations else _truce_key_id(b)
        if ea == eb:
            return False
        p = _pair(ea, eb)
        self.truce[p] = max(self.truce.get(p, 0), int(until))
        return True

    def active_truce(self, a: str, b: str) -> int | None:
        """a、b 之间**有效**的休战 → 到期回合（已到期的顺手清掉，None = 没有）。

        ★★ 休战表**按外交实体存**（与条约表 `self.pacts` 同一口径，2026-10-11 修）：
        键是实体 id（独立国＝`国:x`，联盟＝`盟:名字`）。

        · 同属一个实体（联盟）⇒ None：**盟内互不攻击**比和约更强，那纸约不独立成立；
        · 否则查**两个实体之间**那条 ⇒ **成员个人的和约在盟内自动冻结**（它的键是
          `国:成员`，而此刻这个国家属于 `盟:某盟`，键对不上），**退出即自动恢复**
          （键又对上了）——表里那条**一个字都不用删**。

        ★★ 为什么不能"查盟主"（我第一版就是这么写的，被用户当场判错）：
        「移交盟主，没有移交联盟关系，变成了被移交者的个人关系」——把实体的约**派生**自
        盟主身上那条，等于**换盟主就换掉了全盟的对外关系**：新盟主跟谁有私约，全盟就跟谁
        有约。**联盟关系是联盟关系，个人关系是个人关系**：前者记在联盟身上、只随投票变，
        后者冻结在成员自己身上、随进退盟解冻。现在换盟主**动不了**任何一条。
        """
        ea, eb = self.entity_of(a), self.entity_of(b)
        if ea == eb:
            return None                      # 同实体：盟内互不攻击
        p = _pair(ea, eb)
        t = self.truce.get(p)
        if t is None:
            return None
        if self.turn >= t:
            self.truce.pop(p, None)
            return None
        return t

    def truces_of(self, name: str) -> list[tuple[str, int]]:
        """该国（**其所在实体**）还在休战期内的全部对手 → [(对手, 到期回合)]，按对手排序。

        ★ 含**亡国时压给全天下的强制休战**（`FALL_TRUCE_TURNS`）——用户 2026-09-20 口径：
        那条也算"和约"。它只拦**宣战**，不拦结盟（见 `active_truce`）。
        返回的是**实体 id**（"盟:周天下" / "国:燕"）；成员个人冻结中的私约不在此列。
        """
        me_ent = self.entity_of(name)
        out: dict[str, int] = {}
        for p in list(self.truce):
            x, y = sorted(p)          # ★ sorted：p 是 frozenset，裸迭代序受 PYTHONHASHSEED 影响
            if x != me_ent and y != me_ent:
                continue
            other = y if x == me_ent else x
            # 陈旧条目：成员**入盟前**跟这个联盟签的那条（键是 国:成员↔盟:本盟）。
            # 入盟那一刻它就等于"联盟跟自己"，不该再作为对手出现在面板上。
            if other == me_ent or (other.startswith("国:")
                                   and self.entity_of(other[2:]) == me_ent):
                continue
            t = self.truce.get(p)
            if t is None or self.turn >= t:
                if t is not None:
                    self.truce.pop(p, None)
                continue
            out[other] = max(out.get(other, 0), t)
        return sorted(out.items())

    def _suspended_truces(self, members: list[str]) -> list[str]:
        """这批国家手里那些**从此暂停**的和约 → 人话（只**读表**报事实，不改表）。

        ★ 2026-10-11：实体的和约＝**盟主**的和约 ⇒ 成员自己签的那些一律暂停（对内对外
        都一样）。表里那条根本没动，所以"退出自动恢复"不需要任何额外机制——
        但不报一句就成了"结果不告诉当事人"。
        """
        out: list[str] = []
        seen: set = set()
        for m in members:
            for p in sorted(self.truce, key=sorted):
                if p in seen or ent_nation(m) not in p:
                    continue
                u = self.truce[p]
                if self.turn >= u:
                    continue
                seen.add(p)
                out.append(f"{'↔'.join(sorted(p))}（原休战至第 {u} 回合）")
        return out

    def _vote_stakeholders(self, v: dict) -> list[str]:
        """一条投票的**当事人**：盟内全体成员 + **盟外**相关方（申请人／对方实体／被邀方）。

        ★ 用户 2026-10-11：「**投票是否成功，或者被取消，盟外和盟内都需要通知的**，
        例如某个国家提请加入结果中途爆发战争，应该被通知」。
        此前这些结局只挂 `nation=proposer`——**申请人（恰恰常在盟外）什么都收不到**：
        他提了入盟申请，盟主一票否决／票没过／联盟解散把票清了，他一无所知，
        只能对着 `diplomacy` 面板里消失的投票号猜。
        """
        pl = v.get("payload") or {}
        out: list[str] = []
        b = self.bloc_by_name(v.get("bloc") or "")
        if b:
            out += list(b["members"])
        if v.get("proposer") in self.nations:
            out.append(v["proposer"])
        for key in ("candidate", "to", "target", "offer_id"):
            # candidate=入盟申请人（国名）；to=议和对象（国名）；target/A/B=实体 id（下面统一展开）
            if pl.get(key) in self.nations:
                out.append(pl[key])
        for ent in pl.values():
            # 实体 id（"盟:x"/"国:y"）：认不出的值返回 []，所以"pact"/"cancel"这些也不怕
            if isinstance(ent, str):
                out += self.entity_members(ent)
        out += [x for x in (pl.get("invitees") or []) if x in self.nations]
        seen: set = set()
        res: list[str] = []
        for x in out:
            if x in self.nations and x not in seen:
                seen.add(x)
                res.append(x)
        return sorted(res)

    def _cancel_vote(self, v: dict, why: str) -> None:
        """作废一条投票（若还在表里）并**通知盟内盟外全部当事人**。

        ★ **计票数字不进这条**：用户 2026-09-19 的"商议过程不公开"没被推翻——
        要通知的是**结果**（成没成、废没废），不是票数。票数照旧只在当事国的**回复**里
        给到发起人（`_tally` 的返回值），盟内其他人的面板里进行中的票本来就带票数。
        """
        if v in self.votes:
            self.votes.remove(v)
        self.log(f"🗳 「{v['bloc']}」投票#{v['id']}（{v['kind']}）作废：{why}",
                 phase="外交", parties=self._vote_stakeholders(v))

    def _void_pending_treaties(self, why: str, all_kinds: bool = False) -> list[str]:
        """开战 ⇒ **战前还没通过的外交条约一律当场作废**（2026-10-11 用户口径）。

        `all_kinds=True` 是给**强制和平**用的（用户 2026-10-11 报的洞：「强制和平后，
        还没有敲定的和平条约没有自动作废」）：亡国那一刻**所有战线当场终止 + 全天下压上
        强制休战**，在途的一切（宣战/议和投票、求和提议）全都失去前提，一律作废；
        而开战时只清"缔约/入盟"，**宣战与议和投票要留着**——那是战争本身的操作。

        「战时条约冻结」（缔结与解除都不行，见 `propose_pact` / `break_pact`）早就有，
        但**在途的表决与邀约是绕过它的后门**：缔约投票、入盟投票、结盟提议、
        共同防御/保障邀约——统统是"**战前发起、战后再落地**"：发起那一刻还没打仗，
        通过那一刻已经在打了。开战即清，谁都别想搭这趟车。
        ★ **宣战与议和投票不动**：那是战争本身的操作，清了等于把出口也堵死。
        """
        votes = [v for v in self.votes
                 if all_kinds or v["kind"] in ("缔约", "入盟")]
        props = list(self.proposals)
        offers = list(self.peace_offers) if all_kinds else []
        if not votes and not props and not offers:
            return []
        killed: list[str] = []
        for v in votes:              # 每条投票**单独通知**它的盟内盟外当事人（含申请人）
            killed.append(f"{v['kind']}投票#{v['id']}（「{v['bloc']}」）")
            self._cancel_vote(v, f"{why}——{'战线已全部终止' if all_kinds else '战时条约冻结'}")
        for o in offers:
            # 在途的求和提议：强制和平之后它已经**没有战线可停**了，留着只会在落地那一刻
            # 把全天下强制休战覆盖成它自己的短休战（2026-10-11 报的洞）。
            killed.append(f"求和提议#{o['id']}（{o['a']}→{o['b']}）")
            self.peace_offers.remove(o)
            self.log(f"🕊 {o['a']} 对 {o['b']} 的求和提议#{o['id']}作废：{why}"
                     "（战线已终止，无须再谈；强制休战期照旧）", phase="外交",
                     parties=sorted({o["a"], o["b"]} & set(self.nations)))
        if props:
            killed += [f"{p['kind']}提议#{p['id']}" for p in props]
            parties: list[str] = []
            for p in props:
                for key in ("a", "asker"):
                    if p.get(key) in self.nations:
                        parties.append(p[key])
                parties += [x for x in (p.get("invitees") or []) if x in self.nations]
                for ent in (p.get("A"), p.get("B")):
                    if isinstance(ent, str):
                        parties += self.entity_members(ent)
            self.proposals = []
            self.log(f"🕊 {why} ⇒ **战前未通过的外交条约当场作废**：{'、'.join(killed)}"
                     "（战时条约冻结；停战后可重新提）", phase="外交",
                     parties=sorted(set(parties)))
        return killed

    def _truce_blocks_war_join(self, countries: list[str], opponents: list[str]) -> bool:
        """这批国家里有没有谁与**对面**还在休战期内 ⇒ 不能把它拖进这场战争。

        用在自动参战（联盟/共同防御/保障的守侧一跳）上：用户 2026-09-20
        「有和约时，防御条约和独立保障应该无法执行」——**已有的条约不触发**，
        和约不能因为盟友开战就当场作废。
        """
        return any(self.active_truce(m, o) for m in countries for o in opponents)

    def _war_brief(self, name: str) -> str:
        """给"战争期禁止外交"类错误提示用的战线简述。"""
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if name in atk:
                return f"{name} 正与 {'、'.join(dfs)} 交战"
            if name in dfs:
                return f"{name} 正与 {'、'.join(atk)} 交战"
        return ""

    def bloc_desc(self) -> str:
        """看海/面板用：全部联盟一览。"""
        if not self.blocs:
            return "无联盟"
        parts = []
        for b in self.blocs:
            chief = self.bloc_chief(b) or "?"
            parts.append(f"「{b['name']}」（盟主 {chief}；成员：{'、'.join(b['members'])}）")
        return "  ".join(parts)

    # ------------------------------------------------------------- 看海日志
    def _stamp_seen(self, entry: dict, parties: list[str] | None = None) -> None:
        """纪事落盘时刻抓一份"谁看得见这里"的快照。events_for 按快照过滤，
        而不是按查询时刻的视野——否则你后来夺下的地上发生的**旧** Retreat/战报
        会事后凭空显形（回溯补发情报）。

        `parties`：**必须看到这条**的当事国（把结果告诉对面）。有坐标时是**并进**
        视野快照，没坐标时它们就是全部可见者。这条通道是用户 2026-09-20 报的两个洞
        的正解：求和/缔约**被拒**此前只有拒绝方自己看得见（对面一直等下去），
        夺地只写攻方视角（失主**四周已无自家地**时连"我丢了哪块"都收不到）。
        ★ 口径：**"怎么谈的"不广播**，但**当事人必须知道结果**——两者不冲突
        （广播是给第三方的，parties 是给桌上那两方的）。
        """
        x, y = entry.get("x"), entry.get("y")
        # ★ **坐标成对才算坐标**（2026-09-23 修）：只看 `x is not None` 的话，
        #   半个坐标（有 x 没 y）会一路带到 `visible_to` → `neighbors` → `None + int` 崩掉。
        #   缺一个 = 没有坐标（按无坐标处理），后面 events_for 也只认成对的（同口径）。
        has_coords = x is not None and y is not None and bool(self.nations)
        if not has_coords and not parties:
            return
        seen = [n for n in self.nations if self.visible_to(n, x, y)] if has_coords else []
        for p in (parties or ()):
            if p in self.nations and p not in seen:
                seen.append(p)
        entry["seen"] = seen

    def broadcast(self, text: str, phase: str = "事件") -> str:
        """**全世界都看得见**的公告（央行利率这类世界新闻用它）。

        与 `log` 的区别：`log` 按坐标做视野快照，**没有坐标的条目谁也看不到**；
        这里显式把 `seen` 写成全体现存国家，`events_for` 按快照放行。
        """
        entry = {"turn": self.turn, "phase": phase, "nation": None,
                 "x": None, "y": None, "text": text,
                 "seen": list(self.nations)}
        self.history.append(entry)
        return text

    def proclaim(self, text: str) -> str:
        """**国家行为**的世界公告：缔约 / 解除 / 宣战 / 议和 / 联盟成立与变更。

        ★ 口径（2026-09-19 用户：「**必须知情**」）：条约与战争是**公开行为**——第三方有权
        知道谁跟谁结盟、谁打谁、谁跟谁议和了（现实里这些本来就要公布，共同防御尤其如此：
        它本来就是冲着第三方设计的，第三方却被蒙在鼓里说不过去）。
        走 `broadcast`（`seen` = 全体现存国家，`phase="外交"`，进各国近讯的外交类），
        **不受视野过滤**——与央行利率公告同一条通道。

        与之相对，**商议过程**仍只给当事人（`log(nation=…)`）：联盟内部投票与计票、求和提议的
        来回、写信、情报。一句话：**「签了没有」公开，「怎么谈的」不公开。**
        """
        return self.broadcast(text, phase="外交")

    def add_usage(self, nation: str, stats: dict) -> None:
        """把一次调用的用量累计进 `token_usage[nation]`（**只为统计**，不参与结算）。

        口径与 `llm_provider` 的 stats 同键：`hit`/`miss` 是输入的两半（hit+miss=输入总量）、
        `out_tokens` 是输出、`reason_tokens` 是其中的思考。

        两条纪律（都是这个项目栽过的坑）：
        1. **只认 `nations` 里的国家**。键一旦让外部字符串长进来（模型名、临时 actor），
           存档契约断言就会在某个不相干的回合突然炸 —— 宁可丢掉这一笔记账。
        2. **估的与报的分开数**。`usage_reported` 为假时走的是本地估算，那部分必须能
           被分辨出来；否则汇总出来的"总用量"就是估数与真数的混合，拿它算钱会错得没边。
        """
        slot = self.token_usage.get(nation)
        if slot is None:
            return
        hit = int(stats.get("hit") or 0)
        miss = int(stats.get("miss") or 0)
        out = int(stats.get("out_tokens") or 0)
        slot["calls"] += 1
        slot["hit"] += hit
        slot["miss"] += miss
        slot["prompt"] += hit + miss
        slot["out"] += out
        slot["reason"] += int(stats.get("reason_tokens") or 0)
        if stats.get("usage_reported"):
            slot["real_calls"] += 1
        else:
            slot["est_calls"] += 1

    def usage_totals(self) -> dict:
        """把 `token_usage` 汇总成一行总账（放看海台用）。

        `estimated` 为真表示总数里掺了本地估算 —— 显示时要打 `≈`，别当真数看。
        """
        total = {"calls": 0, "prompt": 0, "hit": 0, "miss": 0, "out": 0,
                 "reason": 0, "est_calls": 0, "real_calls": 0}
        for slot in self.token_usage.values():
            for k in total:
                total[k] += int(slot.get(k) or 0)
        inp = total["hit"] + total["miss"]
        total["hit_rate"] = (total["hit"] / inp) if inp else None
        total["total"] = total["prompt"] + total["out"]
        total["estimated"] = bool(total["est_calls"])
        return total

    def log(self, text: str, phase: str = "事件", nation: str | None = None,
            x: int | None = None, y: int | None = None,
            parties: list[str] | None = None,
            lost_by: str | None = None) -> str:
        """写一条纪事。可见性见 `_stamp_seen`：
        `nation=` 只给那一家；坐标按视野快照；`parties=` **保证这些当事国看到**
        （对手方通知：被拒了、地被夺了——不广播，但对面必须知道）。

        `lost_by`：**地块易主时原属国**（`phase="领土"` 用）——给面板的
        【领土警报】按事实查（`nation`=得方 / `lost_by`=失方 / x,y=哪一格），
        **不解析文本**（文本是给人读的，改个措辞就把面板读崩了）。
        """
        entry = {
            "turn": self.turn, "phase": phase, "nation": nation,
            "x": x, "y": y, "text": text,
        }
        if lost_by is not None:
            entry["lost_by"] = lost_by
        self._stamp_seen(entry, parties)
        self.history.append(entry)
        return text

    def action(self, nation: str, tool: str, args: str, result: str, x=None, y=None):
        entry = {
            "turn": self.turn, "phase": "行动", "nation": nation,
            "x": x, "y": y,
            "text": f"{nation} ◇ {tool} {args} → {result}",
        }
        self._stamp_seen(entry)
        self.history.append(entry)

    def events_for(self, name: str, limit: int = 14) -> list[str]:
        """该国能看到的近期事件（自己相关，或发生在视野内）。信件走信箱，此处不重复。"""
        out = []
        for h in reversed(self.history):
            if h["phase"] == "信件":
                continue
            if h["nation"] == name:
                out.append(f"[第{h['turn']}回合] {h['text']}")
            elif "seen" in h:
                # ★ 有快照就**只认快照**（绝不退回现视野——否则夺地后旧战报会回溯显形）；
                #   无坐标的世界广播也走这条：broadcast 把 seen 写成全体现存国家。
                if name in h["seen"]:
                    out.append(f"[第{h['turn']}回合] {h['text']}")
            elif (h.get("x") is not None and h.get("y") is not None
                  and self.visible_to(name, h["x"], h["y"])):
                # ★ 按落盘时刻的视野快照过滤（_stamp_seen）；无快照的极少数条目退回现视野
                out.append(f"[第{h['turn']}回合] {h['text']}")
            if len(out) >= limit:
                break
        return list(reversed(out))

    def fresh_history(self) -> list[dict]:
        h = self.history[self.history_seen:]
        self.history_seen = len(self.history)
        return h

    # ------------------------------------------------------------- 开局
    def _new_tile(self, x: int, y: int, owner: str) -> dict:
        terrain = self.tile_terrain(x, y)
        return {
            "owner": owner,
            "terrain": terrain,
            "resources": self.tile_resources(x, y),
            "buildings": {b: 0 for b in BUILDINGS},
            "pending": {b: 0 for b in BUILDINGS},  # 在建（下回合才生效）
            # ★ 地名是**地图属性**（main 2026-11）：由 `(seed,size,x,y)` 决定、全图唯一，
            #   未物化的格也有名（"有名字没守军"= 可读侦查信号），不随建地顺序变化。
            "name": self.mapgen.name(x, y),
            "core": owner,  # 核心领土：首任 owner；每次战争结束按参与者实占重算
            "recruited_this_turn": 0,
            "built_this_turn": 0,
        }

    def _cross_ok(self, cx: int, cy: int) -> bool:
        """十字开局是否合法：五格都在界内、未物化、且都不是自然屏障（高山/海洋）。"""
        size = self.size
        pts = [(cx + dx, cy + dy) for dx, dy in CROSS]
        if any(not (0 <= x < size and 0 <= y < size) for x, y in pts):
            return False
        if any((x, y) in self.tiles for x, y in pts):
            return False
        return all(self.tile_terrain(x, y) not in BARRIER_TERRAINS for x, y in pts)

    def _find_safe_cross(self, cx: int, cy: int):
        """离理想点最近的合法十字起点（main spawn 同款：按距离、再按坐标全序）。"""
        size = self.size
        choices = sorted(((x, y) for x in range(2, size - 2) for y in range(2, size - 2)),
                         key=lambda p: (max(abs(p[0] - cx), abs(p[1] - cy)),
                                        (p[0] - cx) ** 2 + (p[1] - cy) ** 2, p))
        for p in choices:
            if self._cross_ok(*p):
                return p
        return None

    def _place_crosses(self, starts: dict[str, tuple[int, int]]):
        """十字开局：中心 + 上下左右。★ **中心（=本国核心）必然是平原、且自带一座市政厅**——
        用户 2026-09-21 口径「开局默认有个市政厅，在国家核心」＋「中心格必然是平原」；
        它是**国祚**（见 `has_townhall` / `_eliminate_if_dead`）。白送，不花钱、也不受
        `min_slots≥6` 那道门槛约束（那是"自己再盖一座"的门槛）。

        ★ 地形改成平原**只写这一格的 `terrain`**：地块一旦物化，它自己的 `terrain`
        就是权威（`tile_terrain` 先查已物化的格）⇒ 地图/移动代价/防御/建造惩罚
        全都跟着这一处变，不必到处打补丁。理由：核心是国祚所在地，开局就顶着一座
        山地/森林的施工惩罚说不过去（且山地地形防御会把首都变成免费要塞）。
        ★ 2026-11 main 自然边界：理想点落在高山/海洋里时，就近找合法十字（`_find_safe_cross`）。"""
        for nm, (cx, cy) in starts.items():
            if not self._cross_ok(cx, cy):
                safe = self._find_safe_cross(cx, cy)
                if safe is not None:
                    cx, cy = safe
            for dx, dy in CROSS:
                x, y = cx + dx, cy + dy
                if 0 <= x < self.size and 0 <= y < self.size and (x, y) not in self.tiles:
                    self._drop_guardians(x, y)   # 全图野人已预置：新占的格子上的守卫撤走
                    t = self._new_tile(x, y, nm)
                    if dx == 0 and dy == 0:
                        t["terrain"] = "平原"
                        # 资源是**按地形权重**抖出来的 ⇒ 改了地形就得跟着重算，
                        # 否则留下一格"平原产石油"的怪物（见 `MapGen.resources_as`）
                        t["resources"] = self.mapgen.resources_as(x, y, "平原")
                        t["buildings"]["市政厅"] = 1
                    self.tiles[(x, y)] = t
            # 兜底：中心格跑到界外时（畸形 starts）也得有国祚——否则这国一出场就是死的
            if not self.has_townhall(nm):
                self._seed_townhall(nm)

    def _place_ring(self, names: list[str]):
        """各国环状开局（3 国=三角）。"""
        n = len(names)
        c = self.size / 2
        r = self.size * HUNS_RING_RATIO   # 环半径（占地图边长比例，见 balance）
        pts = {}
        for i, nm in enumerate(names):
            ang = -math.pi / 2 + i * 2 * math.pi / n
            pts[nm] = (int(round(c + r * math.cos(ang))), int(round(c + r * math.sin(ang))))
        self._place_crosses(pts)

    def _spawn_guardian(self, x: int, y: int):
        gid, seq = self._new_army("野人")
        aid = x * self.size + y + 1      # main 编号口径：格号即野人号（可复现）
        self.armies.append({"id": seq, "gid": gid, "aid": aid, "name": f"野人{aid}",
                            "hp": ARMY_MAX_HP, "x": x, "y": y, "owner": "野人",
                            "moved_turn": -1, "engaged": False})
        self.guard_once.add((x, y))  # 出生过就算数：这格野人死了不再有

    # 野人按需生成（main 2026-11）：不预铺全图——攻击无主格时才生成守军。
    def _ensure_guardian_at(self, x: int, y: int) -> None:
        """目标格是无主地且从未生过野人 → 生成一支守军（`attack` 调用）。"""
        if self.owned_by(x, y) is not None or (x, y) in self.guard_once:
            return
        if self.tile_terrain(x, y) in BARRIER_TERRAINS:
            return
        if (x, y) in self.guardians:     # 格上已有野人（手造/旧档）⇒ 不重复生成
            return
        self._spawn_guardian(x, y)

    def _drop_guardians(self, x: int, y: int):
        self.armies = [a for a in self.armies
                       if not (a["owner"] == "野人" and (a["x"], a["y"]) == (x, y))]

    # ------------------------------------------------------------- 看海中途加国
    def add_nation(self, name: str, polity: str = "", extra=None,
                   start: dict | None = None, summary=None) -> tuple[bool, str]:
        """看海中途加国：随机到距所有现有领地足够远的位置登场。polity='huns'=匈奴。
        extra=临时注入上下文(塞入正常 system_prompt，20回合后仅剩 summary 小结)；
        summary=20回合后常驻的小结(存进存档)；start=定制开局（如 {"骑":8,"黄金":2000,"补给":300}）。"""
        name = (name or "").strip()
        if not name:
            return False, "需要国名，如 add 匈奴 / add 秦"
        if name in self.nations:
            return False, f"国家 {name} 已存在"
        polity = (polity or "").strip()
        is_huns = polity in ("匈奴", "huns", "hun")
        margin = max(ARRIVE_MARGIN_MIN, self.size // ARRIVE_MARGIN_DIV)
        pos = None
        if self.tiles:
            for _ in range(ARRIVE_ATTEMPTS):
                x, y = self.rng.randrange(self.size), self.rng.randrange(self.size)
                if (all(max(abs(x - px), abs(y - py)) >= margin for (px, py) in self.tiles)
                        and self._cross_ok(x, y)):
                    pos = (x, y)
                    break
        else:
            pos = (self.size // 2, self.size // 2)
        if pos is None:
            pos = (self.rng.randrange(self.size), self.rng.randrange(self.size))
        if pos is None or not self._cross_ok(*pos):
            pos = self._find_safe_cross(*pos) or pos
        self.nations[name] = Nation(name, None)
        self.order.append(name)
        self.mailbox[name] = []
        self.grid_short[name] = False
        self._assign_code(name)
        self._place_crosses({name: pos})
        if is_huns:
            self.apply_polity(name, "huns", home=pos, start=start)
        if extra:
            self.extra_prompt[name] = {"text": str(extra), "until": self.turn + EXTRA_PROMPT_TURNS,
                                       "summary": str(summary or "")}
        desc = ("匈奴" if is_huns else "国家") + f" {name} 登场（距各国至少 {margin} 格）"
        if is_huns:
            pd = POLITY["huns"]
            d0 = pd.get("start", {})
            s = start or {}
            cav = int(s.get("骑", d0.get("骑", 0)))
            gold = int(s.get("黄金", d0.get("黄金", 0)))
            sup = int(s.get("补给", d0.get("补给", 0)))
            r = pd.get("recruit", {}).get("骑", {}) or {}
            short = {"粮食": "粮", "装备": "装", "黄金": "金"}
            rc = "+".join(f"{a}{short.get(k, k)}" for k, a in r.items()) or "—"
            desc += (f"：开局 {cav} 骑兵·金{gold}·补给{sup}"
                     f"·建筑+{pd.get('build_cost_pct', 100) - 100}%惩罚·骑兵征召{rc}"
                     "·不能外交（只可勒索/宣战/逼降/求和）")
        self.log(desc, phase="事件", nation=name)
        return True, desc

    def cheat(self, name: str, **kw) -> tuple[bool, str]:
        """观海作弊补助：直接给某国加资源/骑兵（kw: 黄金/粮食/木头/矿石/石油/装备/补给/骑）。"""
        if name not in self.nations:
            return False, f"国家 {name} 不存在"
        r = self.nations[name].res
        parts = []
        home = self.own_tiles(name)[0] if self.own_tiles(name) else None
        for k, v in kw.items():
            v = int(v)
            if k == "骑" and v > 0 and home:
                for _ in range(v):
                    gid, seq = self._new_army(name)
                    self.armies.append({"id": seq, "gid": gid, "name": army_name(name, seq, "骑"), "type": "骑",
                                        "hp": ARMY_MAX_HP, "x": home[0], "y": home[1],
                                        "owner": name, "moved_turn": -1, "engaged": False})
                parts.append(f"骑+{v}")
            elif k in r:
                r[k] += v
                parts.append(f"{k}+{v}")
        if not parts:
            return False, "没补任何东西（可用 金/粮/木/矿/油/装/补/骑）"
        self.log(f"⚙ 观海补助 {name}：{'、'.join(parts)}", phase="事件")  # 观察者可见
        return True, f"已给 {name} 补助：{'、'.join(parts)}"

    def apply_polity(self, name: str, polity: str, home: tuple[int, int] | None = None,
                     start: dict | None = None) -> None:
        """给一个已存在的国家套政体（目前仅 huns=匈奴）：覆写开局资源 + 骑兵 + 标记。
        start 可定制（如 {"骑":8,"黄金":2000,"补给":300}），缺省 6骑/1000金/200补。"""
        polity = (polity or "").strip()
        if polity not in ("huns", "匈奴", "hun") or name not in self.nations:
            return
        self.polity[name] = "huns"
        start = start or {}
        _def = POLITY.get(polity if polity in POLITY else "huns", {}).get("start", {})
        gold = int(start.get("黄金", _def.get("黄金", 1000)))
        supply = int(start.get("补给", _def.get("补给", 200)))
        cav = int(start.get("骑", _def.get("骑", 6)))
        self.nations[name].res.update({"黄金": gold, "粮食": 0, "木头": 0,
                                       "矿石": 0, "石油": 0, "装备": 0, "补给": supply})
        if home is None:
            own = self.own_tiles(name)
            home = max(own, key=lambda p: sum(1 for n in self.neighbors(*p)
                                              if self.owned_by(*n) == name)) if own else None
        if home:
            cx, cy = home
            for i in range(cav):
                gid, seq = self._new_army(name)
                self.armies.append({"id": seq, "gid": gid, "name": army_name(name, seq, "骑"),
                                    "type": "骑", "hp": ARMY_MAX_HP,
                                    "x": cx, "y": cy, "owner": name,
                                    "moved_turn": -1, "engaged": False})

    # ------------------------------------------------------------- 资源
    def res(self, name: str, key: str) -> int:
        return self.nations[name].res.get(key, 0)

    def add_res(self, name: str, key: str, v: int):
        self.nations[name].res[key] += v

    # ------------------------------------------------------------- 地块建设
    @staticmethod
    def _eff(t: dict) -> dict:
        """有效建筑数 = 已建成 + 在建（用于占位/上限判断）。"""
        b = t["buildings"]
        p = t.get("pending", {})
        return {k: b.get(k, 0) + p.get(k, 0) for k in b}

    def build(self, name: str, x: int, y: int, building: str, *, dry: bool = False) -> tuple[bool, str]:
        """下单建造。造价即扣，但建筑先进入『在建』，回合结算时才落地，下回合起生效。"""
        t = self.tiles.get((x, y))
        if name not in self.nations:
            return False, f"国家 {name} 不存在"
        if t is None or t["owner"] != name:
            return False, "只能在自己的地块上建造"
        if building not in BUILDINGS:
            return False, f"未知建筑：{building}"
        info = BUILDINGS[building]
        b = t["buildings"]
        eff = self._eff(t)
        if t["built_this_turn"]:
            return False, "该地块本回合已下过单（每地块每回合限建 1 座）"
        if sum(eff.values()) >= MAX_SLOTS:
            return False, f"建筑位已满（{MAX_SLOTS} 格，含在建）"
        cr = info["cap_resource"]
        if cr is not None:
            have = t["resources"][cr]
            if have <= 0:
                return False, f"本地无{cr}，无法建{building}"
            if eff[building] >= have:
                return False, f"{building} 已达上限：本地 {cr}={have}"
        if info["kind"] == "castle" and eff[building] >= info["max_level"]:
            return False, f"{building} 已达上限 L{info['max_level']}"
        # 特殊约束（市政厅等）：需该地块已用建筑位达标（含在建）/ 每地块限座
        used_eff = sum(eff.values())
        if info.get("min_slots") and used_eff < info["min_slots"]:
            return False, f"{building} 需该地块已用建筑位 ≥{info['min_slots']}（现 {used_eff}），先建满再盖"
        if info.get("limit") and eff[building] >= info["limit"]:
            return False, f"{building} 已达上限（每地块 {info['limit']} 座）"
        if info.get("limit_nation") and self.diplo_built.get(name, 0) >= info["limit_nation"]:
            return False, f"{building} 自建全国限 {info['limit_nation']} 座（已自建过；再要只能从别国手里抢）"
        lv = eff[building]
        cost = info["cost"][lv] if info["kind"] == "castle" else info["cost"]
        label = f"城堡L{lv+1}" if info["kind"] == "castle" else building
        bp = TERRAIN_STATS[t["terrain"]]["build_penalty"]   # 地形施工惩罚（只上浮金价，木材不变）
        if bp:
            cost = cost * (100 + bp) // 100
        disc = ""
        if t["buildings"].get("工程院") and building != "工程院":
            _disc = building_effect("工程院", "build_discount")   # 只认**已落成**的（本格有它）
            cost = cost * (100 - _disc) // 100
            disc = f"，工程院-{_disc}%"
        if self.polity.get(name) == "huns":
            # 政体建造惩罚（数值在 balance.POLITY，乘算：不擅建设，靠抢）
            cost = cost * self.polity_rule(name, "build_cost_pct", 100) // 100
        wood = info["wood"]
        if self.res(name, "黄金") < cost:
            return False, f"黄金不足：{label} 需 {cost}，国库 {self.res(name,'黄金')}"
        if self.res(name, "木头") < wood:
            return False, f"木材不足：{label} 需 {wood}，储备 {self.res(name,'木头')}"
        if dry:                         # 只校验不执行（RL 的「可执行」特征）
            return True, "可建"
        self.add_res(name, "黄金", -cost)
        self.add_res(name, "木头", -wood)
        led = self._ledger(name)        # 经济报表：投资=实付金 + 木×当时市价（含地形/工程院/匈奴修正后的真价）
        led["invest_gold"] += cost
        led["invest_wood_value"] += self._mvalr(led, "invest_wood_value", "木头", wood)
        self._spend(name)["build"] += cost + self._mvalr(self._spend(name), "build", "木头", wood)   # 总消费：建造
        t["pending"][building] += 1  # 在建，回合末才落地
        t.setdefault("pending_paid", {}).setdefault(building, []).append((cost, wood))   # 取消在建按实付退
        t["built_this_turn"] = 1
        if building == "外交中心":
            self.diplo_built[name] = self.diplo_built.get(name, 0) + 1  # 自建名额记账（抢来的不占）
        tile_name = t["name"]
        note = f"，{t['terrain']}施工+{bp}%" if bp else ""
        return True, f"动工 {label}（@{tile_name}{note}{disc}，本回合在建、下回合生效），-{cost}金 -{wood}木"

    def demolish(self, name: str, x: int, y: int, building: str) -> tuple[bool, str]:
        """拆除本国一栋建筑（main 2026-11）：施工中退 50% 材料，已完工**零返还**；
        城堡按等级逐级拆：按名拆时拆掉的总是最高一级（main 每级是一个实例、有更高级时不能拆低级——按名拆恒满足）；
        不恢复本格本期施工配额。"""
        t = self.tiles.get((x, y))
        if t is None or t["owner"] != name:
            return False, "只能拆自己地上的建筑"
        if building not in BUILDINGS:
            return False, f"没有这种建筑：{building}"
        info = BUILDINGS[building]
        cnt = int(t["buildings"].get(building, 0))
        pend = int(t["pending"].get(building, 0))
        if not cnt and not pend:
            return False, f"({x+1},{y+1}) 没有{building}"
        if pend:
            cost = info["cost"] if isinstance(info["cost"], int) else info["cost"][0]
            # main：施工中退实际材料的 50%，**可含半单位**（库存是小数）——不取整
            paid = (t.get("pending_paid") or {}).get(building) or []
            pg, pw = paid.pop() if paid else (int(cost), int(info.get("wood", 0)))
            rg = pg / 2
            rw = pw / 2
            rg = int(rg) if rg == int(rg) else rg
            rw = int(rw) if rw == int(rw) else rw
            t["pending"][building] -= 1
            self.add_res(name, "黄金", rg)
            self.add_res(name, "木头", rw)
            return True, f"取消在建{building}：退金{rg}、木{rw}（施工中退 50%）"
        t["buildings"][building] -= 1
        return True, f"拆除{building}（已完工，零返还）；本格本期施工配额不恢复"

    def recruit(self, name: str, x: int, y: int, n: int = 1, kind: str = "步", *, dry: bool = False) -> tuple[bool, str]:
        t = self.tiles.get((x, y))
        if kind not in UNIT_TYPES:
            return False, f"未知兵种：{kind}（可选：{'、'.join(UNIT_TYPES)}）"
        if name not in self.nations:
            return False, f"国家 {name} 不存在"
        if t is None or t["owner"] != name:
            return False, "只能在自己有兵营/军屯的地块征兵"
        if kind == "民":
            # 民兵走军屯征召：军屯不耗电，不受全国电网停摆影响。
            # 双限额（2026-10-10 起每座军屯 2 支，用户「军屯可以生产和驻守两队民兵」）：
            #   ① 每座军屯每回合 `militia_cap` 支；② **全国民兵总数 ≤ 全国军屯总数×militia_cap**。
            # ★ 三处（这里两处 + `_supply_need` 的免补给覆盖）**都读同一个 effects 值**，
            #   不许谁再写死一个 1 或 2——数值只有一个权威（`balance.BUILDINGS["军屯"]`）。
            _mcap = building_effect("军屯", "militia_cap")          # 每座**能驻**几支
            _mturn = building_effect("军屯", "militia_per_turn")     # 每座**每回合能征**几支
            if t["buildings"]["军屯"] <= 0:
                return False, (f"该地块没有军屯（民兵只能在军屯征召：50金+5粮/支，"
                               f"每军屯每回合{_mturn}支）")
            tile_cap = t["buildings"]["军屯"] * _mturn - t.get("militia_recruited_this_turn", 0)
            if tile_cap <= 0:
                return False, f"本回合该地块民兵征召产能已用完（每军屯 {_mturn} 支/回合）"
            quota = self.nation_building_count(name, "军屯") * _mcap
            alive = sum(1 for a in self.troops if a["owner"] == name and unit_kind(a) == "民")
            cap = min(tile_cap, quota - alive)
            if cap <= 0:
                return False, (f"民兵总数已达军屯编制上限（{alive}/{quota} 支）："
                               f"军屯即民兵编制（每座可驻 {_mcap} 支）——想扩编先建军屯，"
                               f"阵亡或遣散（disband）后方可补员")
        else:
            if self.grid_short.get(name):
                return False, "全国电网不足，高级建筑（含兵营）停摆，无法征兵"
            if t["buildings"]["兵营"] <= 0:
                return False, "该地块没有兵营"
            cap = t["buildings"]["兵营"] * building_effect("兵营", "recruit_cap") - t["recruited_this_turn"]
            if cap <= 0:
                return False, "本回合征召产能已用完（每兵营 1 支/回合）"
        n = min(n, cap)
        cost = self.recruit_cost(name, kind)
        n = min(n, min(self.res(name, f) // amt for f, amt in cost.items()))
        if n <= 0:
            return False, "战略储备不足（每支耗 " + "、".join(f"{f}x{a}" for f, a in cost.items()) + "）"
        if dry:                         # 只校验不执行
            return True, f"可征 {n} 支"
        spent = 0.0
        for f, amt in cost.items():
            self.add_res(name, f, -amt * n)
            # ⚠ 国库的「黄金」**就是钱本身**，按面值 1:1 计；不能走 _mval ——
            # _mval 里「黄金」是**地块资源单位**的折算率（1 单位 = 10 金，见 MARKET["黄金"]，
            # 那是给黄金矿场产出用的）。曾经这里一律走 _mval，于是民兵（50 金 + 5 粮）
            # 被记成 ~510 分消费、虚高 10 倍——RL 的「爆民兵」正是吃这个 10 倍系数。
            # 对照同文件 `build`：它一直是 `cost + _mval("木头", wood)`，黄金走面值。
            # 所以这不是两种口径各有道理，是这里跟 build 不一致。
            spent += (amt * n) if f == "黄金" else self._mvalr(self._spend(name), "recruit", f, amt * n)
        self._spend(name)["recruit"] += spent
        for i in range(n):
            gid, seq = self._new_army(name)
            # ★ 新兵**本回合不能行动**（用户 2026-10-12 定案）：把 `moved_turn` 钉成本回合，
            #   等于"已经动过"——移动/进攻/撤退共用这条闸（见 `_reachable` 那几处判定），
            #   下一回合它自然解冻（判据是"== 当前回合"，不是"有没有动过"）。
            self.armies.append({"id": seq, "gid": gid, "name": army_name(name, seq, kind),
                                "type": kind, "hp": unit_max_hp({"type": kind}), "x": x, "y": y,
                                "owner": name, "moved_turn": self.turn, "engaged": False})
        if kind == "民":
            t["militia_recruited_this_turn"] = t.get("militia_recruited_this_turn", 0) + n
        else:
            t["recruited_this_turn"] += n
        return True, f"征召 {n} 支{UNIT_TYPES[kind]['label']} @{t['name']}"

    # ------------------------------------------------------------- 军队
    def _assign_code(self, name: str) -> None:
        """分配国家码（军队全局唯一 gid 的前缀；野人固定 0）。"""
        if name == "野人":
            self.nation_code.setdefault("野人", 0)
        elif name not in self.nation_code:
            self.nation_code[name] = self._next_code
            self._next_code += 1

    def _new_army(self, owner: str) -> tuple[int, int]:
        """新军队编号 → (gid, seq)。seq=本国序列，从 1 递增、阵亡不回收（AI 所见与引用即 seq）；
        gid=国家码×1e8+seq，全局唯一但**对 AI 不可见**（仅存档/内部用；野人码 0 → gid==seq）。"""
        seq = self.next_army_seq.get(owner, 0) + 1
        self.next_army_seq[owner] = seq
        return self.nation_code.get(owner, 0) * ARMY_GID_BASE + seq, seq

    def _next_engage_seq(self) -> int:
        """递增的「入场序号」：军队每次 atk 参战领一个新号，用于野地索取顺序。"""
        self._engage_seq += 1
        return self._engage_seq

    def _claim_winner(self, alive: dict[str, list[dict]], *, attackers: set[str] | None = None) -> str | None:
        """该格（野地或敌国）的归属候选：进攻方中「无活敌」者，按入场序号取最早 atk 的
        ——**索取者优先**；索取者已阵亡则顺位给最早入场的同盟者。无候选返回 None。
        attackers=本场战斗的进攻方集合（战斗结算用；此时 engaged 标记可能已被清扫）。
        attackers=None 时不再筛进攻方，只看「在场且与格上他人无交战」——供「守军尽撤」用。"""
        claim = []
        for F, fs in alive.items():
            if F == "野人":
                continue
            if attackers is not None and F not in attackers:
                continue
            # ★ 已下令撤退的军队**不索取地块**：人都要走了，把地判给一支正在脱离的军队
            #   （甚至全 faction 皆撤 → 格归一个驻军为零的国家）不合理；留下的人才配拿。
            stay = [a for a in fs if not a.get("retreat_to")]
            if not stay:
                continue
            if any(G in alive and G != F and self.war_between(F, G) for G in alive):
                continue
            claim.append(F)
        if not claim:
            return None
        return min(claim, key=lambda F: min((a.get("engage_seq", 10 ** 9) for a in alive[F]
                                             if not a.get("retreat_to")),
                                            default=10 ** 9))

    @property
    def troops(self) -> list[dict]:
        """**非野人**的军队（= 各国军队）——一张现成的名单，省掉"扫全表只为滤掉野人"。

        ★ 为什么要有它（2026-09-16 实测）：野人是地图的静态属性（每个无主格一支），
          一局里通常 1500+ 支，而**绝大多数判定里它们连候选都不是** —— `_mv_wall` 的
          "野地驻军"那条、`nation_armies`、v11 的寻路/编组…… 谓词里都写着 `!= "野人"`，
          却仍要逐条走过那 1500 支。40x40、60 回合量到：全库扫 `armies` 的元素数约 93 万，
          其中 98% 是这种**必然落空**的白扫（这笔开销全部摊在每回合/每次寻路上）。

        ★ **口径**：`[a for a in self.armies if a["owner"] != "野人"]` —— 逐条相同。
          **只许用在谓词本来就把野人排除在外的地方**：`_defs_at` 要拿野人当守军、
          `targeting` 要枚举野人驻军，那些地方不许用。
        ★ **失效判据** = `(id(self.armies), len(self.armies), sum(next_army_seq.values()))`：
          军队的 `owner` **一经创建不再改写**（引擎里没有一处写军队的 `["owner"]` ——
          `["owner"] =` 那两处改的是**地块**），所以名单只在**新建 / 阵亡 / 遣散 / 整表重建**时变，
          而这些事必然动到上面三项里的至少一项：新建 ⇒ 序列号 +1；
          阵亡与**遣散**（`disband`）⇒ 长度变；`load()` 与过滤式重建 ⇒ 列表对象换人。
        ★ 缓存的是**引用**：调用方不许就地改这张表（要改先 `list(...)` 拷一份）。
        ★ 它是**派生量、不进存档** —— 别按"新增字段三步"往 SAVE_KEYS 里写。
        """
        self._army_split()
        return self._troops

    @property
    def guardians(self) -> dict:
        """`{(x, y): 野人军队}` —— 按格查野人，省掉"为了找一支野人扫 1500 支"。

        ★ 为什么敢缓存：**野人从不移动**（它们是地图的静态属性，`_spawn_guardian` 出生后
          只会被 `_drop_guardians` 撤走或在战斗里阵亡），所以这张表只在**野人增减**时失效 ——
          判据与 `troops` 同一把钥匙（id/长度/序列号），而"新建/阵亡/整表重建"三件事
          必然动到它。**国家军队不在这张表里**（它们会移动，缓存就会陈旧）。
        ★ 一个格最多一支野人（`guard_once`：出生过就不再补），所以是"格 → 一支"。
        ★ 用途：`_defs_at`（v11 的战斗评估每回合要问 ~10 次，每次原本都要全表扫一遍）。
        """
        self._army_split()
        return self._guards

    def _army_split(self) -> None:
        """按需重建 `troops` / `guardians`（**一次扫描**建两张表）。

        判据：`(id(self.armies), len(self.armies), sum(next_army_seq.values()))` ——
        推导见 `troops` 的文档（军队 `owner` 不可改写 ⇒ 名单只在建/亡/整表重建时变）。
        惰性：只有真被问到的那一张会付重建成本（两张一起扫，比各扫一遍便宜）。
        """
        arm = self.armies
        key = (id(arm), len(arm), sum(self.next_army_seq.values()))
        if key == self._army_key:
            return
        troops: list[dict] = []
        guards: dict = {}
        for a in arm:
            if a["owner"] == "野人":
                guards[(a["x"], a["y"])] = a
            else:
                troops.append(a)
        self._troops, self._guards, self._army_key = troops, guards, key

    def _army(self, name: str, aid: int) -> dict | None:
        src = self.armies if name == "野人" else self.troops   # 野人不是"国家军队"，见 `troops`
        return next((a for a in src if a["owner"] == name and a["id"] == aid), None)

    def nation_armies(self, name: str) -> list[dict]:
        src = self.armies if name == "野人" else self.troops   # 同上：传"野人"走全表
        return [a for a in src if a["owner"] == name]

    def _defs_at(self, name: str, x: int, y: int) -> list[dict]:
        """这一格上、对 `name` 而言算**敌人**的军队（引擎口径的唯一出处）。

        ★ 2026-09-16：不再全表扫——**野人从不移动**，所以按格查表（`guardians`）；
          国家军队那张表小（几十支），直接扫 `troops`。逐条等价，唯一要守的是**顺序**：
          原写法按 `self.armies` 的列表序产出，而野人恒为该列表的**前缀**
          （`_ensure_guardians` 在建局时一次铺完，此后只会被撤走/阵亡，不会插到国家军队之后），
          所以"先野人、后国家军队（各按列表序）"与原序**逐位相同** ——
          `tests/test_troops.py` 用一份朴素实现逐格对照钉住它。
        """
        owner = self.owned_by(x, y)
        out = []
        if owner is None:                       # 野人只守无主格（已物化的地块上没有野人）
            g = self.guardians.get((x, y))
            if g is not None:
                out.append(g)
        for a in self.troops:
            if (a["x"], a["y"]) != (x, y) or a["owner"] == name:
                continue
            if self.war_between(name, a["owner"]):
                out.append(a)
        return out

    def _blind_cost(self, name: str, armies: list[dict], x: int, y: int) -> None:
        """向**视野外**的目标格下令、撞上目标格上的规则墙（中立领土/敌境空格/
        敌军驻守/第三方打野）→ 参令军队本回合移动额度**照样烧掉**。
        报错本身如实返回——那就是斥候带回的情报，侦察付了钱就要拿得到货；
        要付的是钱：对看不见的地方滥发命令，每一发都值一支军队一回合的腿。
        视野内撞墙不额外罚（你看得见，试错是正常决策，报错免费）。"""
        if self.visible_to(name, x, y):
            return
        for a in armies:
            a["moved_turn"] = self.turn

    def move(self, name: str, aid: int, x: int, y: int) -> tuple[bool, str]:
        a = self._army(name, aid)
        if a is None:
            return False, f"军队 {aid} 不存在"
        if a.get("engaged"):
            return False, f"{a['name']} 交战中，先 retreat 撤出"
        # 交战地中的军队（含防守方）不能直接 mv 撤离——撤出走 retreat（回合末随战斗结算后脱离）
        if any(d["owner"] != a["owner"] and d["owner"] != "野人" and d.get("engaged")
               and (d["x"], d["y"]) == (a["x"], a["y"]) and self.war_between(a["owner"], d["owner"])
               for d in self.troops):        # 谓词排除野人 ⇒ 只扫国家军队
            return False, f"{a['name']} 所在格正在交战，不能直接 mv 撤离；撤出请用 retreat（回合末随战斗结算后脱离）"
        try:
            self._check(x, y)
        except IndexError as e:
            return False, str(e)
        if a.get("moved_turn") == self.turn:
            # 教学式话术：说清"它这回合不能再动"且**下一步该做什么**（别让它反复试同一支军）
            return False, (f"{a['name']} 本回合已移动过（每军每回合只挪一次），这回合不能再动；"
                           f"换一支还能动的军，或等结算后下回合——名单见 query panel=army 的「可行动」")
        # ★ 目标格本身的墙先判（与旧口径一致：视野外撞墙 → 报错照给、**额度照烧**，侦察要付钱）。
        #   然后才是"走不到"（地形代价/中途被挡）——那一条**不烧额度**（旧版的射程不够也不罚）。
        why = self._mv_wall(name, x, y)
        if why:
            self._blind_cost(name, [a], x, y)
            # 城堡公开（2026-09-19）：这里之所以只在**调用点**补、不写进 `_mv_wall`，
            # 是因为 `_mv_wall` 在 `_reachable` 的逐格 BFS 热路径上——往里加
            # `visible_to`（O(全表)）会把寻路拖垮。
            _cl = self.visible_buildings(name, x, y).get("城堡", 0)
            return False, why + (f"（该格城L{_cl}）" if _cl else "")
        if (x, y) not in self._reachable(name, a):
            return False, self._unreachable_msg(a, x, y, for_attack=False)
        # mv 只挪位置，不占地——占地走 atk
        a["x"], a["y"] = x, y
        a["moved_turn"] = self.turn
        # ★ 落点是**无主地**时把话说死（用户 2026-10-07，实盘秦）：
        #   `move` 的描述里写着「野地可直接走进/穿过」，`attack` 的描述里写着「格上无任何
        #   军队则直接进驻占领」——**两句长得像、后果相反**。秦 把前者读成了"走进就是占下"，
        #   自称「本回合实证 mv 直接进驻即可」，两回合铺了 30 多次 mv、**国土一块没多**，
        #   小结里却写「魏 48 块无主地已收大部分」。
        #   而回执原样是「军队8 移防 (4,8)」——中性，发十六条也读不出问题。
        #   按项目惯例（教学式回执，见 `_mv_wall` 的 docstring：光说"不行"会让它换个姿势
        #   再撞），在**它形成错误信念的那一刻**把话说死。只加在无主地：自家/盟国格不存在
        #   这个误解，不必白占 token。
        if self.owned_by(x, y) is None:
            return True, (f"军队{a['id']} 移防 ({x+1},{y+1})"
                          "（**未占地**：mv 只挪位置，这一格**还是无主地**；"
                          "要占它得用 atk）")
        return True, f"军队{a['id']} 移防 ({x+1},{y+1})"

    def attack(self, name: str, aids: list[int], x: int, y: int) -> tuple[bool, str]:
        """atk = 一次『进军占地』：派军队进目标格——
        有守军(野人/敌国军)就交战（打赢后按索取顺序占地）；格上**无任何军队**才直接进驻占领（空城/无主空地），
        他国领土上有非敌军队（中立/第三方）则不能进驻；**野地例外**——和平驻守的第三方不参战、不占地，
        清场后直接进驻（驻守者回合末被遣返）。野地上有「非敌非盟」的一方正在打野时不能插足。
        多势力同时开战各打各的敌人。mv 只挪位置不占地；占地一律走 atk，没有特例。"""
        try:
            self._check(x, y)
        except IndexError as e:
            return False, str(e)
        targets = [a for a in self.armies if a["owner"] == name and a["id"] in aids]
        if not targets:
            return False, f"未找到我方军队 {aids}"
        # ★ 目标格上的"墙"与 mv 同规：视野外撞墙 → 报错如实，但突入军队本回合额度照烧。
        owner = self.owned_by(x, y)
        why = None
        if owner is not None and (owner == name or self.allied_between(name, owner)):
            # ★ 教学式（2026-09-20 实测赵 连续 5 次 atk 自家地）：说清"这格本来就是你的"，
            #   给出正确动作，免得它换个编队继续撞。
            here = [a["name"] for a in self.troops
                    if (a["x"], a["y"]) == (x, y) and a["owner"] == name]
            tile = self.tiles.get((x, y)) or {}
            tname = tile.get("name", "?")
            why = (f"({x+1},{y+1})「{tname}」已经是{('你' if owner == name else '你盟国')}的地，"
                   f"**不用进攻**"
                   + (f"——{('、'.join(here))} 已经在格上，算已进驻" if here else "")
                   + "。要让军队过去：**用 mv**（自家/盟国/无主地都能进）；"
                     "想看各军在哪、谁还能动：query panel=army")
        elif owner is not None and not self.war_between(name, owner):
            why = "中立不可攻击他国领土"
        else:
            # 野地上别人正在打野（交战方与你既非敌也非盟）→ 不能插足抢地：
            # 这是「不抢别人的战斗」——中立打野时你不能 atk；盟友/敌人在打野则可以参战
            # （都按索取顺序占地）。想旁观仍可 mv 过去（不参战）。
            busy = [a for a in self.troops
                    if (a["x"], a["y"]) == (x, y) and a.get("engaged") and a["owner"] not in ("野人", name)]
            if owner is None and busy and not any(self.war_between(name, a["owner"]) or self.allied_between(name, a["owner"])
                                                  for a in busy):
                other = busy[0]["owner"]
                why = (f"({x+1},{y+1}) 有 {other}军正在打野（与你非交战也非盟友），"
                       f"不能插足抢地——等这场战斗打完再 atk（想插手就先向 {other} 宣战）；"
                       f"旁观可以 mv 过去（不参战）")
        if why:
            self._blind_cost(name, targets, x, y)   # 视野外撞墙：报错照给，突入军队的移动额度照烧
            return False, why
        if owner is None:
            self._ensure_guardian_at(x, y)          # 野人按需生成：这一格第一次被打才出生
        defs = self._defs_at(name, x, y)
        for a in targets:
            if a.get("engaged") and (a["x"], a["y"]) != (x, y):
                return False, (f"{a['name']} 正在交战中，不能离开战场改攻他处；"
                               f"想脱战先 retreat 军队id 目标格（会挨守军一击）")
            # ★ atk 也**逐格**走：隔着山/隔着别人的地界就冲不进去（旧版是 5×5 直取）
            if (a["x"], a["y"]) != (x, y) and (x, y) not in self._reachable(name, a, for_attack=True):
                return False, self._unreachable_msg(a, x, y, for_attack=True)
            if (a["x"], a["y"]) != (x, y) and a.get("moved_turn") == self.turn:
                return False, (f"{a['name']} 本回合已移动过（每军每回合只动一次），不能再冲；"
                               f"换一支「可行动」的军，或等结算——名单见 query panel=army")
        for a in targets:
            if (a["x"], a["y"]) != (x, y):
                a["x"], a["y"] = x, y
                a["moved_turn"] = self.turn
        ids = "、".join(f"{a['name']}" for a in targets)
        if defs:
            for a in targets:
                a["engaged"] = True
                a["engage_seq"] = self._next_engage_seq()  # 野地索取顺序：谁先 atk 谁号小
            who = "野人" if defs[0]["owner"] == "野人" else f"{defs[0]['owner']}军"
            _cl = self.visible_buildings(name, x, y).get("城堡", 0)
            _fort = f"（该格城L{_cl}，守方吃它的减伤）" if _cl else ""
            # ★ 打**视野外**的格是合法的（这里只查规则墙与可达性，没有视野闸），而引擎
            #   照收那格地形/城堡的减伤 —— 但按视野门禁这里报不出城堡。所以必须**明说
            #   "你在盲战"**：盲战的代价是真的（该吃多少减伤吃多少），缺的只是知情。
            #   不说的话，AI 会以为自己这一拳没吃到任何加成，正好把账算反。
            _blind = "" if self.visible_to(name, x, y) else \
                "（**盲战**：该格不在你视野内，守军构成与减伤均不可知，结算照常进行）"
            return True, (f"{ids} 冲入 ({x+1},{y+1}) 与{who}交战{_fort}{_blind}，"
                          "之后每回合结算一轮；可 retreat 撤出")
        # 格上还有其他军队但不是你的敌人（中立/盟友，和平驻守）：
        #  · 他国领土 → 不能进驻（旧规：中立地不进门）；
        #  · 野地（无主）→ 和平驻守不产生任何权利、也不构成障碍：atk 只打野人/敌人，
        #    清场后直接进驻占地，驻守的第三方被挤走（回合末自动遣返）。
        squatters = sorted({a["owner"] for a in self.armies
                            if a["owner"] != name and a["hp"] > 0 and (a["x"], a["y"]) == (x, y)})
        if squatters and owner is not None:
            return False, (f"({x+1},{y+1}) 有他国军队但并非你的敌人（中立/第三方），"
                           f"不能直接进驻；只能攻击敌人或占领无任何守军的空地")
        # 格上无守军/敌人 → atk 进驻即占
        _ok, cmsg = self._conquer(x, y, name, "进驻占领", log_it=False)
        nm2 = self.tiles[(x, y)]["name"]
        self.log(f"{name} {ids} 进驻 ({x+1},{y+1})，{cmsg}", phase="领土", nation=name, x=x, y=y,
                 parties=[owner] if owner and owner != name else None,   # 同上：失主必看
                 lost_by=owner if owner and owner != name else None)
        note = (f"（{'、'.join(squatters)}军未参战，回合末自动遣返）" if squatters else "")
        return True, f"{ids} 进驻 ({x+1},{y+1})，敌人为 0，{cmsg}{note}"

    def _retreat_legal(self, name: str, x: int, y: int) -> bool:
        """撤退合法点：无人荒地 / 己方领土 / 同盟领土（中立与敌国格都不行）。
        ★ 无人荒地上有敌（交战中）军队驻守 → 也不行——与 mv 的"野地有敌军→只能 atk"同口径，
        否则能以"撤退"名义免费将军队空投进敌脚（同格不交战，下回合被围歼）。
        己方/同盟格上有混战敌军仍放行（那是增援，mv 同样允许）。
        ★ 高山/海洋不可通行（main 的 `_pass`）：之前这里不查地形，军队能"撤"进海里。"""
        if self.tile_terrain(x, y) in ("高山", "海洋"):
            return False
        o = self.owned_by(x, y)
        if o == name:
            return True
        if o is not None:
            return self.allied_between(name, o)
        return not any(a["owner"] != name and a["owner"] != "野人"
                       and (a["x"], a["y"]) == (x, y) and self.war_between(name, a["owner"])
                       for a in self.troops)

    def retreat(self, name: str, aid: int, x: int, y: int) -> tuple[bool, str]:
        """撤出：与 mv/atk 同一个『每回合一次移动』额度。
        交战中的军队（含防守方守军）都能用；撤退固定只能退相邻 1 格（3×3，所有人，不按兵种速度）；
        目标限 己方/同盟/无人荒地（中立与敌国格都不行）；四周没有合法撤退点则不能撤退。
        撤退不立刻结算：军队留在战场参与本回合末的战斗结算（伤害全场分摊；防御方撤退减伤
        RETREAT_DEF_COVER%），结算后自动脱离到目标格——避免『每撤一支各吃一次全额』的灾难。"""
        a = self._army(name, aid)
        if a is None:
            return False, f"军队 {aid} 不存在"
        # ★ 攻守角色一律读唯一口径 `battle_sides`（从前这里与 `_resolve_battles` 各写一遍，
        #   一处排除 hp≤0、一处不排除，会静默漂开）。
        sides = self.battle_sides(a["x"], a["y"])
        # 交战判定：①**本军自己**挂着 engaged（逐军语义——故意不用 "name ∈ attacker"，
        #   那会新开能力：同格我军 X 军 engaged、Y 军没 engaged 时，今天 Y 撤不了，换掉就能撤）；
        #   ②本军所在格上我方是**挨打方**（有人打我）。
        in_battle = bool(a.get("engaged")) or bool(sides and name in sides["defending"])
        if not in_battle:
            return False, f"{a['name']} 未在交战中，无需撤退"
        try:
            self._check(x, y)
        except IndexError as e:
            return False, str(e)
        if (a["x"], a["y"]) == (x, y):
            return False, "撤出需选一个不同的格"
        if max(abs(a["x"] - x), abs(a["y"] - y)) > RETREAT_RANGE:
            return False, "撤退固定只能退相邻 1 格（3×3），超出范围"
        # 没有合法撤退点则不能撤退（目标限 己方/同盟/无人荒地）
        if not any(self._retreat_legal(name, nx, ny)
                   for nx, ny in self.neighbors(a["x"], a["y"])):
            return False, "四周没有合法撤退点（己方/同盟/无人荒地），无法撤退"
        if a.get("moved_turn") == self.turn:
            return False, f"{a['name']} 本回合已移动/进攻过，移动额度用尽，撤不出（下回合再撤）"
        if not self._retreat_legal(name, x, y):
            return False, "不能撤到敌国或中立国的格子；只能撤向 己方/同盟/无人荒地"
        # 撤退不立刻结算：标记 retreat_to 留在原地，本回合结束时随战斗结算走正常战斗机制
        # （敌方伤害全场分摊，撤退者在场照常吃自己那份；防御方撤退减伤 RETREAT_DEF_COVER%），
        # 结算后自动脱离到目标格（见 resolve_turn 撤退落地）。
        # 防御方减伤：我方在该格「未参战」（不是进攻方）、或本身就是格主 → 守方，撤退减伤
        # RETREAT_DEF_COVER%（谁挨打谁是守方，野地和平驻军同理）；主动进攻方撤退是全额。
        # ★ 资格读 `battle_sides` 的 `soak_elig`——与结算真正用的减伤**同一个来源**。
        defends = bool(sides and sides["soak_elig"].get(name))
        cover = RETREAT_DEF_COVER if defends else 100
        a["retreat_to"] = [x, y]
        a["retreat_cover"] = cover
        # `retreat_role` 仅供**展示**（日志/面板/摘要）——结算只认 `retreat_cover`。
        # 不 derive-from-cover：`RETREAT_DEF_COVER` 是可调数值，若被调成 100，
        # 「cover<100 ⇒ 防御」当场反标签；布尔语义免疫调参。
        a["retreat_role"] = "守" if defends else "攻"
        a["moved_turn"] = self.turn
        return True, (f"{a['name']} 准备撤到 ({x+1},{y+1})（{retreat_note(defends, cover)}）："
                      f"本回合结束时随战斗结算（全场分摊）后自动脱离；结算期间仍在战场")

    def disband(self, name: str, aids: list[int]) -> tuple[bool, str]:
        """遣散：把本国军队**就地解散**（解甲归田）——军队从表里消失，此后再不吃补给、不计军费。

        ★ 三条口径（用户 2026-10-09 拍板）：

          · **不返还**——人、装备、粮一律不退。这不是抠门，是**评分口径**逼出来的：
            排名看「总消费 = 建造 + 征兵 + 军费」，而 `_spend` 只有 `+=`、`_mval` 对负数
            直接返回 0 ⇒ 引擎里**没有任何负向记账入口**。一旦返还装备，就凭空多出一条
            「征兵（记一笔消费）→ 遣散（拿回装备）→ 卖装备（回本）」的零成本闭环，
            把黄金直接换成消费分。不返还则无新增刷分路径。
          · **任意位置**——境内/境外/野地都行。它没有目标格，所以**不用** `_check`
            （坐标校验）/`_reachable`（可达性）/`_blind_cost`（对视野外滥发命令的罚）——
            那三个都以坐标为输入，套用会得出错误语义。孤军深陷敌境时的止损出口，
            代价是整支军队当场没了。
          · **交战中不得遣散**（含被攻击的守方）——这是**硬闸，不是凑口径**：
            `battle_sides` 返回 None ⟺ 该格没有活着的进攻方，所以遣散 `engaged` 军会让
            **整场战斗凭空消失**（比 retreat 更强的免费脱战）；且「弃城即陷」只遍历本回合的
            `war_lines`，遣散最后一个守方会让格子当回合**不被改旗**——即「遣散守军」比
            「守军阵亡」更保地。判据逐字复用 `retreat` 的唯一口径（攻方按逐军 `engaged`、
            守方按逐国 `defending`，那处刻意的不对称别"顺手统一"）。

        ★ 不做的事（与「阵亡/饿毙/亡国清场」那三处删除一致，见 `troops` 文档）：
          不回退 `next_army_seq`（番号口径是**阵亡不回收**，回收会与 AI 已引用的 `#n` 撞号）、
          不记 `_spend`/`flow_out` 流水、不动 `engaged`/`retreat_to`/`moved_turn`。
          亡国只认市政厅 ⇒ 遣散光军队**不亡国**。
        """
        if not aids:
            return False, "没给军队编号。想看自己有哪些军：query panel=army"
        if name not in self.nations:
            return False, f"国家 {name} 不存在"
        # `self.troops` 天然不含野人（野人走 `guardians`）⇒ 野人番号进不了 targets，
        # 「野人不会被遣散」不需要额外判一次。
        targets = [a for a in self.troops if a["owner"] == name and a["id"] in aids]
        if not targets:
            return False, (f"未找到我方军队 {aids}（番号各国独立从 1 编号、且**阵亡不回收**，"
                           f"以 query panel=army 为准）")
        # 先全量校验、再统一动手（同 attack 的两段式）：免得"一半遣散了、一半被拒"的半截状态。
        for a in targets:
            sides = self.battle_sides(a["x"], a["y"])
            if a.get("engaged") or (sides and name in sides["defending"]):
                return False, (f"{a['name']} 正深陷交战（{a['x']+1},{a['y']+1}），不能就地遣散——"
                               f"交战中不许处置军队（遣散会让这场战斗凭空消失）。"
                               f"先用 retreat 撤出战场，下回合再遣散")
        for a in targets:
            self.armies.remove(a)   # ★ 删 self.armies：`self.troops` 是派生**缓存列表**（见其文档）
            self.log(f"⚑ 遣散 {a['name']}（{a['x']+1},{a['y']+1}）：解甲归田，"
                     f"人甲不返还，本回合起不再吃补给、不计军费", phase="内政", nation=name)
        names = "、".join(a["name"] for a in targets)
        return True, (f"已遣散 {len(targets)} 支：{names}——**不返还**任何粮/装备/黄金；"
                      f"本回合起即不再吃补给、不计军费（民兵的编制名额也当场释放）。"
                      f"遣散不亡国，但军队没了就是没了，番号不回收")

    # ------------------------------------------------------------- 战斗
    def _die(self):
        d = self.rng.randint(min(COMBAT_DIE_MOD), max(COMBAT_DIE_MOD))
        return d, COMBAT_DIE_MOD[d]

    @staticmethod
    def _combat_power(atk_total: int, def_pct: int) -> int:
        """atk_total = 该方各军兵种攻击之和（步/骑 50、民兵 25，见 unit_atk）。"""
        return max(1, atk_total * (100 - def_pct) // 100)

    @staticmethod
    def _round_damage(power: int, mod: int) -> int:
        return max(1, power * (100 + mod) // 100)

    @staticmethod
    def _equal_allocation(amount: float, limits: list[float]) -> list[float]:
        """水填充均分（main `Military.equal_allocation` 逐字移植）：每人一份均摊，
        吃不下的（上限用尽者）把余量转嫁给还没满的。"""
        allocated = [0.0] * len(limits)
        active = {i for i, lim in enumerate(limits) if lim > 0}
        remaining = max(0.0, float(amount))
        while active and remaining > 1e-12:
            share = remaining / len(active)
            capped = [i for i in active if limits[i] - allocated[i] <= share + 1e-12]
            if not capped:
                for i in active:
                    allocated[i] += share
                break
            spent = 0.0
            for i in capped:
                take = min(share, max(0.0, limits[i] - allocated[i]))
                allocated[i] += take
                spent += take
                active.remove(i)
            remaining = max(0.0, remaining - spent)
        return allocated

    @staticmethod
    def _spread(dmg: int, units: list[dict]):
        """把伤害**均摊**到这一方的各军头上（main 口径：HP 是小数，不取整）。

        每军的上限 = hp / 撤退减伤比例（cover 100% → 比例 1）；有军被打死时它吃不下的份额
        转嫁给还活着的（水填充，见 `_equal_allocation`）；个人减伤只折算它自己吃到的那份。
        """
        if not units:
            return
        ratios = [a.get("retreat_cover", 100) / 100 for a in units]
        caps = [float("inf") if r == 0 else a["hp"] / r for a, r in zip(units, ratios)]
        shares = World._equal_allocation(dmg, caps)
        for a, sh, r in zip(units, shares, ratios):
            a["hp"] = max(0, a["hp"] - sh * r)

    @staticmethod
    def faction_atk(units: list[dict]) -> int:
        """该方**本回合输出基数** = Σ 各军兵种攻击（`unit_atk`，**与 hp 无关**）。

        撤退中的军输出 −`RETREAT_ATK_PENALTY`%（撤离途中无心恋战），下限 1。

        ★ 这是**基数**，不含骰子修正——掷完骰子那一步是 `_round_damage`。
          面板报"总战力"时必须按它报，并把标签写成「输出基数」，
          否则 AI 会把基数读成"这一轮会打出的伤害"（那还要乘骰子 ±25%）。

        ★ 结算与面板的**唯一出处**：别在面板里重抄这个 `sum`。
        """
        return sum(unit_atk(a) if not a.get("retreat_to")
                   else max(1, unit_atk(a) * (100 - RETREAT_ATK_PENALTY) // 100)
                   for a in units)

    def defense_breakdown(self, x: int, y: int, def_owner: str | None) -> tuple[int, int, int]:
        """该格对 `def_owner` 的防御**三分量**：`(地形%, 城堡%, 合计%)`。

        合计 = 两者**相乘**叠加（`100 - ((100-td)*(100-cd))//100`），不是相加——
        所以「沙漠 −10% × 城堡 L2 +20%」的合计是 12% 而不是 10%，可以小于任一分量。
        负的地形防御（沙漠 −10%）**如实返回**，别夹到 0：那是"守方反而多挨打"。

        城堡分量只在**该格归属就是防御方**时才计（`t["owner"] == def_owner`）——
        非格主的守军（同格第三方守军）只吃地形。

        ★ 结算与面板的**唯一出处**：`_defense_pct` 就是它的 `[2]`；面板要摊开三分量时读它，
        不许自己重算（那会让"面板报的减伤"与"结算真吃的减伤"悄悄漂开）。
        """
        t = self.tiles.get((x, y))
        terrain = t["terrain"] if t else self.tile_terrain(x, y)
        castle = t["buildings"]["城堡"] if (t and t["owner"] == def_owner) else 0
        td = TERRAIN_STATS[terrain]["defense"]
        cd = castle * building_effect("城堡", "defense_per_level")
        return td, cd, 100 - ((100 - td) * (100 - cd)) // 100

    def _defense_pct(self, x: int, y: int, def_owner: str | None) -> int:
        """地块总防御% = 地形与城堡**相乘**叠加。见 `defense_breakdown`（本函数＝它的 `[2]`）。"""
        return self.defense_breakdown(x, y, def_owner)[2]

    @staticmethod
    def _modtxt(mods: dict[str, int]) -> str:
        """每方骰修正的简短文本：如「甲+5% 乙-15%」。"""
        return " ".join(f"{F}{m:+d}%" for F, m in sorted(mods.items())) or "—"

    def battle_sides(self, x: int, y: int) -> dict | None:
        """(x,y) 这一格**当前这一仗**的完整切分 —— 攻守/减伤/输出的**唯一出处**。

        返回 `None` ⟺ 该格没有待结算的战斗（无活军，或没有任何**活着的**进攻方）。

        非 None 时给：
          owner       格主（None = 无主野地）
          forces      {势力: [该格活军…]}   列表序 = `self.armies` 序；含野人、含在野第三方
          attacker    {势力}                有 engaged 军的势力（野人永不在内）
          defending   {势力}                挨打方 = ⋃ 各攻方的敌人
          role        {势力: "攻"|"守"|"旁观"}   旁观 = 在场但既不攻也不挨打
          enemies     {势力: [与之交战的在场势力…]}
          soak_elig   {势力: bool}          **结算减伤资格**：F ∉ attacker 或 F == owner
          soak_pct    {势力: int}           结算**真正用的**数（不符合资格者恒 0）
          soak_parts  {势力: (地形%, 城堡%, 合计%)}  与资格无关的引擎真值
          atk_base    {势力: int}           本回合输出基数（Σ `unit_atk`，撤退军 −80%）

        ★ `forces` 里装的是**军队对象本身**（不是拷贝）——`_spread` 要就地改 hp。

        ★ 这里是「谁是进攻方」的**唯一**判定处，`_resolve_battles` 与 `retreat()` 都读它。
          从前这两处各写一遍（一处排除 `hp <= 0`、一处不排除），对"格上还有没有活着的
          进攻军"可能给出相反答案，而症状是**静默**的：结算按攻方算、撤退却按守方给
          50% 减伤。统一到 `hp > 0`——0 血军是尸体，既不计入输出、也不参与分摊，
          更不该替本方要来"防御撤退"的减伤。
        """
        owner = self.owned_by(x, y)
        forces: dict[str, list[dict]] = {}
        for a in self.armies:
            if (a["x"], a["y"]) != (x, y) or a["hp"] <= 0:
                continue
            if a["owner"] == "野人" and owner is not None:
                continue                      # 野人只守无主格
            forces.setdefault(a["owner"], []).append(a)
        attacker = {F for F in forces if F != "野人"
                    and any(a.get("engaged") for a in forces[F])}
        if not forces or not attacker:
            return None

        def _enemies(F: str) -> list[str]:
            """敌人关系：非野人 = 格上其他交战方 +（自己是进攻方时）无主格野人；野人 = 只打进攻方。"""
            if F == "野人":
                return [G for G in attacker if G != "野人"]
            en = [G for G in forces if G != F and G != "野人" and self.war_between(F, G)]
            if F in attacker and "野人" in forces:
                en.append("野人")
            return en

        enemies = {F: _enemies(F) for F in forces}
        defending = {G for F in attacker for G in enemies[F]}
        # 减伤：未参战的驻军（含野人）挨打时吃本格地形，格主永远算守方
        # （攻击方不吃加成——谁挨打谁是守方）。
        soak_parts = {F: self.defense_breakdown(x, y, F) for F in forces}
        soak_elig = {F: (F not in attacker or F == owner) for F in forces}
        return {
            "x": x, "y": y, "owner": owner,
            "forces": forces, "attacker": attacker, "defending": defending,
            "role": {F: ("攻" if F in attacker else "守" if F in defending else "旁观")
                     for F in forces},
            "enemies": enemies, "soak_elig": soak_elig,
            "soak_pct": {F: (soak_parts[F][2] if soak_elig[F] else 0) for F in forces},
            "soak_parts": soak_parts,
            "atk_base": {F: self.faction_atk(forces[F]) for F in forces},
        }

    def _resolve_battles(self) -> list[str]:
        """每格每回合的多势力交战结算：**进攻方不纯联合**——每方独立只打自己的敌人（互相宣战才互打），
        每方掷自己的骰；野人只守无主格、只打"进攻方"（不打扰和平停驻者）；地形/城堡减伤只给格主/野人；
        同格多方同时出手再统一结算阵亡；占地 = 唯一幸存且野人已清的势力。"""
        lines: list[tuple[int, int, str]] = []  # (x, y, 战报行)——带坐标才进得了事件视野
        engaged = [a for a in self.armies if a.get("engaged") and a["owner"] != "野人"]
        for (x, y) in sorted({(a["x"], a["y"]) for a in engaged}):
            # 格子标记带上**城堡等级**（2026-09-19：城堡公开——凡是报"哪格在打"的地方都带上它，
            # 否则守方靠城减伤，攻方却看不出为什么打不动）。tag 被本格所有战报行复用，
            # 所以这一处改动就让每条战报都带上。
            _t_castle = self.tiles.get((x, y))
            _cl = _t_castle["buildings"].get("城堡", 0) if _t_castle else 0
            tag = f"({x+1},{y+1}){self.ter_char(x, y)}" + (f" 城L{_cl}" if _cl else "")
            # ★ 攻守/减伤/输出全部来自唯一口径 `battle_sides`（见其 docstring）
            sides = self.battle_sides(x, y)
            if sides is None:
                continue
            owner = sides["owner"]
            forces = sides["forces"]
            attacker = sides["attacker"]
            enemies = sides["enemies"]
            soak = sides["soak_pct"]
            # 每方掷自己的骰，同时出手（先算全部伤害再统一施加，允许同归于尽）
            # ★ 骰序与 main 一致：每格按**国名字典序**逐方掷一颗（同 seed 可复现，
            #   且与 main 的"格(x,y)升序 × owner 字典序"消耗序对齐）。
            dmg: dict[str, int] = {F: 0 for F in forces}
            mods: dict[str, int] = {}
            for F in sorted(forces):
                en = enemies[F]
                if not en:
                    continue
                _d, mod = self._die()
                mods[F] = mod
                atk = self.faction_atk(forces[F])   # 撤退中的军 −80% 的输出折扣在这一处
                power = self._round_damage(self._combat_power(atk, 0), mod)
                share = power / len(en)  # 均分给各敌人（腹背受敌则兵力分散）
                for G in en:
                    dmg[G] += max(1, round(share * (100 - soak[G]) / 100))
            for F in forces:
                if not dmg[F]:
                    continue
                units = forces[F]
                self._spread(dmg[F], units)
            for a in list(self.armies):
                if (a["x"], a["y"]) == (x, y) and a["hp"] <= 0:
                    self.armies.remove(a)
            alive = {}
            for F, fs in forces.items():
                fs2 = [a for a in fs if a["hp"] > 0]
                if fs2:
                    alive[F] = fs2
            survivors = [F for F in alive if F != "野人"]
            # 清 engaged：该方在格上已无活敌人 → 脱离战斗
            for F in alive:
                if F == "野人":
                    continue
                if not enemies[F] or not any(G in alive for G in enemies[F]):
                    for a in alive[F]:
                        a["engaged"] = False
            # 占地 / 战报：归属候选 = 进攻方中「无活敌」者，按索取顺序取最早 atk 的（索取者优先；
            # 索取者阵亡则顺位最早入场的同盟者）。野地与敌国同规。
            win = self._claim_winner(alive, attackers=attacker)
            desc_alive = "；".join(f"{F} 余{len(alive[F])}支[{alive[F][0]['hp']}hp]" for F in survivors)
            if owner is None:
                # ---- 野地（无主）----
                # 野人清空 + 有归属候选 → 占地；和平驻守的第三方不占地也不参战（回合末被遣返）。
                if "野人" in alive:
                    if win is not None:
                        fs = alive[win]
                        lines.append((x, y, f"⚔ {win} 仍与野人交战 @{tag}"
                                     f"（余{len(fs)}支[{fs[0]['hp']}hp]，守军未清，占不得）"))
                    else:
                        lines.append((x, y, f"⚔ 攻方全灭 @{tag}，野人仍在（无主地守军未清）"))
                elif win is not None:
                    fs = alive[win]
                    info = f"{win} 余{len(fs)}支[{fs[0]['hp']}hp]"
                    _ok, msg = self._conquer(x, y, win, "进驻")
                    others = [F for F in survivors if F != win and F in attacker]
                    joint = (f"（共占，按索取顺序归 {win}；同场 {'、'.join(others)}）" if others else "")
                    sq = sorted(F for F in survivors if F not in attacker)
                    squeeze = (f"（{'、'.join(sq)}军未参战，回合末自动遣返）" if sq else "")
                    lines.append((x, y, f"⚔ 全歼守军 @{tag}，{msg}（{info}）{joint}{squeeze}"))
                elif any(F in attacker for F in survivors):
                    lines.append((x, y, f"⚔ 多方混战 @{tag}（骰 {self._modtxt(mods)}）：{desc_alive}（战局未定）"))
                elif survivors:
                    lines.append((x, y, f"⚔ 野人已清 @{tag}，但场上只剩未参战的驻军，野地维持无主"))
                else:
                    lines.append((x, y, f"⚔ 同归于尽 @{tag}——此地成无主空地，可直接占领"))
            else:
                # ---- 他国领土：同一套索取顺序（多国共同围攻时，第一个 atk 者优先接管）----
                if win is not None and win != owner:
                    fs = alive[win]
                    info = f"{win} 余{len(fs)}支[{fs[0]['hp']}hp]"
                    ok, msg = self._conquer(x, y, win, "攻陷")
                    lines.append((x, y, f"⚔ 全歼守军 @{tag}，{msg}（{info}）"))
                elif owner in alive:
                    fs = alive[owner]
                    info = f"{owner} 余{len(fs)}支[{fs[0]['hp']}hp]"
                    if any(F in attacker for F in survivors):
                        lines.append((x, y, f"⚔ 守军坚守 @{tag}：{info}，攻方未退"
                                     f"（骰 {self._modtxt(mods)}）"))
                    else:
                        dead = sum(len(v) for F, v in forces.items() if F != owner)
                        lines.append((x, y, f"⚔ 守军坚守 @{tag}：攻方{dead}支全灭，{info}"
                                     f"（骰 {self._modtxt(mods)}）"))
                elif survivors:
                    lines.append((x, y, f"⚔ 多方混战 @{tag}（骰 {self._modtxt(mods)}）：{desc_alive}（战局未定）"))
                else:
                    lines.append((x, y, f"⚔ 同归于尽 @{tag}——城仍在敌手"))
        return lines

    # ------------------------------------------------------------- 占领/灭国
    def _conquer(self, x: int, y: int, by: str, how: str, *, log_it: bool = True) -> tuple[bool, str]:
        self._check(x, y)
        old = self.owned_by(x, y)
        self.guard_once.discard((x, y))
        self._drop_guardians(x, y)
        t = self.tiles.get((x, y))
        if t is None:
            t = self._new_tile(x, y, by)
            self.tiles[(x, y)] = t
            msg = f"{by} {how}拓疆「{t['name']}」({x+1},{y+1}){t['terrain']}"
        elif old is None:
            # ★ **无主故土**（前朝废墟，用户 2026-09-21 口径「剩余领土变成空地，建筑保留，
            #   但是无主」）：格子在、名字在、建筑也在，只是没有主人。
            #   ⇒ **复用这一格，不许 `_new_tile` 重造**——重造会把地名/建筑/资源全洗掉，
            #   等于"建筑保留"这条口径在这个入口上被静默吃掉（`old is None` 曾经只可能
            #   意味着"从没物化过"，现在多了一种）。
            #   无主 ⇔ 没有失主：没有 `lost_by`，也没有 `_return_core`（旧核心主张随亡国作废）。
            # ★★ 但**核心要写**（2026-10-07 修）：这一支原本只改 owner、不写 `core`，于是
            #   同样的"占无主地"在**两条路上给出两种结果**——上面 `t is None` 那条走
            #   `_new_tile`（里面写着 `"core": owner`）⇒ 有核心；这条 ⇒ `core` 留着 `None`。
            #   而 `tiles` 是**惰性物化**的（面板/地图/视野查一次就建）⇒ **谁看过那格**
            #   会改变它将来有没有 core —— 同 seed 两局可能对不上，且静默。
            #   口径对齐开局（「每格 core = owner」）与 `_new_tile`：**无主 ⇒ 没有活着的
            #   失主 ⇒ 核心归占领者**。用途上是必要的：core 唯一的消费者是 `_return_core`
            #   （同联盟同战线的盟友占了你的核心地就归还）；没 core 的地永远不归还。
            #   ⚠ 与"不调 `_return_core`"不冲突：那说的是**没有失主可还**，不是"不记归属"。
            #   ⚠ 占**活着的**他国的地仍不动 core（下面那支）——留给战后 `_snapshot_cores`
            #     按实占重算，那是现有设计。
            t["owner"] = by
            t["core"] = by
            msg = f"{by} {how}「{t['name']}」({x+1},{y+1}){t['terrain']}（无主之地）"
            _loot = " ".join(f"{b}×{n}" for b, n in t["buildings"].items() if n)
            if _loot:
                # 无主的建筑不涉机密（无主＝没有国家需要护着的内政底细）⇒ 可以照报
                msg += f"，得 {_loot}"
        elif old != by:
            t["owner"] = by
            # ★ **地名在前、被动语态**（用户 2026-09-20：「应该显示最近消息，地名(坐标)被x攻占」）：
            #   一条纪事同时喂养三方（攻方、失主、视野内的第三方），所以取**事件视角**——
            #   "「绥湾」(12,20) 被 秦 攻陷" 谁读都对；原先写"秦 攻占「绥湾」"是攻方视角，
            #   失主从自己的近讯里**认不出是自己丢了地**（用户报的「丢地不报消息」）。
            #   末尾点名原属国：失主据此一眼确认"这是我的地"。
            #   ★ 动词只认"攻陷"这一种**真打下来**的说法，其余（`进驻`/`进驻占领`/
            #   `守军尽撤`）一律中性"占领"——`how` 不全是动词，直接套被动会读成
            #   "被秦守军尽撤"；那些是**原因**，同一回合的动作纪事里就写着。
            # 城堡**公开**（2026-09-19）：占领后建筑原样保留，所以要报出缴获了什么要塞。
            # ★ 这条日志是**视野广播**的（同格谁看得见谁就收到），所以只能带公开信息——
            #   城堡可以；兵营/工厂/农田那些若报出去，等于向第三者泄露被占国的内政底细。
            # ★ 市政厅（2026-09-21 起）与城堡同级公开：它是**国祚**（拔光即亡国），
            #   攻城方必须看得出"这一刀砍在国祚上"——否则"我为什么把它打死了"无从知晓
            #   （亡国广播只说结果，不说这一格的价值）。兵营/工厂等内政底细仍照旧瞒着。
            _cl = t["buildings"].get("城堡", 0)
            _th = t["buildings"].get("市政厅", 0)
            _pub = "，".join(x for x in (f"原属 {old}", f"城L{_cl}" if _cl else "",
                                         f"市政厅×{_th}" if _th else "") if x)
            msg = f"「{t['name']}」({x+1},{y+1}) 被 {by} " \
                  f"{'攻陷' if how == '攻陷' else '占领'}（{_pub}）"
            extra = self._return_core(x, y, by)  # 同战线盟友核心领土 → 自动归还
            if extra:
                t = self.tiles[(x, y)]
                msg += extra
        else:
            return False, "已是自己领土"
        if log_it:
            # ★ `parties=[old]`：失主**必看**——按视野快照它可能已经看不到这格了
            #   （那块地是飞地、或失去它之后四周再无自家地），于是"丢了地"这件事
            #   在它的近讯里彻底不存在（用户 2026-09-20 报的第二个洞的极端情形）。
            self.log(msg, phase="领土", nation=by, x=x, y=y,
                     parties=[old] if old and old != by else None,
                     lost_by=old if old and old != by else None)
        # ★ 亡国**不在这里当场判**（2026-10-09 用户拍板「统一到回合末」）：这里只把地易主，
        #   亡国与"全天下强制休战"统一由 `resolve_turn` 收尾的 `_settle_deaths()` 结算。
        #   旧口径是在命令阶段当场亡国——空厅被 `atk` 进驻的那一刻就除名、全世界战线立刻冻结、
        #   余土立刻变无主。后果是**同一个回合里世界被半路改写**：AI 是工具循环、一条条下令的，
        #   它刚拔掉一座空厅，同回合计划好的下一刀就变成"中立不可攻击他国领土"了
        #   （实测复现：秦拔楚最后一座空厅 ⇒ 秦↔齐 的战线也当场消失 ⇒ 秦接着打齐被拒）。
        #   而且"空厅当场 / 有守军等回合末"是不该有的不对称：同一件事落在两个时刻。
        return True, msg

    def has_townhall(self, name: str) -> bool:
        """本国是否还有**已落成**的市政厅 —— 这是**国祚**（用户 2026-09-21 口径）。
        在建的不算：`pending` 里的那笔还没盖起来（同"产出只认已落成"的口径）。"""
        return any(t["owner"] == name and t["buildings"].get("市政厅", 0) > 0
                   for t in self.tiles.values())

    def _seed_townhall(self, name: str) -> str | None:
        """白送一座**已落成**的市政厅，落在"国家核心"。两处用法都叫"给它一条国祚"——
        开局（`_place_crosses`）与**旧档迁移**（`load`）。

        「核心」＝**自家最早物化的那块地**：`_place_crosses` 先建中心、后建四臂，而
        `tiles` 按插入序保存/还原（见 `save`），所以这个次序跨存档稳定。
        ★ 别拿 `t["core"]` 判：那是"首任归属"（战后按实占重算），**开局每一格都等于 owner**，
        认不出首都在哪——拿它挑只会挑到坐标最小的那块。"""
        owned = set(self.own_tiles(name))
        if not owned:
            return None
        pick = next(p for p in self.tiles if p in owned)
        self.tiles[pick]["buildings"]["市政厅"] += 1
        return self.tiles[pick]["name"]

    def _settle_deaths(self) -> list[str]:
        """**回合末统一**判定亡国：厅尽失的国家在此除名（含全世界强制休战、余土变无主）。

        ★ 时序口径（用户 2026-10-09 拍板「统一到回合末」，回答"全球强制和平的结算插在
          回合末还是回合中"）：`_conquer` 只负责地易主，**不**当场判亡国——旧的当场判定会让
          同一个回合里世界被半路改写（AI 是工具循环、逐条下令，它刚拔掉一座空厅，
          同回合计划好的下一刀就"中立不可攻击他国领土"了），而且造成"空厅当场 /
          有守军等回合末"的不对称。**两条路现在都在这里收口**：
          空厅由命令阶段的 `atk` 进驻、有守军的由 `_resolve_battles` 在回合末拔掉。
        返回本回合灭掉的国家名（按 `order` 序；供日志与测试用）。
        """
        dead = [n for n in self.order if n in self.nations and not self.has_townhall(n)]
        for n in dead:
            self._eliminate_if_dead(n)
        return dead

    def _eliminate_if_dead(self, name: str) -> bool:
        """**亡国条件＝一座市政厅都不剩**（用户 2026-09-21 改版；旧口径是"领土尽失"）。

        ★ 现在**只由 `_settle_deaths()` 在回合末调用**（2026-10-09 用户拍板「统一到回合末」）——
          命令阶段拔掉最后一座厅只会让地易主，亡国本身等回合末统一判。别在别处直接调它。

        领土丢光自然也没有市政厅（市政厅盖在地上），所以旧口径是这一条的特例；
        但反过来不成立：**还握着大片土地、市政厅却被拔光的国家照样亡国**——
        这时它的领土**不归任何人**：变成**无主空地**，地上的建筑（含市政厅/城堡/兵营）
        **原样留在原地**，等着谁进驻谁得（`_conquer` 的 `old is None` 分支复用该格）。
        """
        if name not in self.nations:
            return False
        if self.has_townhall(name):
            return False
        # ★ **战斗也要当场停**（用户 2026-10-07：「正在发生的战争必须强制停下」「包括战斗」）：
        #   战线马上要没了，场上不再有"进攻方"这个身份。不清 `engaged` 的话，滞留在原敌方
        #   格上的军队下一回合会被 `_resolve_battles` 判成"唯一幸存者"（没敌人了）⇒
        #   `_conquer("攻陷")` —— **白占一格、顺手清掉守军**（实测复现过：3 秦军 vs 2 韩军
        #   打了一回合，第三国亡国停战，再结算一回合 ⇒ 地归秦、守军消失）。
        #   口径与议和一致（`_do_accept_peace` 那句「各方军队解除交战」）；之后它们是
        #   **非法滞留**，由 `_withdraw_illegal` 按兵种速度遣返回国。
        #   ⚠ **必须跑在"余土变无主"之前**：那一步一执行，亡国者的地块 `owner` 就成了 None，
        #     站在上面的军队会被下面那条"只清国有地"的过滤器漏掉，带着 `engaged` 留在无主地
        #     上——洞还是那个洞（顺序反了就是同一个 bug 换个地方复发，有用例钉着）。
        #   ⚠ 只清**站在国有地上**的：打野人的仗不是"战争"（野人只守无主格），
        #     全天下休战不该把清野地一并掐掉。
        for a in self.armies:
            if a["owner"] != "野人" and self.owned_by(a["x"], a["y"]) is not None:
                a["engaged"] = False
        # 亡国 ⇒ 余土变无主之地（建筑留存）；核心主张随之作废（没有国了，谈何核心）
        orphaned = [t for t in self.tiles.values() if t["owner"] == name]
        for t in orphaned:
            t["owner"] = None
            t["core"] = None
        # ★ 亡国**是公开事实**（`broadcast`）：原先写成 `log(nation=name)`——只有那个
        #   已经不存在、再也不会查询的国家"看得见"，等于谁都不知道（连灭它的那家也不知道，
        #   若它正好在视野外）。同族问题的极端形态（用户 2026-09-20「丢地不报消息」）。
        #   归无主的余土要报出**块数**：那是全世界都能去捡的废墟（有建筑就值钱）。
        tail = (f"余 {len(orphaned)} 块领地沦为无主之地（建筑留在原地，先到先得）"
                if orphaned else "")
        self.broadcast(f"☠ {name} 亡国：市政厅尽失，国祚断绝！{tail}", phase="灭国")
        del self.nations[name]
        # 军队解散
        self.armies = [a for a in self.armies if a["owner"] != name]
        # 关系与外交清场
        # ★★ 2026-10-07 口径（用户拍板）：**「全天下强制休战」字面就是停战**——
        #   一方亡国 ⇒ **现有战线一律当场终止**（不只是与亡国者有关的那几条），
        #   然后给全体现存国家两两压 `FALL_TRUCE_TURNS` 回合（下面的 truce 块）。
        #   语义与 `offer_peace` 完全对齐：**战争结束 + 期限内不得再宣战**。
        #   旧口径只终止与亡国者相关的战线、其余照打，结果是自相矛盾的一幕：
        #   全世界两两"休战至第 N 回合"的同时，别的战线**照打不误**
        #   （实盘 T157 魏/周同日亡国 ⇒ 全天下休战至 167，而韩↔燕 照打、连一次宣战都不用）
        #   ——**"防连环征服"的立意被绕过**：灭国者反而拿到一段"没人能宣战它"的接收窗口，
        #   正在流血的一方却一分钟都没停。
        ended_wars = list(self.wars)
        self.wars = []
        # 因亡国而终结的战争：余方实际持有重算为核心领土
        for w in ended_wars:
            self._snapshot_cores([w["atk"], w["def"]] + list(w["followers"])
                                 + list(w.get("atk_followers", [])))
        others = [w for w in ended_wars if name not in (w["atk"], w["def"])]
        if others:
            names = "、".join(f"{w['atk']}↔{w['def']}" for w in others[:3])
            more = f" 等 {len(others)} 条" if len(others) > 3 else ""
            self.proclaim(f"🕊 **全天下强制休战 {FALL_TRUCE_TURNS} 回合**：{name} 亡国，"
                          f"与它无关的战线也一并终止（{names}{more}）"
                          "——期满各自是中立，要再打，得重新宣战")
        # 联盟清场：盟主亡 → 顺位继承（最早加入的剩余成员）；成员全亡 → 解散
        for bloc in list(self.blocs):
            if name in bloc["members"]:
                was_chief = self.bloc_chief(bloc) == name
                bloc["members"].remove(name)
                if bloc["members"]:
                    if was_chief:
                        bloc["chief"] = bloc["members"][0]
                        self.proclaim(f"👑 {name} 亡国，盟主之位由 {bloc['chief']} "
                                      f"继承（联盟「{bloc['name']}」）")
                else:
                    self.blocs.remove(bloc)
                    self.proclaim(f"💔 联盟「{bloc['name']}」因成员凋零而解散")
        for _v in [v for v in self.votes if self.bloc_by_name(v["bloc"]) is None]:
            self._cancel_vote(_v, "联盟因成员凋零而解散")   # ★ 别静默清票：盟外申请人要收到
        self.truce = {p: u for p, u in self.truce.items() if ent_nation(name) not in p}
        # 附庸清场（main）：亡国者的附庸释放；作为附庸的身份消失
        freed = [x for x, v in self.vassals.items() if v["overlord"] == name]
        for x in freed:
            del self.vassals[x]
        self.vassals.pop(name, None)
        if freed:
            self.proclaim(f"🤝 {name} 亡国，其附庸 {'、'.join(freed)} 恢复独立")
        # ★★ 强制和平 ⇒ **在途的外交事项一律当场作废**（用户 2026-10-11 报的洞：
        #   「强制和平后，还没有敲定的和平条约没有自动作废，可能覆盖风险」）。
        #   这一刀落下时**所有战线已经终止**：在途的求和提议已经无仗可停，留着只会在落地
        #   那一刻把下面的全天下强制休战覆盖成它自己的短休战（防雪球的地基被一纸短约抹掉）；
        #   宣战/议和投票同理——它们的前提（有战线）也没了。见 `_void_pending_treaties`。
        self._void_pending_treaties(f"{name} 亡国、全天下强制休战", all_kinds=True)
        # 一方灭亡 → 强制全天下休战 10 回合（防连环征服滚雪球；已有更长休战则保留）
        until_fall = self.turn + FALL_TRUCE_TURNS
        ents = self.entities()
        for i in range(len(ents)):                      # 实体 ↔ 实体（联盟也在内）
            for j in range(i + 1, len(ents)):
                self.set_truce(ents[i], ents[j], until_fall)
        alive = self.alive()
        for i in range(len(alive)):                     # 国家 ↔ 国家（成员退盟后由它兜底）
            for j in range(i + 1, len(alive)):
                self.set_truce(alive[i], alive[j], until_fall)
        gone = self.drop_pacts_of(ent_nation(name))
        if gone:
            self.proclaim(f"💔 {name} 亡国，其条约随之作废（{'、'.join(gone)}）")
        self.mailbox.pop(name, None)
        # ★ 亡国**不清记忆**（2026-10-08 用户：「结算厅要结算所有国家」）——亡国之君要凭
        #   自己的记忆走进结算厅；删掉就只剩一屋子失忆的君主，整局战绩没有下文。
        #   留下的三样都是**记忆**（长期记忆 / 每回合小结 / 阶段块总结），逐字增长已停止；
        #   清掉的是**在局状态**：`turn_memory` 是"活着接着打"用的逐字缓冲区（也是存档里
        #   最大的一块，单国 ~1.4MB），死了不再需要；`maps`/`plans`/`econ_intel`/`ledger`
        #   同理。`polity` 留（那是身份：匈奴君主的 system prompt 要靠它）。
        self.turn_memory.pop(name, None)
        self.maps.pop(name, None)
        self.gift_pending = [g for g in self.gift_pending if g["from"] != name and g["to"] != name]
        self.map_pending = [m for m in self.map_pending if m["from"] != name and m["to"] != name]
        self.spy_pending = [s for s in self.spy_pending if s["from"] != name and s["to"] != name]
        self.econ_intel.pop(name, None)
        self.ledger.pop(name, None)          # 账本是本期暂态；已出的 econ_reports 留作历史
        self.plans.pop(name, None)
        self.extra_prompt.pop(name, None)     # 在局注入的临时提示；`polity` 留（身份）
        self.mail_pending = [m for m in self.mail_pending if m["to"] != name and m["from"] != name]
        self.peace_offers = [p for p in self.peace_offers if p["a"] != name and p["b"] != name]
        self.proposals = [p for p in self.proposals
                          if p.get("a") != name and p.get("b") != name
                          and p.get("A") != ent_nation(name) and p.get("B") != ent_nation(name)]
        return True

    # ------------------------------------------------------------- 经济报表
    def _ledger(self, n: str) -> dict:
        """取（或新建）该国本期经济账本。投资/贸易/资产从这里按整期出数；
        GDP/军费不读整期值——由 _close_report_period 取**结报回合的增量**
        （run-rate，见 _ledger_runrate_mark），账本怎么攒、首期缺几回合都不影响它们。"""
        led = self.ledger.get(n)
        if led is None:
            led = self.ledger[n] = {**{k: 0.0 for k in LEDGER_FIELDS},
                                    "_since": max(1, self.turn)}
        return led

    def _spend(self, n: str) -> dict:
        """取（或新建）该国总消费账（全期累计，不随报表清零）。"""
        d = self.spend.get(n)
        if d is None:
            d = self.spend[n] = {k: 0.0 for k in SPEND_FIELDS}
        return d

    def spend_total(self, n: str) -> float:
        """该国累计总消费（建造+征兵+军费）——RL 的回报就是这个数的终局值。"""
        return float(sum(self._spend(n).values()))

    def _credit_output(self, owner: str, good: str, amt: float) -> None:
        """生产入账。附庸的每一笔产出**先扣贡**再进自己的库存（main `buildings.produce`：贡率×产出
        + 同一（附庸,宗主,资源）历史余额，向下取整，余数结转），所以本期后续生产链只能用扣后的余量。
        扣下的贡品记到 `_tribute_out`，等全体生产结束后再划给宗主。"""
        v = self.vassals.get(owner)
        if v and amt > 0 and v["overlord"] in self.nations:
            o = v["overlord"]
            key = f"{owner}|{o}|{good}"
            give, rem = divmod(amt * v.get("tribute_percent", self.ORDINARY_TRIBUTE) + self.tribute_carry.get(key, 0), 100)
            if rem:
                self.tribute_carry[key] = rem
            else:
                self.tribute_carry.pop(key, None)
            if give:
                self._tribute_out[(owner, o, good)] = self._tribute_out.get((owner, o, good), 0) + give
                amt -= give
        self.add_res(owner, good, amt)

    def _mvalr(self, store: dict, key: str, good: str, amt: float) -> float:
        """按**当时**价估值并登记「待重估」：main 的经济报表在**结算末（市场结算之后）**按当期收盘价
        给全部流量估值（`ValuationAt = report-stage`），不是按发生时的价。回合末 `_revalue_flows`
        用收盘价把已记入的值改正过来——GDP / 授信额度 / 总消费都因此与 main 同口径。"""
        v = self._mval(good, amt)
        if v and good != "黄金":
            self._reval.append((store, key, good, amt, v))
        return v

    def _revalue_flows(self) -> None:
        for store, key, good, amt, taken in self._reval:
            store[key] += self._mval(good, amt) - taken
        self._reval = []

    def _mval(self, good: str, amt: int) -> float:
        """按当前市价把 amt 单位 good 折成金（黄金按 MARKET['黄金']）。"""
        if amt <= 0:
            return 0.0
        if good == "黄金":
            return amt * MARKET["黄金"]
        return amt * self.prices.get(good, float(MARKET.get(good, 0)))

    def nation_assets(self, n: str) -> float:
        """该国全部建筑的重置成本（造价金 + 木×现价；城堡按已升到的级数累计投入）。
        与 settlement.py 同口径，只是木头用现价——夺来的地同样计入（报表里会注明）。"""
        wp = self.prices.get("木头", float(MARKET["木头"]))
        total = 0.0
        for t in self.tiles.values():
            if t.get("owner") != n:
                continue
            for bname, cnt in t["buildings"].items():
                if not cnt:
                    continue
                info = BUILDINGS[bname]
                if info["kind"] == "castle":
                    total += sum(info["cost"][:cnt])          # 逐级累计，不是 cnt×单价
                else:
                    total += cnt * (info["cost"] + info["wood"] * wp)
        return total

    @staticmethod
    def _growth(cur: float, base: float | None) -> float | None:
        """环比增长率；无上期或上期非正 → None（报表里显示「—」）。"""
        if base is None or base <= 0:
            return None
        return (cur - base) / base

    # 报表口径（2026-09-12 用户定）：GDP / 军费**不平均、不按整期累计**——
    # 只取"结报这一回合"的实际产出增量（run-rate）。投资/贸易/资产仍是整期值。
    _RUNRATE_FIELDS = ("prod_value", "mid_value", "fuel_value", "gold_in", "supply_eaten")

    def _ledger_runrate_mark(self) -> dict:
        """结算开头为每国抓一份 GDP/军费相关字段的快照，供本回合增量（_turn_flows）用。"""
        return {n: {k: self._ledger(n).get(k, 0.0) for k in self._RUNRATE_FIELDS}
                for n in self.alive()}

    def _turn_flows(self, runrate_from: dict) -> dict[str, dict[str, float]]:
        """**本回合**各国账本的增量（GDP/军费口径的五个字段）：{国: {字段: 增量}}。

        结算开头抓的 `runrate_from` 快照（生产/军耗发生之前）与此刻的账本逐字段相减，
        得到"这一回合实际发生了多少"——与报表口径同源：**报表每 REPORT_EVERY 回合用一次，
        央行授信每回合都要用一次**（`gdp_run`），所以抽出来共用，免得两处各写一条公式。
        """
        out = {}
        for n in self.alive():
            led = self._ledger(n)
            s0 = runrate_from.get(n) or {}
            out[n] = {k: led.get(k, 0.0) - s0.get(k, 0.0) for k in self._RUNRATE_FIELDS}
        return out

    @staticmethod
    def _flows_gdp(f: dict) -> float:
        """GDP = 本回合生产增加值（市价，**不含军费**）：采集/工厂产出 + 金矿与市政厅金
        − 中间投入 − 能源燃料。不除天数、不攒期累计——就是当前的产出速率（run-rate）。"""
        return (f.get("prod_value", 0.0) - f.get("mid_value", 0.0)
                - f.get("fuel_value", 0.0) + f.get("gold_in", 0.0))

    def _close_report_period(self, runrate_from: dict,
                             flows: dict | None = None) -> None:
        """把本期账本结成一期快照并清零账本。只在回合结算末尾调用——AI 无手动入口。
        runrate_from：本回合结算开头（生产/军耗发生之前）的账本快照；
        flows：本回合增量（`_turn_flows` 的结果）；不传就现算（口径完全一样，
        留着是为了让单独调用本函数的测试/工具不必先备好 flows）。
        GDP 与军费只反映**本回合**（报表所结算的那一回合）的实际增量。"""
        if flows is None:
            flows = self._turn_flows(runrate_from)
        for n in self.alive():
            led = self._ledger(n)
            start = int(led.get("_since", self.turn - REPORT_EVERY + 1))
            days = max(1, min(REPORT_EVERY, self.turn - start + 1))   # 覆盖回合数（仅供展示）
            f = flows.get(n) or {}
            # GDP = 本回合生产增加值（市价，不含军费）——不除天数、不攒期累计
            gdp = self._flows_gdp(f)
            # 军费 = 本回合军队实际吃掉的补给 × 现价（不看来源：自产/外购一视同仁）
            military = f.get("supply_eaten", 0.0) * self.prices.get("补给", float(MARKET["补给"]))
            invest = led["invest_gold"] + led["invest_wood_value"]      # 整期累计（不 run-rate）
            assets = self.nation_assets(n)
            supply_total = led["prod_value"] + led["import_gold"]
            trade = ((led["export_gold"] + led["import_gold"]) / supply_total
                     if supply_total > 0 else 0.0)
            # 上期快照：首期没有（prev={}）→ 各增长率取 None，报表显示「—」；
            # 用 .get 兜底，避免旧档/损坏数据里缺字段时把异常抛进回合结算
            prev = (self.econ_reports.get(n) or [{}])[-1]
            if not isinstance(prev, dict):
                prev = {}
            snap = {
                "period_end": self.turn, "report_turn": self.turn + 1,
                "period_start": start, "span": days,
                "gdp": round(gdp, 1), "gdp_growth": self._growth(gdp, prev.get("gdp")),
                "military": round(military, 1),
                "military_ratio": round(military / gdp, 4) if gdp > 0 else None,
                "invest": round(invest, 1),
                "invest_growth": self._growth(invest, prev.get("invest")),
                "assets": round(assets, 1),
                "assets_growth": self._growth(assets, prev.get("assets")),
                "export_gold": round(led["export_gold"], 1),
                "import_gold": round(led["import_gold"], 1),
                "supply_eaten": int(led["supply_eaten"]),           # 整期累计（供展示）
                "supply_eaten_turn": int(f.get("supply_eaten", 0.0)),  # 本回合吃掉（军费口径）
                "trade_ratio": round(trade, 4),
            }
            self.econ_reports.setdefault(n, []).append(snap)
            # 公告一条（看海终端可见；该国在【近讯】里也能看到 → 提醒它去 report 查）
            mr = snap["military_ratio"]
            self.log(f"📊 第 {snap['report_turn']} 回合经济报表已生成："
                     f"本回合 GDP {snap['gdp']:.0f} 金、军费占 GDP "
                     f"{f'{mr * 100:.0f}%' if mr is not None else '—'}、"
                     f"总资产 {snap['assets']:.0f}（report 看明细 / report all=true 看趋势）",
                     phase="内政", nation=n)
        self.ledger = {}

    @staticmethod
    def _remove_pair(lst: list, name: str):
        lst[:] = [p for p in lst if name not in p]

    # ------------------------------------------------------------- 回合结算
    def resolve_turn(self) -> dict:
        # 快照本回合起点的账本增量字段：GDP/军费只报"本回合"的实际产出（见 _close_report_period）
        runrate_from = self._ledger_runrate_mark()
        # 0) 刷新每地块每回合配额（main: 行动期提交 → 回合末结算）
        for t in self.tiles.values():
            t["recruited_this_turn"] = 0
            t["built_this_turn"] = 0
            t["militia_recruited_this_turn"] = 0

        # 5.5) 联盟投票逾期未决 → 作废（发起回合的下一回合结束前须决出）
        self._expire_votes()


        # 1) 采集
        prod = {n: {k: 0 for k in ("粮食", "木头", "矿石", "石油", "装备", "补给")} for n in self.alive()}
        plants: dict[str, list] = {n: [] for n in self.alive()}
        factories: dict[str, list] = {n: [] for n in self.alive()}
        maint = {n: 0 for n in self.alive()}
        gold_in = {n: 0 for n in self.alive()}
        for (x, y), t in self.tiles.items():
            owner = t["owner"]
            if owner not in self.nations:
                continue
            b = t["buildings"]
            for bname, cnt in b.items():
                if cnt == 0:
                    continue
                info = BUILDINGS[bname]
                kind = info["kind"]
                if kind == "extract":
                    # 采集类：无投入，按 outputs 产出入储备。
                    # （军屯曾走这条分支屯田产粮，2026-09-18 起不产——它现在是纯民兵编制，
                    #   见 balance.py；这条分支只剩采集建筑。）
                    for g, amt in info["outputs"].items():
                        self._credit_output(owner, g, amt * cnt)
                        prod[owner][g] += amt * cnt
                        self._ledger(owner)["prod_value"] += self._mvalr(self._ledger(owner), "prod_value", g, amt * cnt)
                elif kind == "gold":
                    gain = info["outputs"].get("黄金", 0) * cnt * MARKET["黄金"]
                    self._credit_output(owner, "黄金", gain)
                    gold_in[owner] += gain
                    self._ledger(owner)["gold_in"] += gain
                elif kind == "energy":
                    plants[owner].append((bname, info, cnt))
                elif kind == "factory":
                    factories[owner].append((bname, info, cnt))
                    maint[owner] += cnt
                elif kind in ("barracks", "townhall"):
                    maint[owner] += cnt

        # 2) 电网 + 工厂
        for n in self.alive():
            et = 0
            for bname, info, cnt in plants[n]:
                fuel = info["fuel"]
                batches = cnt
                for f, need in fuel.items():
                    batches = min(batches, self.res(n, f) // need)
                for f, need in fuel.items():
                    self.add_res(n, f, -need * batches)
                    self._ledger(n)["fuel_value"] += self._mvalr(self._ledger(n), "fuel_value", f, need * batches)
                et += batches * info["energy_out"]
            short = et < maint[n]
            self.grid_short[n] = short
            self.energy_report[n] = (et, maint[n], short)
            if not short:
                for bname, info, cnt in factories[n]:
                    batches = cnt
                    for f, need in info["inputs"].items():
                        batches = min(batches, self.res(n, f) // need)
                    if batches == 0:
                        continue
                    for f, need in info["inputs"].items():
                        self.add_res(n, f, -need * batches)
                        self._ledger(n)["mid_value"] += self._mvalr(self._ledger(n), "mid_value", f, need * batches)
                    for g, amt in info["outputs"].items():
                        self._credit_output(n, g, amt * batches)
                        prod[n][g] += amt * batches
                        self._ledger(n)["prod_value"] += self._mvalr(self._ledger(n), "prod_value", g, amt * batches)
                # 市政厅：每座 = effects.gold_base + 该地块已占建筑位(不含自身)×effects.gold_per_slot 金；电网不足即停摆
                for (hx, hy), ht in self.tiles.items():
                    if ht["owner"] != n:
                        continue
                    h = ht["buildings"].get("市政厅", 0)
                    if h:
                        others = sum(ht["buildings"].values()) - h
                        hall_gain = (building_effect("市政厅", "gold_base")
                                     + others * building_effect("市政厅", "gold_per_slot")) * h
                        self._credit_output(n, "黄金", hall_gain)
                        gold_in[n] += hall_gain
                        self._ledger(n)["gold_in"] += hall_gain

        # 2.5) 贡品到账（main：贡品在**全体生产结束后**统一入宗主账，本期不能再参与生产，也不再被抽成）
        for (_s, _o, _g), _give in sorted(self._tribute_out.items()):
            if _give and _o in self.nations:
                self.add_res(_o, _g, _give)
        self._tribute_out = {}

        # 2.9) 外交结算（main `relations` 挂点：生产之后、补给与战斗之前；提交的命令统一重验后生效或退款）
        self.resolve_diplomacy()

        # 3) 军队补给 + 回复（**先算补给、再打架**——用户 2026-10-11 钉死的回合末顺序：
        #    补给了才有血打；饿着肚子打完再回血，等于让『断粮扣血』和『这一拳』互相插队）
        famine = {}
        for n in self.alive():
            ps = self.nation_armies(n)
            # ★ 需求/缺口/每军扣血一律走 `supply_shortfall`——面板要报"缺粮会流多少血"
            #   时读同一个函数，不许自己重抄 `max(1, 35*short//need)`（那又是一处静默漂移源）。
            need, short, per = self.supply_shortfall(n)
            paid = min(need, self.res(n, "补给"))
            self.add_res(n, "补给", -paid)
            self._ledger(n)["supply_eaten"] += paid
            self._spend(n)["supply"] += self._mvalr(self._spend(n), "supply", "补给", paid)   # 总消费：军费
            if short:
                # 缺口按比例分摊：**吃补给的**每军扣 ARMY_STARVE_DAMAGE×缺口/需求（交战中也照扣），
                # 至少 1。★ 2026-10-10 用户：「应该是**依赖补给的军队**一起扣」——原先这里遍历
                # `ps`（全军），于是**驻在自家军屯、这一回合根本没吃补给的民兵也跟着挨饿**：
                # 豁免明明让它不占需求额度，却仍在挨饿名单里，前后自相矛盾。
                # 名单改从 `_supply_fed` 取——与需求同一份判定。
                dead = []
                for a in self._supply_fed(n, ps):
                    a["hp"] -= per
                    if a["hp"] <= 0:
                        dead.append(a)
                for a in dead:
                    if a in self.armies:
                        self.armies.remove(a)
                famine[n] = (short, per, len(dead))
                ps = self.nation_armies(n)
            battle_tiles = {(a["x"], a["y"]) for a in self.armies if a.get("engaged")}
            # 回血（main 2026-11 平均分配模型）：两个前提——本国本回合没断供、所在格不在交战；
            # 正规伤兵共享「装备库存 × 每件 ARMY_HEAL_PER_TURN(30)HP」的池，水填充均分
            # （各封顶 30HP 与缺口），按实际恢复总量 ceil(恢复/30) 扣装备；民兵独立恢复、
            # 免费、不占池。
            if not short:
                healable = []
                for a in list(self.troops):
                    if a["owner"] != n or (a["x"], a["y"]) in battle_tiles:
                        continue
                    cap = min(ARMY_HEAL_PER_TURN, unit_max_hp(a) - a["hp"])
                    if cap <= 0:
                        continue
                    if unit_kind(a) == "民":
                        a["hp"] += cap            # 民兵：免费、独立恢复
                    else:
                        healable.append((a, cap))
                pool = self.res(n, "装备") * ARMY_HEAL_PER_TURN
                alloc = self._equal_allocation(pool, [cap for _a, cap in healable])   # 小数 HP，同 main
                healed = 0.0
                for (a, _cap), got in zip(healable, alloc):
                    if got:
                        a["hp"] = min(unit_max_hp(a), a["hp"] + got)
                        healed += got
                if healed:
                    equip = math.ceil(healed / ARMY_HEAL_PER_TURN - 1e-12)   # ceil(恢复总量/30)，同 main
                    equip = min(equip, self.res(n, "装备"))
                    self.add_res(n, "装备", -equip)
                    self._ledger(n)["heal_value"] += self._mvalr(self._ledger(n), "heal_value", "装备", equip)
                    self.log(f"🩹 {n} 军队回血：{healed}HP，吃装备 {equip} 件（民兵免费）",
                             phase="内政", nation=n)
        for n, (short, per, dead) in famine.items():
            self.log(f"⚠ {n} 补给断粮（缺 {short}，吃补给的每军 -{per}HP）："
                     f"{dead} 支军队饿毙", phase="内政", nation=n)

        # 4) 战争结算
        war_lines = self._resolve_battles()
        for wx, wy, ln in war_lines:
            self.log(ln, phase="战报", x=wx, y=wy)  # 带坐标 → 视野内（含瞭望塔圈）才可见
        flat_lines = [ln for _, _, ln in war_lines]

        # 4.5) 撤退落地：撤退军队已随本轮战斗结算（全场分摊），此刻脱离到目标格
        for a in [a for a in self.armies if a.get("retreat_to")]:
            tx, ty = a["retreat_to"]
            # ★ **先抢存再 pop**：角色/减伤档要在下面三行日志里用，而 pop 与日志之间
            #   隔着 `hp<=0` 判断和三层分支——本函数曾经就是"先 pop 后写日志"才把
            #   攻/防角色丢掉的（谁再往里插一个分支就会再犯一次）。数据跟着军走，
            #   与 pop 的位置无关。
            role, cover = a.get("retreat_role"), a.get("retreat_cover", 100)
            note = retreat_note(role != "攻", cover)
            a.pop("retreat_to", None)
            a.pop("retreat_cover", None)
            a.pop("retreat_role", None)
            if a["hp"] <= 0:
                continue  # 结算中阵亡，撤不成了（战报已记）
            if self._retreat_legal(a["owner"], tx, ty):
                a["x"], a["y"] = tx, ty
                a["engaged"] = False
                self.log(f"{a['name']} 撤到 ({tx+1},{ty+1})，脱离交战（{note}）", phase="战报",
                         nation=a["owner"], x=tx, y=ty)
            else:
                alts = [(nx, ny) for nx, ny in self.neighbors(a["x"], a["y"])
                        if (nx, ny) != (a["x"], a["y"]) and self._retreat_legal(a["owner"], nx, ny)]
                if alts:
                    a["x"], a["y"] = alts[0]
                    a["engaged"] = False
                    self.log(f"{a['name']} 撤退目标格战局生变，改撤 ({alts[0][0]+1},{alts[0][1]+1})（{note}）",
                             phase="战报", nation=a["owner"], x=alts[0][0], y=alts[0][1])
                else:
                    self.log(f"{a['name']} 撤退目标格已不合法且四周无可退点，原地留守（{note}）",
                             phase="战报", nation=a["owner"], x=a["x"], y=a["y"])

        # 4.95) 弃城即陷：本回合发生过战斗的格子，守军全撤走/覆灭后格上只剩唯一一方
        # （且与格主交战）→ 直接改旗。兑现 rules 既定的「守军弃城即陷」，无需再补一刀 atk。
        # ★ sorted：_conquer 会改归属、可触发亡国（改 wars/truce/blocs），
        #   裸 set 迭代序受 hash 随机化 → 同 seed 换进程改旗顺序不同 → 战局分叉。
        for bx, by in sorted({(x, y) for x, y, _ in war_lines}):
            owner = self.owned_by(bx, by)
            if owner is None or owner not in self.nations:
                continue
            holders: dict[str, list[dict]] = {}
            for a in self.armies:
                if (a["x"], a["y"]) == (bx, by):
                    holders.setdefault(a["owner"], []).append(a)
            if owner in holders:
                continue  # 格主守军还在 → 不动
            # 守军尽撤 → 围攻方按索取顺序接管（第一个 atk 者优先；多个互相交战者仍算混战）
            foes = {g: fs for g, fs in holders.items() if g != "野人" and self.war_between(g, owner)}
            g = self._claim_winner(foes)
            if g is None:
                continue
            ok, msg = self._conquer(bx, by, g, "守军尽撤")
            if ok:
                self.log(f"⚔ 守军尽撤 @({bx + 1},{by + 1}){self.ter_char(bx, by)}，{msg}",
                         phase="战报", x=bx, y=by)

        # 4.96) ★ 亡国判定（**回合末统一**，2026-10-09 用户拍板：「当全球强制和平的结算插入
        #   是回合末还是回合中」→ **回合末**）。
        #   · 放在 `_withdraw_illegal` **之前**：亡国会清掉滞留军的 `engaged` 并把余土变无主，
        #     紧接着第 5 步就把它们按兵种速度遣返——与旧时序一致（旧版是战斗结算当场亡国、
        #     然后第 5 步遣返），变的只是**判定时刻**：从"命令阶段当场"挪到"回合末统一"。
        #   · 战果照旧当场可见：地已经易主、日志已经出（`_conquer` 里那几条），
        #     亡国只是不再**半路**改写同回合剩余命令所面对的世界。
        self._settle_deaths()

        # 5) 非法滞留 → 自动遣返（断盟/退盟/停战后必须撤出）
        self._withdraw_illegal()

        # 4.9) 脱离清扫：撤退军已落地离开原格，格上留守者不该再背「交战中」
        cleared = self._clear_disengaged()
        if cleared:
            self.log(f" {cleared} 支军队解除交战（敌军已撤离/覆灭）", phase="战报")


        # 6) 市场：本期净流量进库存、基准漂移、重算下一期报价（main market.settlement）
        # churn 摘要必须在结算前取（settle 清本期成交）
        self._churn_briefs = {n: self.churn_brief(n) for n in self.alive()}
        self.market_settle()
        self._revalue_flows()      # 报表按市场结算后的收盘价估值（main：ValuationAt=report-stage）

        # 6.5) 在建建筑落地（施工 1 回合）：本回合结算不产出，落地后从下回合开始生效
        for t in self.tiles.values():
            p = t.get("pending") or {}
            for k, c in p.items():
                if c:
                    t["buildings"][k] += c
            t["pending"] = {k: 0 for k in BUILDINGS}
            t.pop("pending_paid", None)

        # 6.8) 世界央行：储蓄结息 + 贷款计息/到期强制扣款（开关关着就是空转）
        self._bank_settle()

        # 7) 各国结算摘要（供 agent 看）
        for n in self.alive():
            et, mt, short = self.energy_report.get(n, (0, 0, False))
            parts = [f"{k}+{v}" for k, v in prod[n].items() if v]
            if gold_in[n]:
                parts.append(f"金+{gold_in[n]}")
            fam = f"，⚠断粮缺{famine[n][0]}" if famine.get(n) else ""
            grid = "停摆" if short else f"电{et}/{mt}"
            armies = len(self.nation_armies(n))
            churn = self._churn_briefs.get(n, "")   # 本回合空转（settle 前缓存）
            if churn:
                parts.append(churn)
            self.econ_summary[n] = (
                f"产出 {' '.join(parts) if parts else '无'} | 电网 {grid} | 军队 {armies} 支{fam} | "
                f"国库{self.res(n,'黄金')} 木{self.res(n,'木头')} 补给仓{self.res(n,'补给')}"
            )

        # 7.4) 每回合的 GDP run-rate（央行授信按"**当时**的 GDP"放款，见 World.bank_credit）。
        # 报表每 REPORT_EVERY 回合才结一期，太稀了；这里用与报表**同一条公式**每回合记一份。
        # ★ 必须赶在 7.5 之前算：报表结完会把本期账本清零，之后再来读增量就全是 0 了。
        flows = self._turn_flows(runrate_from)
        self.gdp_run = {n: self._flows_gdp(f) for n, f in flows.items()}   # 不取整：授信额度 = floor(GDP×5)，与 main 同

        # 7.5) 经济报表：每 REPORT_EVERY 回合自动结一期（第 11/21/31… 回合开局可查）
        # 报表是派生数据（坏了不影响世界状态），所以这里兜底：出岔子只跳过本期并记进纪事，
        # 绝不把异常抛进 resolve_turn 拖垮整局（与「不静默」原则一致——日志里看得见）。
        if self.turn and self.turn % REPORT_EVERY == 0:
            try:
                self._close_report_period(runrate_from, flows)
            except Exception as e:
                self.log(f"⚠ 经济报表生成失败，本期跳过：{type(e).__name__}: {e}", phase="内政")

        # 8) 空转追踪**过回合**：把 `churn` 清空，下一回合重新从零累计。
        #    ★ 空转**不是在这里判的**——判在每一次 buy/sell 里（`_record_trade`：成交即比对，
        #      买不提示、随后那笔卖当场提示、再买又提示）。这里只是划"本回合"的界：
        #      不分回合的话，"上回合卖、这回合买"也会被算成倒手——而跨回合分批恰恰是**对的**做法。
        #    生命周期＝行动阶段（一次结算到下一次结算之间），与 flow_in/flow_out（结算内部
        #    累积、`_update_market` 里清）不是一回事。派生暂态、不进存档（存档永远落在结算后）。
        return {"war_lines": flat_lines, "famine": famine}

    def _supply_fed(self, n: str, ps: list[dict]) -> list[dict]:
        """这批军里**这一回合真要吃补给**的那些（同序）。

        **唯一判定处**——需求（`_supply_need`）与断粮扣血（`resolve_turn` 第 4 步）
        都从这里取名单，**不许各写一遍**（曾经扣血走的是"全军"、需求走的是"扣掉免供的"，
        于是免供的军屯民兵也跟着挨饿）。

        豁免只有一条：**民兵驻在自家军屯格**，每座军屯覆盖本格 `militia_cap` 支
        （2026-10-10 起 2）；同格超出覆盖数的、离格的、军屯被夺的，照常吃。
        """
        free: dict[tuple[int, int], int] = {}
        out: list[dict] = []
        for a in ps:
            if unit_kind(a) == "民":
                t = self.tiles.get((a["x"], a["y"]))
                if t is not None and t["owner"] == n:
                    cap = t["buildings"].get("军屯", 0) * building_effect("军屯", "militia_cap")
                    used = free.get((a["x"], a["y"]), 0)
                    if used < cap:
                        free[(a["x"], a["y"])] = used + 1
                        continue
            out.append(a)
        return out

    def _supply_need(self, n: str, ps: list[dict]) -> int:
        """全军每回合补给需求（单位数）：步1/骑2/民1，**只算真要吃的那些**
        （免供的军屯民兵不计——判定见 `_supply_fed`）。"""
        return sum(unit_supply(a) for a in self._supply_fed(n, ps))
        return need

    @staticmethod
    def starve_per_army(need: int, short: int) -> int:
        """缺口 → **每支军**扣多少血：按缺口比例分摊（满额 `ARMY_STARVE_DAMAGE`），至少 1；
        无缺口为 0。★ 公式只此一处，结算与面板都走它。"""
        return max(1, ARMY_STARVE_DAMAGE * short // need) if (short and need) else 0

    def supply_shortfall(self, n: str) -> tuple[int, int, int]:
        """该国本回合的补给账 `(需求, 缺口, 每军扣血)` —— **只看不扣**（供面板/摘要）。

        ★ 三条容易漏的引擎事实，报给 AI 时都要带上：
          · **交战中也照扣**——断粮的军不会因为"正在打仗"就免于流血；
          · 扣血的是**要吃补给的军**（2026-10-10 用户口径：免供——即驻自家军屯的民兵——
            **不在此列**，它们这一回合根本没吃你的补给）；不分在不在交战格；
          · 断粮**或**所在格在交战 ⇒ 那格**本回合不回血**（见 `resolve_turn` 第 4 步）。
        """
        need = self._supply_need(n, self.nation_armies(n))
        short = max(0, need - self.res(n, "补给"))
        return need, short, self.starve_per_army(need, short)

    def industry_upkeep(self, name: str) -> dict[str, int]:
        """该国工业**每回合的额定投料** `{资源: 单位数}`——**只看不扣**（供面板做断料预警）。

        · **能源厂**：`fuel` × 座数（烧 木头 或 石油）；
        · **工厂**（补给厂 / 装备厂）：`inputs` × 座数。
        兵营与市政厅只吃电、不吃料，故不在内；城镇/城堡等也不吃料。

        ★ 口径是**额定需求**，不是"实际会扣掉多少"：实际扣料会被仓库存量截断
          （`resolve_turn` 里那两个 `batches = min(cnt, res//need)`），而这张表要回答的
          恰恰是"仓里够不够"——拿被截断后的结果做预警是循环论证（永远不报警）。
        ★ 与 `supply_shortfall` 同类：**派生量、不进存档**，随 `tiles` 现读现算。
        ★ 使用方（`mp_ai._res_line`）负责说清一件事：**电网停摆时工厂根本不投料**
          （`resolve_turn` 只在 `not short` 时才跑工厂），那时的实际投料只剩电厂的燃料。
        """
        need: dict[str, int] = {}
        for t in self.tiles.values():
            if t["owner"] != name:
                continue
            for bn, cnt in t["buildings"].items():
                if not cnt:
                    continue
                info = BUILDINGS.get(bn)
                if info is None:
                    continue
                for per_map in (info.get("fuel"), info.get("inputs")):
                    for f, per in (per_map or {}).items():
                        need[f] = need.get(f, 0) + per * cnt
        return need

    def _clear_disengaged(self) -> int:
        """脱离战斗清扫：格上已无活敌军的 engaged 军队就地解除交战。
        覆盖两处死角——敌军撤退落地离开原格（留守者傻等下回合结算才解锁）、
        以及任何路径留下的空交战标记。返回解除数。"""
        cleared = 0
        for a in self.armies:
            if not a.get("engaged"):
                continue
            foes = []
            for d in self.armies:
                if d is a or (d["x"], d["y"]) != (a["x"], a["y"]):
                    continue
                if d["owner"] == "野人":
                    if a["owner"] != "野人":
                        foes.append(d)  # 我方与野人交战（野人只接战进攻方）
                    continue
                if d["owner"] != a["owner"] and self.war_between(a["owner"], d["owner"]):
                    foes.append(d)
            if a["owner"] == "野人":
                # 野人只与「交战中的进攻方」为敌，和平停驻者不算
                foes = [d for d in self.armies
                        if d is not a and (d["x"], d["y"]) == (a["x"], a["y"])
                        and d["owner"] != "野人" and d.get("engaged")]
            if not foes:
                a["engaged"] = False
                cleared += 1
        return cleared

    def _withdraw_illegal(self):
        """断盟/停战后身处他国中立领土的军队，每回合按兵种速度朝最近的合法地(本国/盟国)撤
        （步兵 1 格=3×3、骑兵 2 格=5×5，一步步走）。"""
        for n in list(self.alive()):
            legal_tiles = self.own_tiles(n)
            for m in self.alive():
                if m != n and self.allied_between(n, m):
                    legal_tiles += self.own_tiles(m)
            if not legal_tiles:
                continue
            for a in list(self.troops):              # 撤军只可能是国家军队（野人不 retreat）
                if a["owner"] != n or a.get("engaged"):
                    continue
                owner = self.owned_by(a["x"], a["y"])
                if owner is None or owner == n or self.allied_between(n, owner) or self.war_between(n, owner):
                    continue  # 合法
                # 非法：按兵种速度（骑兵 2 格/步兵 1 格）朝最近的合法地一步步走
                tx, ty = min(legal_tiles, key=lambda p: max(abs(p[0] - a["x"]), abs(p[1] - a["y"])))
                moved = False
                for _ in range(unit_speed(a)):
                    best, bd = None, 10 ** 9
                    for nx, ny in self.neighbors(a["x"], a["y"]):
                        if not self._enterable_step(n, nx, ny, forced=True):
                            continue
                        dd = max(abs(nx - tx), abs(ny - ty))
                        if dd < bd or (dd == bd and (nx, ny) < (best or (9 ** 9, 0))):
                            best, bd = (nx, ny), dd
                    if best is None:
                        break
                    a["x"], a["y"] = best
                    moved = True
                if moved:
                    self.log(f"🚶 {n} 军队{a['id']} 自敌境「遣返」撤向合法地（{a['x']+1},{a['y']+1}）", phase="事件", nation=n, x=a["x"], y=a["y"])

    def _enterable_step(self, n: str, x: int, y: int, forced: bool = False) -> bool:
        """军队能否落步到 (x,y)。forced=True 供强制遣返用：军队已非法滞留他国（断盟/停战后），
        只允许落在合法地会把它永远困死，故遣返途中允许踩过中立地，一路走回本国/盟国。"""
        if forced:
            return True
        o = self.owned_by(x, y)
        return o is None or o == n or self.allied_between(n, o) or self.war_between(n, o)

    # ------------------------------------------------------------- 回合推进
    def begin_turn(self) -> int:
        """开始下一回合：投递上一回合发出的信件。返回投递数。"""
        self.turn += 1
        due = [m for m in self.mail_pending if m["arrive"] <= self.turn]
        self.mail_pending = [m for m in self.mail_pending if m["arrive"] > self.turn]
        for m in due:
            box = self.mailbox.get(m["to"])
            if box is not None:
                box.append({"from": m["from"], "text": m["text"], "turn": m["arrive"]})
        for m in due:
            if m["to"] in self.nations:
                self.log(f"📮 {m['to']} 收到 {m['from']} 的信", phase="事件", nation=m["to"])
        # 在途馈赠：下回合到账；收方已亡国则退回
        due_g = [g for g in self.gift_pending if g["arrive"] <= self.turn]
        self.gift_pending = [g for g in self.gift_pending if g["arrive"] > self.turn]
        for g in due_g:
            if g["to"] not in self.nations:
                if g["from"] in self.nations:
                    self.add_res(g["from"], g["good"], g["n"])  # 退回
                continue
            self.add_res(g["to"], g["good"], g["n"])
            self.log(f"🎁 {g['from']} 赠你的 {g['good']}×{g['n']} 到账", phase="事件", nation=g["to"])
        # 在途地图情报：下回合到账
        due_m = [m for m in self.map_pending if m["arrive"] <= self.turn]
        self.map_pending = [m for m in self.map_pending if m["arrive"] > self.turn]
        for m in due_m:
            if m["to"] not in self.nations:
                continue
            store = self.maps.setdefault(m["to"], [])
            store.append({"from": m["from"], "turn": m["arrive"], "text": m["text"]})
            del store[:-KEEP_MAPS]  # 只留最近 N 张图，控体积
            self.log(f"🗺 {m['to']} 收到 {m['from']} 的地图", phase="事件", nation=m["to"])
        # 间谍回报：3回合后盗回目标当前经济情报（含粗略军情数量）+ 地图；目标亡国则任务失败
        due_sp = [s for s in self.spy_pending if s["arrive"] <= self.turn]
        self.spy_pending = [s for s in self.spy_pending if s["arrive"] > self.turn]
        for s in due_sp:
            if s["from"] not in self.nations:
                continue
            if s["to"] not in self.nations:
                self.log(f"🕵 {s['from']} 的间谍回报：目标 {s['to']} 已亡国，情报落空",
                         phase="事件", nation=s["from"])
                continue
            store = self.econ_intel.setdefault(s["from"], [])
            store.append({"from": s["to"], "turn": s["arrive"], "text": self._econ_snapshot(s["to"])})
            del store[:-KEEP_SAVES]  # 只留最近 N 份，控体积
            # 间谍偷来的地图也进 intel（world.maps，与 share_map 同池，留最近 N 张）
            mstore = self.maps.setdefault(s["from"], [])
            mstore.append({"from": f"{s['to']}(间谍)", "turn": s["arrive"],
                           "text": self._map_snapshot(s["to"])})
            del mstore[:-KEEP_MAPS]
            self.log(f"🕵 {s['from']} 的间谍回报了 {s['to']} 的情报与地图",
                     phase="事件", nation=s["from"])
        return len(due)

    # ------------------------------------------------------------- 市场（main 库存引擎）
    def market_price(self, good: str) -> float:
        """本期报价（金/单位，保留一位小数）——**本期一价**，对所有人一致。"""
        return round(self.prices[good], 1)

    def market_inventory(self, good: str) -> int:
        """市场库存（可为负：负库存＝市场欠着货）。"""
        return int(self.market_inv[good])

    def market_reference(self, good: str) -> float:
        """基准库存（报价尺度）：开局 = 名义深度，每期按净流量漂移。"""
        return float(self.market_ref[good])

    def market_depth(self, good: str) -> int:
        """名义深度（基准库存的起点，= 开局库存）。"""
        return int(MARKET_DEPTH[good])

    def _market_level(self, good: str) -> float:
        """按当前库存算本期报价：base × exp(弹性 × (ref−inv)/ref)，夹在数值上下限。"""
        ref = self.market_ref[good]
        gap = (ref - self.market_inv[good]) / ref
        p = math.exp(math.log(MARKET[good]) + MARKET_ELASTICITY * gap)
        return min(max(p, MARKET_MIN_PRICE), MARKET_MAX_PRICE)

    def _market_cash(self, name: str, exact: float, side: str) -> tuple[int, float]:
        """把精确成交额结算成整数金：买 ceil、卖 floor，零头按 owner 累计（carry）。

        防两腿各自 floor/ceil 套利的口径与 main 一致：与怎么拆单无关。
        """
        carry = self.gold_carry.get(name, 0.0)
        if side == "sell":
            total = exact + carry
            gold = int(math.floor(total + 1e-9))
            rem = total - gold
        else:
            total = exact - carry
            gold = max(0, int(math.ceil(total - 1e-9)))
            rem = gold - total
        return gold, (0.0 if rem < 1e-9 else rem)

    def market_walk(self, good: str, n: int, side: str,
                    name: str | None = None) -> tuple[float, float]:
        """沿本期报价逐件计价 n 件：返回 (均价, 精确总额)。

        第 s 件单价 = 报价 × exp(±弹性·s/ref)，s = 该 owner 本期该方向的累计成交量
        （main 口径：别人的成交不影响我的报价；深单自己会把均价推高/压低）。
        买 ×(1+spread/2)、卖 ×(1−spread/2)。
        """
        price = self.prices[good]
        ref = self.market_ref[good]
        vol = self.market_volume.get((name, side, good), 0) if name is not None else 0
        step = MARKET_ELASTICITY / ref
        if step == 0:
            factor = 1 + MARKET_SPREAD / 2 if side == "buy" else 1 - MARKET_SPREAD / 2
            return price * factor, price * factor * n
        if side == "buy":
            up = math.expm1(step)
            units = (math.exp(MARKET_ELASTICITY * vol / ref)
                     * math.expm1(MARKET_ELASTICITY * n / ref) / up)
            total = price * units * (1 + MARKET_SPREAD / 2)
        else:
            down = -math.expm1(-step)
            units = (math.exp(-MARKET_ELASTICITY * vol / ref)
                     * -math.expm1(-MARKET_ELASTICITY * n / ref) / down)
            total = price * units * (1 - MARKET_SPREAD / 2)
        return total / n, total

    def market_quote(self, good: str, n: int, side: str,
                     name: str | None = None) -> tuple[float, int]:
        """试算：不实际成交，返回 (成交均价, 整数总额)。name 给定时含该国 carry。"""
        unit, exact = self.market_walk(good, n, side, name)
        if name is None:
            gold, _ = self._market_cash("__anon__", exact, side)
        else:
            gold, _ = self._market_cash(name, exact, side)
        return unit, gold

    def buy(self, name: str, good: str, n: int) -> tuple[bool, str]:
        if good not in TRADEABLE:
            return False, f"「{good}」不可交易（可交易：{'、'.join(TRADEABLE)}）"
        if n <= 0:
            return False, "数量需为正整数"
        unit, exact = self.market_walk(good, n, "buy", name)
        gold, carry_after = self._market_cash(name, exact, "buy")
        if self.res(name, "黄金") < gold:
            return False, (f"黄金不足：买 {good}×{n}（均价 {unit:.2f}）需 {gold}，"
                           f"国库 {self.res(name,'黄金')}")
        self.gold_carry[name] = carry_after
        self.add_res(name, "黄金", -gold)
        self.add_res(name, good, n)
        key = (name, "buy", good)
        self.market_volume[key] = self.market_volume.get(key, 0) + n
        self.market_trades.append({"owner": name, "good": good, "side": "buy", "n": n,
                                   "gold": gold, "exact": exact, "period": self.market_period})
        self._ledger(name)["import_gold"] += gold   # 经济报表：进口额（外贸占比用）
        return True, (f"购入 {good}×{n}（本期报价 {self.prices[good]:.2f}，含价差均价 {unit:.2f}，"
                      f"实付 {gold}），余{self.res(name,good)}"
                      + self._record_trade(name, good, "buy", n, gold))

    def sell(self, name: str, good: str, n: int) -> tuple[bool, str]:
        if good not in TRADEABLE:
            return False, f"「{good}」不可交易"
        if n <= 0:
            return False, "数量需为正整数"
        if self.res(name, good) < n:
            return False, f"储备不足：{good} 现有 {self.res(name,good)}"
        unit, exact = self.market_walk(good, n, "sell", name)
        gold, carry_after = self._market_cash(name, exact, "sell")
        self.gold_carry[name] = carry_after
        self.add_res(name, good, -n)
        self.add_res(name, "黄金", gold)
        key = (name, "sell", good)
        self.market_volume[key] = self.market_volume.get(key, 0) + n
        self.market_trades.append({"owner": name, "good": good, "side": "sell", "n": n,
                                   "gold": gold, "exact": exact, "period": self.market_period})
        self._ledger(name)["export_gold"] += gold   # 经济报表：出口额
        return True, (f"售出 {good}×{n}（本期报价 {self.prices[good]:.2f}，含价差均价 {unit:.2f}，"
                      f"实收 {gold}），余{self.res(name,good)}"
                      + self._record_trade(name, good, "sell", n, gold))

    # ------------------------------------------------- 市场空转（同回合又买又卖）
    def churn_state(self, name: str, good: str) -> dict:
        """该国**本期**在 good 上的累计成交（买/卖的数量与所付/所收金）。"""
        rows = [t for t in self.market_trades
                if t["owner"] == name and t["good"] == good]
        return {"buy_n": sum(t["n"] for t in rows if t["side"] == "buy"),
                "buy_gold": sum(t["gold"] for t in rows if t["side"] == "buy"),
                "sell_n": sum(t["n"] for t in rows if t["side"] == "sell"),
                "sell_gold": sum(t["gold"] for t in rows if t["side"] == "sell")}

    @staticmethod
    def churn_loss(t: dict) -> tuple[int, float]:
        """(空转量, 空转损益)：空转量 = min(买, 卖)；损益 = 空转量 ×(买均价 − 卖均价)。"""
        c = min(t["buy_n"], t["sell_n"])
        if c <= 0:
            return 0, 0.0
        return c, c * (t["buy_gold"] / t["buy_n"] - t["sell_gold"] / t["sell_n"])

    def churn_note(self, name: str, good: str) -> str:
        """空转提示（人话一句）。没发生空转就返回空串。"""
        t = self.churn_state(name, good)
        c, loss = self.churn_loss(t)
        if not c:
            return ""
        head = (f"⚠ 市场空转：本回合你在 {good} 上又买又卖"
                f"（买 {t['buy_n']} 均价 {t['buy_gold'] / t['buy_n']:.2f}、"
                f"卖 {t['sell_n']} 均价 {t['sell_gold'] / t['sell_n']:.2f}）"
                f"——重叠的 {c} 单位是**纯倒手**")
        if loss >= 0:
            tail = (f"，净亏 {int(round(loss))} 金（一进一出＝白付两趟买卖价差，外加自己推价的冲击）。")
        else:
            tail = (f"，反倒赚了 {int(round(-loss))} 金（市价在你两笔之间被动过）——"
                    "别把它当生意：价差是照付的，长期必亏。")
        return head + tail

    def _record_trade(self, name: str, good: str, side: str, n: int, gold: int) -> str:
        """成交已入 `market_trades`；若由此构成/延续空转，返回提示（前面带换行）。"""
        note = self.churn_note(name, good)
        if note:
            self.log(note, phase="市场", nation=name)
            return "\n" + note
        return ""

    def churn_brief(self, name: str) -> str:
        """结算摘要里的一句本期空转（没有就空串；多商品按损失从大到小，最多列两个）。"""
        rows = []
        goods = {t["good"] for t in self.market_trades if t["owner"] == name}
        for good in goods:
            c, loss = self.churn_loss(self.churn_state(name, good))
            if c:
                amt = (f"亏 {int(round(loss))} 金" if loss >= 0
                       else f"赚 {int(round(-loss))} 金")
                rows.append((loss, f"空转{good}×{c} {amt}"))
        if not rows:
            return ""
        rows.sort(key=lambda r: -r[0])
        return "⚠ " + "、".join(r[1] for r in rows[:2])

    def market_settle(self) -> None:
        """回合末市场结算（main market.settlement）：本期净流量进库存、基准漂移、重算报价。

        库存可负（负＝市场欠货）；Refill=0 ⇒ 外部永不回补（开局库存是唯一一次发货）。
        下一期报价重算；成交/量清空。
        """
        net_buy = {}
        for t in self.market_trades:
            sign = 1 if t["side"] == "buy" else -1
            net_buy[t["good"]] = net_buy.get(t["good"], 0) + sign * t["n"]
        for g in TRADEABLE:
            nb = net_buy.get(g, 0)
            self.market_inv[g] -= nb                       # 净买减库存（可负）
            self.market_ref[g] = max(1.0, self.market_ref[g] + MARKET_FLOW * nb)
            if MARKET_REFILL:
                gap = self.market_ref[g] - self.market_inv[g]
                if gap > 0:
                    self.market_inv[g] += min(math.ceil(gap), math.ceil(gap * MARKET_REFILL))
            self.prices[g] = self._market_level(g)
        self.market_trades = []
        self.market_volume = {}
        self.market_period += 1

    # ------------------------------------------------------------- 世界央行
    # 口径（2026-09-19 用户）：国库现金**默认就是储蓄**（不用存）；观察者设储蓄利率、可为负
    # （负则每回合扣钱，**扣到 0 为止**）；贷款 = 储蓄利率 + BANK_SPREAD（也可为负）；
    # **还清前不能再借**；到期**强制扣款**（这一笔允许扣成负的）。
    # ★ 2026-09-22 授信改革（用户：「银行只能贷款当时 GDP×5 的金，不再要求设置回合，
    #   也不要求金额，默认 10 回合，默认当前 GDP×5」→ 随后改口径「默认 5 回合，
    #   10 回合纯吃利息」）：**固定的 1000 金上限作废**，改按经济规模授信——
    #   额度 = `bank_credit()` = 当前 GDP × BANK_LOAN_GDP_MULT，金额与期限都可省（有默认）。
    def bank_on(self) -> bool:
        return bool(self.bank.get("on"))

    def bank_enable(self) -> bool:
        """[配置开关] 打开世界央行，返回"本次是否真的打开了"。

        ★ 口径（2026-09-19 用户）：「银行**只能在配置文件开、不能关**，**可以中途加**」
        ⇒ 单向：`on` 只允许 false → true。配置说 true 就在本局打开（续局中途开也行）；
        配置说 false **也不会**把已经开着的关掉——一局里边开边关，账目与贷款期限就对不上了。
        """
        if self.bank.get("on"):
            return False
        self.bank["on"] = True
        return True

    def bank_rate(self) -> float:
        """储蓄利率（观察者设，可为负）。"""
        return float(self.bank.get("rate", 0.0))

    def bank_loan_rate(self) -> float:
        """贷款利率 = 储蓄利率 + BANK_SPREAD（可为负 ⇒ 欠款每回合**缩水**）。"""
        return self.bank_rate() + BANK_SPREAD

    def nation_gdp(self, name: str) -> float:
        """该国**当前 GDP**（金/回合）= 上一回合结算记下的 run-rate（`gdp_run`）。

        口径与 `report` 报表里的 GDP 是**同一条公式**（见 `_flows_gdp`），只是每回合都记，
        不像报表那样每 REPORT_EVERY 回合才结一期——央行授信要的是"**当时**的 GDP"。

        旧档兜底：`gdp_run` 缺该国（v4 之前的档、或本回合还没结算过）→ 退回**最新一期
        经济报表的 GDP**；连报表都没有（开局头几回合）→ 0（央行还没看到这个国家的账）。
        """
        if name in self.gdp_run:
            return float(self.gdp_run[name])
        reps = self.econ_reports.get(name) or []
        if reps and isinstance(reps[-1], dict):
            return float(reps[-1].get("gdp", 0.0))
        return 0.0

    def bank_credit(self, name: str) -> int:
        """央行给该国的**授信额度**（金）= 当前 GDP × `BANK_LOAN_GDP_MULT`，向下取整。"""
        return max(0, int(self.nation_gdp(name) * BANK_LOAN_GDP_MULT))

    def bank_set_rate(self, rate: float) -> tuple[bool, str]:
        """[观察者] 设储蓄利率；**变了就全世界播报**。

        播报口径按用户原话：**上调＝抑制通货膨胀、下调＝减少紧缩**，带**变动幅度 + 现值**。
        越界会夹到 [BANK_RATE_MIN, BANK_RATE_MAX]，并在回执里说明夹过。
        """
        if not self.bank_on():
            return False, "本局没开世界央行（mp_config.json 的 world_bank=true 才生效）"
        r = float(rate)
        clamped = max(BANK_RATE_MIN, min(BANK_RATE_MAX, r))
        old = self.bank_rate()
        if abs(clamped - old) < 1e-9:
            return False, f"利率没变（还是 {old:+.1%}）"
        self.bank["rate"] = clamped
        d = abs(clamped - old)
        if clamped > old:
            msg = f"🏦 世界央行公告：为了抑制通货膨胀，上调了 {d:.1%} 利率（现为 {clamped:+.1%}）"
        else:
            msg = f"🏦 世界央行公告：为了减少紧缩，下调了 {d:.1%} 利率（现为 {clamped:+.1%}）"
        if abs(clamped - r) > 1e-9:
            msg += f"（{r:+.1%} 超出可设区间，已夹到 {clamped:+.1%}）"
        self.broadcast(msg)
        return True, msg

    def bank_loan(self, name: str) -> tuple[bool, str]:
        """向世界央行借一笔：现金即刻到账；**还清之前不能再借**（不叠加）。

        ★ 2026-09-22 授信改革（用户：「银行只能贷款当时 GDP×5 的金，不再要求设置回合，
        也不要求金额」→「**改成不能选贷款额和时间**」）⇒ **没有参数可选**，只有一种贷款：
        额度 = 当时 GDP × `BANK_LOAN_GDP_MULT`，期限 = `BANK_LOAN_TURNS`。
        额度只看借款当时的 GDP（上回合产出的 run-rate）——富国的信用上限自己会长，
        穷国想借满 1000 也借不到（这就是"按经济规模授信"的意思）。
        """
        if not self.bank_on():
            return False, "本局没开世界央行（mp_config.json 的 world_bank=true 才生效）"
        if name not in self.nations:
            return False, "借款方必须是现存国家"
        if name in self.bank["loans"]:
            ln = self.bank["loans"][name]
            return False, (f"你在第 {ln['taken_turn']} 回合借的那笔还没还清"
                           f"（到期应还 {ln['due']} 金、还剩 {ln['turns_left']} 回合）——"
                           "还清前不能再借")
        gdp = self.nation_gdp(name)
        credit = self.bank_credit(name)
        cap = (f"贷款额固定 = 你当前 GDP {gdp:.1f} 金/回合 × {BANK_LOAN_GDP_MULT} "
               f"= {credit} 金，期限固定 {BANK_LOAN_TURNS} 回合（都不能自选）")
        if credit <= 0:
            # 央行还没见过你的账：GDP 是"上一回合的产出"，开局没产出的国家就是 0 授信
            return False, (f"央行还没看到你的账：{cap}——GDP 记的是**上一回合的产出**（市价），"
                           "先去建设/扩张，产出过东西才谈得上授信")
        amount, turns = credit, BANK_LOAN_TURNS
        self.add_res(name, "黄金", amount)
        self.bank["loans"][name] = {"principal": amount, "due": amount, "turns_left": turns,
                                    "taken_turn": self.turn, "rate": self.bank_loan_rate()}
        self.log(f"🏦 {name} 向世界央行借款 {amount} 金（{turns} 回合后到期，"
                 f"利率 {self.bank_loan_rate():+.1%}；授信 {credit}）", phase="事件", nation=name)
        return True, (f"已到账 {amount} 金：{turns} 回合后到期，当前利率 "
                      f"{self.bank_loan_rate():+.1%}（= 储蓄 {self.bank_rate():+.1%} + "
                      f"{BANK_SPREAD:.0%}）；到期**强制扣款**，还清前不能再借"
                      f"（{cap}）")

    def bank_sell_report(self, frm: str, to: str, report_turn: int,
                         text: str) -> tuple[bool, str]:
        """[工具] 向世界央行买一份**别国已公布**的经济报表（`BUY_REPORT_COST` 金/次）。

        ★ 卖的是明细不是秘密：每期报表生成时全世界都收到过一行公告（GDP / 军费占 GDP /
        总资产），央行卖的是那张表的全文（投资、外贸、跨期增长…）。所以它跟 `spy` 不冲突——
        `spy` 偷的是**当下**的国库/储备/每块地的建设（100 金、3 回合后到手），
        这里买的是**定期公开的账**（20 金、当场到手）。

        `text` 由调用方（`mp_ai`）用同一套报表渲染器生成——引擎只认钱与库，不认排版。
        **买不到一律不收钱**（没开行 / 不是现存国家 / 买自己 / 国库不足）：扣款在全部校验之后。
        买到手进买家的 `econ_intel`（`query panel=spy` 可重看，与间谍情报同池、同配额）。
        """
        if not self.bank_on():
            return False, "本局没开世界央行（mp_config.json 的 world_bank=true 才生效）——没人在卖报表"
        if frm not in self.nations or to not in self.nations:
            return False, "买卖双方都必须是现存国家"
        if to == frm:
            return False, "买自己国家的报表不用花钱：report 工具直接看（免费）"
        if self.res(frm, "黄金") < BUY_REPORT_COST:
            return False, (f"国库不足：买报表需 {BUY_REPORT_COST} 金，"
                           f"你现 {self.res(frm, '黄金')}")
        self.add_res(frm, "黄金", -BUY_REPORT_COST)
        store = self.econ_intel.setdefault(frm, [])
        store.append({"from": to, "turn": self.turn,
                      "text": f"🏦【央行售出】{to} 第 {report_turn} 回合经济报表\n{text}"})
        del store[:-KEEP_SAVES]          # 与间谍情报同池、同配额（控体积）
        self.log(f"🏦 {frm} 花 {BUY_REPORT_COST} 金从世界央行买下 {to} 第 {report_turn} "
                 f"回合的经济报表（query panel=spy 可重看）", phase="事件", nation=frm)
        return True, (f"✅ 已买下 {to} 第 {report_turn} 回合的经济报表"
                      f"（-{BUY_REPORT_COST} 金，国库 {self.res(frm, '黄金')}）；"
                      f"这份表也进了你的情报库（query panel=spy）。全文如下：\n\n{text}")

    def _bank_settle(self) -> None:
        """每回合末的央行结算：储蓄结息 + 贷款计息/到期强制扣款（开关关着就空转）。"""
        if not self.bank_on():
            return
        r, lr = self.bank_rate(), self.bank_loan_rate()
        for n in self.alive():
            gold = self.res(n, "黄金")
            if r and gold > 0:
                d = int(gold * r)                     # 金是整数，截断取整
                if d < 0 and gold + d < 0:
                    d = -gold                         # ★ 储蓄**扣不到负**（用户口径）
                if d:
                    self.add_res(n, "黄金", d)
                    self.log(f"🏦 {n} 储蓄结息 {d:+d} 金（利率 {r:+.1%}，"
                             f"国库 {self.res(n, '黄金')}）", phase="事件", nation=n)
            ln = self.bank["loans"].get(n)
            if not ln:
                continue
            if lr:
                ln["due"] = max(0, int(round(ln["due"] * (1 + lr))))
            ln["turns_left"] -= 1
            if ln["turns_left"] <= 0:
                pay = ln["due"]
                self.add_res(n, "黄金", -pay)          # ★ 贷款**允许扣成负的**（用户口径）
                self.bank["loans"].pop(n, None)
                self.log(f"🏦 {n} 的央行贷款到期：强制扣款 {pay} 金"
                         f"（本金 {ln['principal']}、利率 {ln['rate']:+.1%}，"
                         f"国库 {self.res(n, '黄金')}）", phase="事件", nation=n)
            else:
                self.log(f"🏦 {n} 的央行贷款计息：应还 {ln['due']} 金、"
                         f"还剩 {ln['turns_left']} 回合（利率 {lr:+.1%}）",
                         phase="事件", nation=n)

    # ------------------------------------------------------------- 信箱
    def send_mail(self, frm: str, to: str, text: str) -> tuple[bool, str]:
        if frm not in self.nations or to not in self.nations:
            return False, "收发双方都必须是现存国家"
        if to == frm:
            return False, "不能给自己写信"
        self.mail_pending.append({"from": frm, "to": to, "text": text, "arrive": self.turn + 1})
        # 信件正文不单独记一条（信件=一次行动，正文已在行动行里）；送达时另有"收到信"事件+收件箱
        return True, f"信已发出，{to} 将于第 {self.turn+1} 回合收到"

    # ------------------------------------------------------------- 神秘人来信（Observer 用）
    def mystery_letter(self, to: str, text: str) -> tuple[bool, str]:
        """Observer 从看海终端给任意国家寄一封『神秘人』来信（下回合到其信箱）。

        发件人恒为「神秘人」，各国 AI 无从判断是谁；只记一条观察者可见的
        日志（nations 收不到），收件人下回合在信箱看到。
        """
        if to not in self.nations:
            return False, f"国家 {to} 不存在"
        text = (text or "").strip()
        if not text:
            return False, "神秘来信内容不能为空"
        self.mail_pending.append({"from": "神秘人", "to": to, "text": text,
                                  "arrive": self.turn + 1})
        self.log(f"🕵️ 神秘人来信 → {to}：{text}", phase="事件")  # 观察者可见，各国近讯收不到
        return True, f"神秘人来信已寄给 {to}，将于第 {self.turn+1} 回合送达其信箱"

    # ------------------------------------------------------------- 外交馈赠
    def gift(self, frm: str, to: str, good: str, n: int) -> tuple[bool, str]:
        """馈赠：把本国储备赠与他国（粮木矿油装补给或黄金）。本回合垫支扣出，下回合到账。"""
        if frm not in self.nations or to not in self.nations:
            return False, "馈赠双方都必须是现存国家"
        if to == frm:
            return False, "不能赠给自己"
        if good not in RES_KEYS:
            return False, f"不可赠送：{good}（可赠：{'/'.join(RES_KEYS)}）"
        if not isinstance(n, int) or n <= 0:
            return False, "数量需为正整数"
        have = self.res(frm, good)
        if have < n:
            return False, f"你{good}不够：现 {have}，赠不出 {n}"
        self.add_res(frm, good, -n)  # 先垫支扣出（锁住）
        self.gift_pending.append({"from": frm, "to": to, "good": good, "n": n,
                                  "arrive": self.turn + 1})
        return True, f"已赠 {to} {good}×{n}（你余 {self.res(frm, good)}），将于第 {self.turn+1} 回合到账"

    # ------------------------------------------------------------- 交换地图
    def _map_snapshot(self, n: str) -> str:
        """把某国的"已知地图"做成文本：全部国土块 + 边界外可见块，全部带坐标（不截断）。"""
        own = self.own_tiles(n)
        fr = sorted(self.frontier_of(n))
        L = [f"{n} 已知地图：国土 {len(own)} 块、边界外可拓地 {len(fr)} 格（全部坐标）"]
        for p in own:
            t = self.tiles[p]
            L.append(f"  {t.get('name', '?')} {t['terrain']}({p[0] + 1},{p[1] + 1}) "
                     f"城L{t['buildings']['城堡']} 位{sum(t['buildings'].values())}")
        if fr:
            L.append("  边界外可见（未占）:")
            for p in fr:
                L.append(f"  {self.tile_terrain(*p)}({p[0] + 1},{p[1] + 1})")
        return "\n".join(L)

    def share_map(self, frm: str, to: str) -> tuple[bool, str]:
        """把你的已知地图发给别国（交换情报/展示势力），下回合到对方【地图情报】。"""
        if frm not in self.nations or to not in self.nations:
            return False, "交换地图双方都必须是现存国家"
        if to == frm:
            return False, "不能把地图发给自己"
        self.map_pending.append({"from": frm, "to": to, "text": self._map_snapshot(frm),
                                 "arrive": self.turn + 1})
        return True, f"已把你的地图发给 {to}，将于第 {self.turn+1} 回合到账"

    # ------------------------------------------------------------- 间谍
    def _econ_snapshot(self, n: str) -> str:
        """目标国当前完整底细：国库/储备 + 收入结算 + 全部地块建设(含在建) + 粗略军情。"""
        r = self.nations[n].res
        res_txt = " ".join(f"{k}{r.get(k, 0)}" for k in RES_KEYS)
        et, mt, short = self.energy_report.get(n, (0, 0, False))
        grid = "停摆" if short else f"产{et}/需{mt}"
        L = [f"【{n} 情报】国库/储备: {res_txt} | 电网: {grid}"]
        summ = self.econ_summary.get(n)
        if summ:
            L.append(f"  上回合收入结算: {summ}")
        # 外交关系（2026-09-19 用户「间谍要包含外交关系」）：给的是**该国自己的视角**——
        # 它与各国的 交战/共同防御/保障/联盟成员/中立，加上它的联盟与战线。
        # 只给"关系"（谁跟谁是什么），不给"商议"（投票/求和来回/信件）——与公开口径一致。
        L.append("  外交关系（该国的视角）: " + self.rel_desc(n))
        bl = self.bloc_of(n)
        if bl is not None:
            L.append(f"    联盟「{bl['name']}」（盟主 {self.bloc_chief(bl)}）"
                     f"成员：{'、'.join(m for m in bl['members'] if m in self.nations)}")
        fronts = []
        for w in self.wars:
            sides = self._war_sides(w)
            if n in sides[0] or n in sides[1]:
                fls = list(w["followers"]) + list(w.get("atk_followers", []))
                fronts.append(f"{w['atk']}↔{w['def']}" + (f"(跟随 {'、'.join(fls)})" if fls else ""))
        L.append("    战线: " + ("；".join(fronts) if fronts else "无"))
        L.append(f"  全部地块建设情况（{len(self.own_tiles(n))} 块）:")
        for (x, y) in self.own_tiles(n):
            t = self.tiles[(x, y)]
            b = t["buildings"]
            p = t.get("pending") or {}
            built = " ".join(f"{bn}×{c}" for bn, c in b.items() if c) or "无"
            pend = " ".join(f"{bn}×{c}(在建)" for bn, c in p.items() if c)
            extra = ("；" + pend) if pend else ""
            L.append(f"    {t.get('name', '?')} {t['terrain']}({x + 1},{y + 1}) "
                     f"城L{b['城堡']} 位{sum(b.values())}/20 建筑[{built}{extra}]")
        # 粗略军情：只有各兵种数量——位置/血量/番号不外泄（间谍能探到敌国在扩军，但别想精准侦察）
        kinds: dict[str, int] = {}
        for a in self.nation_armies(n):
            k = unit_kind(a)
            kinds[k] = kinds.get(k, 0) + 1
        L.append("  军情（仅数量，位置未知）: " + ("、".join(f"{k}×{c}" for k, c in kinds.items()) or "无军队"))
        return "\n".join(L)

    def spy(self, frm: str, to: str) -> tuple[bool, str]:
        """派间谍刺探别国（花 SPY_COST 金），SPY_TURNS 回合后盗回其经济底细 +
        外交关系（该国视角：与谁 交战/共同防御/保障、在哪个联盟、哪条战线）+
        粗略军情（仅各兵种数量，位置/血量/番号不外泄）+ 整张已知地图。不能对自己用。"""
        if frm not in self.nations or to not in self.nations:
            return False, "间谍双方都必须是现存国家"
        if to == frm:
            return False, "不能派间谍刺探自己"
        if self.res(frm, "黄金") < SPY_COST:
            return False, f"国库不足：派间谍需 {SPY_COST} 金，你现 {self.res(frm, '黄金')}"
        self.add_res(frm, "黄金", -SPY_COST)
        self.spy_pending.append({"from": frm, "to": to, "arrive": self.turn + SPY_TURNS})
        return True, (f"已派间谍前往 {to}（-{SPY_COST}金），"
                      f"将于第 {self.turn + SPY_TURNS} 回合拿回其情报（经济底细+外交关系+粗略军情+地图）")

    # ------------------------------------------------------------- 外交
    # ------------------------------------------------------------- 附庸（main 2026-11）
    ORDINARY_TRIBUTE = 15      # 普通附庸上贡：实际产出的 15%

    def _diplo_authority(self, name: str) -> tuple[bool, str]:
        """普通附庸没有独立外交权（main：并入宗主实体，只能 independence_war）。"""
        if name in self.vassals:
            return False, (f"{name} 是附庸：没有独立外交权"
                           "（并入宗主实体、随宗主参战；唯一出路是 independence_war）")
        return True, ""

    def _would_cycle(self, subject: str, overlord: str) -> bool:
        """把 subject 挂到 overlord 下会不会成环。"""
        cur = overlord
        seen = set()
        while cur in self.vassals and cur not in seen:
            if cur == subject:
                return True
            seen.add(cur)
            cur = self.vassals[cur]["overlord"]
        return cur == subject

    def _vassal_block(self, subject: str, overlord: str, *, peace: bool = False) -> str | None:
        """建立附庸关系前的统一校验（不通过返回原因）。"""
        if subject == overlord:
            return "不能向自己称臣"
        if subject not in self.nations or overlord not in self.nations:
            return "双方必须是现存国家"
        if subject in self.vassals:
            return f"{subject} 已经是 {self.vassals[subject]['overlord']} 的附庸"
        if overlord in self.vassals:
            return f"{overlord} 是附庸，不能有附庸（禁止双层）"
        if self._would_cycle(subject, overlord):
            return "会形成附庸环"
        if not peace:
            if self.war_between(subject, overlord):
                return "交战双方不能在战时称臣（先议和）"
            if self.entity_at_war(self.entity_of(subject)) or self.entity_at_war(self.entity_of(overlord)):
                return "战争期间条约与联盟成员冻结：解约、退盟、改名都要等休战或议和"
            if self.bloc_of(subject) is not None:
                return "须先退出原联盟，才能接受附庸关系"
        if self.polity.get(overlord) == "huns" or self.polity.get(subject) == "huns":
            return "游牧政体不参与附庸关系"
        return None

    def propose_vassalage(self, overlord: str, target: str) -> tuple[bool, str]:
        """宗主邀请某国称臣（对方 accept_vassalage 成立）。"""
        ok, why = self._diplo_authority(overlord)
        if not ok:
            return False, why
        bad = self._vassal_block(target, overlord)
        if bad:
            return False, bad
        if any(p["kind"] == "附庸" and p.get("asker") == overlord and p.get("B") == ent_nation(target)
               for p in self.proposals):
            return False, "该提议已在桌上"
        self.proposals.append({"id": self._next_offer_id(), "kind": "附庸",
                               "A": ent_nation(overlord), "B": ent_nation(target),
                               "asker": overlord, "turn": self.turn})
        return True, f"{overlord} 邀请 {target} 称臣（附庸：上贡实际产出 {self.ORDINARY_TRIBUTE}%、无独立外交权），等对方接受"

    def accept_vassalage(self, me: str, offer_id: int) -> tuple[bool, str]:
        """接受称臣邀约（me = 未来的附庸）。"""
        p = next((x for x in self.proposals if x["id"] == offer_id), None)
        if p is None or p.get("kind") != "附庸":
            return False, "没有这个附庸邀约"
        if p.get("B") != ent_nation(me):    # B 存的是实体 id（国:名），不是国名
            return False, "没有这个给你的邀约"
        self.proposals.remove(p)
        # 宗主邀请：接受者 me 是将来的附庸；主动称臣：接受者 me 是宗主，附庸记在 p["subject"]
        subject, overlord = (p["subject"], me) if p.get("subject") else (me, p["asker"])
        bad = self._vassal_block(subject, overlord)
        if bad:
            return False, bad
        self.vassals[subject] = {"overlord": overlord, "kind": "ordinary",
                                 "tribute_percent": self.ORDINARY_TRIBUTE}
        self.proclaim(f"🤝 {subject} 向 {overlord} 称臣（附庸：上贡实际产出 "
                      f"{self.ORDINARY_TRIBUTE}%、并入其外交实体）")
        return True, f"{subject} 向 {overlord} 称臣（附庸）"

    def submit_vassalage(self, subject: str, target: str) -> tuple[bool, str]:
        """主动称臣：向宗主递邀约，**宗主接受后**才成立（main：普通关系均须另一方 accept_proposal）。"""
        ok, why = self._diplo_authority(subject)
        if not ok:
            return False, why
        bad = self._vassal_block(subject, target)
        if bad:
            return False, bad
        if any(p["kind"] == "附庸" and p.get("subject") == subject and p.get("B") == ent_nation(target)
               for p in self.proposals):
            return False, "该提议已在桌上"
        self.proposals.append({"id": self._next_offer_id(), "kind": "附庸",
                               "A": ent_nation(subject), "B": ent_nation(target),
                               "asker": target, "subject": subject, "turn": self.turn})
        return True, f"{subject} 请求向 {target} 称臣，等对方接受"

    def release_vassal(self, overlord: str, target: str) -> tuple[bool, str]:
        """宗主释放普通附庸（和平时免费）。"""
        v = self.vassals.get(target)
        if v is None or v["overlord"] != overlord:
            return False, f"{target} 不是你的附庸"
        del self.vassals[target]
        self.proclaim(f"🤝 {overlord} 释放附庸 {target}（恢复独立）")
        return True, f"已释放附庸 {target}"

    def independence_war(self, subject: str) -> tuple[bool, str]:
        """唯一脱离途径：向宗主真实宣战（删附庸关系后按常规宣战）。"""
        v = self.vassals.get(subject)
        if v is None:
            return False, f"{subject} 不是附庸"
        overlord = v["overlord"]
        del self.vassals[subject]
        ok, msg = self.declare_war(subject, overlord)
        if not ok:
            # 宣战失败（休战等）→ 关系恢复
            self.vassals[subject] = v
            return False, f"独立战争无法开打：{msg}"
        return True, f"{subject} 宣布独立，对宗主 {overlord} 宣战：{msg}"

    def _next_offer_id(self) -> int:
        self._offer_id += 1
        return self._offer_id

    def propose_pact(self, kind: str, a: str, b: str) -> tuple[bool, str]:
        """提议『共同防御』。**签约方是外交实体**：a 在盟 → 先过联盟投票再对外发邀约；
        a 独立 → 直接发邀约。对方若是联盟，接受时同样要过它的联盟投票。"""
        if kind == "同盟":
            return False, "双边同盟已由多边联盟取代：用 bloc_found(name=联盟名, tos=[创始成员]) 发起结盟（需起名，全体创始成员同意）"
        if kind != "共同防御":
            return False, f"未知盟约类型：{kind}（可选：共同防御；联盟请用 bloc_found）"
        if a == b or a not in self.nations or b not in self.nations:
            return False, "双方必须是两个现存国家"
        ok, why = self._diplo_authority(a)
        if not ok:
            return False, why
        if self.polity.get(b) == "huns":
            return False, f"{b} 是游牧政体，不接受盟约（别在它身上花外交费）"
        A, B = self.entity_of(a), self.entity_of(b)
        bad = self._pact_block(kind, A, B)
        if bad:
            return False, bad
        if self.entity_at_war(A):
            return False, f"战争期间不能缔结{kind}：{self._war_brief_ent(A)}（先议和）"
        if self.entity_at_war(B):
            return False, f"{self.entity_label(B)} 正在交战，战争期间不能与它缔结{kind}（先议和）"
        if any(p["kind"] == kind and {p.get("A"), p.get("B")} == {A, B} for p in self.proposals):
            return False, "该提议已在桌上"
        bl = self.bloc_of(a)
        if bl is not None:
            v = self._new_vote("缔约", bl["name"], a,
                               {"pact": kind, "A": A, "B": B, "offer": True})
            self.log(f"🗳 {a} 发起联盟投票（「{bl['name']}」）：向 {self.entity_label(B)} "
                     f"提议{kind}（投票#{v['id']}）", phase="外交", nation=a)
            return True, (f"已发起联盟投票（投票#{v['id']}）：通过后由 {self.entity_label(A)} "
                          f"向 {self.entity_label(B)} 提议{kind}；成员用 vote {v['id']} true/false 表态")
        self.proposals.append({"id": self._next_offer_id(), "kind": kind, "A": A, "B": B,
                               "asker": a, "turn": self.turn})
        return True, f"{self.entity_label(A)} 向 {self.entity_label(B)} 提议{kind}，等对方接受"

    def accept_pact(self, me: str, offer_id: int) -> tuple[bool, str]:
        """接受收到的邀约。对方若是**联盟**，接受本身也要过联盟投票（一盟一票制）。"""
        p = next((x for x in self.proposals if x["id"] == offer_id), None)
        if p is None:
            return False, "没有这个邀约"
        if p["kind"] == "联盟":
            if me not in p.get("invitees", []):
                return False, "没有这个给你的邀约"
            return self._accept_bloc_founding(p, me)
        if p["kind"] == "附庸":
            return self.accept_vassalage(me, offer_id)
        A, B = p.get("A"), p.get("B")
        if B is None or self.entity_of(me) != B:
            return False, "没有这个给你的邀约"
        if self.entity_of(p.get("asker", "")) != A:
            self.proposals.remove(p)
            return False, "提出方已变更外交实体（入盟/退盟），提议作废"
        kind = p["kind"]
        bad = self._pact_block(kind, A, B)
        if bad:
            self.proposals.remove(p)
            return False, bad
        if self.entity_at_war(A) or self.entity_at_war(B):
            self.proposals.remove(p)
            return False, "战争期间不能缔结盟约（提议作废，先议和）"
        if is_bloc_ent(B):
            if any(v["kind"] == "缔约" and v["payload"].get("offer_id") == p["id"]
                   for v in self.votes):
                return False, f"「{ent_key(B)}」已在表决这个邀约（投票进行中，用 vote 表态）"
            v = self._new_vote("缔约", ent_key(B), me,
                               {"pact": kind, "A": A, "B": B, "offer_id": p["id"]})
            self.log(f"🗳 {me} 把 {self.entity_label(A)} 的{kind}邀约提交「{ent_key(B)}」表决"
                     f"（投票#{v['id']}）", phase="外交", nation=me)
            return True, (f"已把邀约提交「{ent_key(B)}」表决（投票#{v['id']}）：赞成 > 反对"
                          f"即通过与 {self.entity_label(A)} 缔约")
        self.proposals.remove(p)
        return self._conclude_pact(kind, A, B)

    def _pact_parties(self, p: dict) -> list[str]:
        """一条缔约/结盟邀约的**当事人**：两边外交实体的全体现存成员（含无盟时的本国），
        结盟提议再带上各位创始成员。**"被拒了"必须让对面知道**——不广播（"怎么谈的"
        不公开），但对面一直在等这条邀约的结果（用户 2026-09-20 报的洞）。"""
        out: list[str] = []
        for ent in (p.get("A"), p.get("B")):
            for c in (self.entity_members(ent) if ent else []):
                if c not in out:
                    out.append(c)
        for c in [p.get("a")] + list(p.get("invitees", [])):
            if c and c in self.nations and c not in out:
                out.append(c)
        return out

    def reject_pact(self, me: str, offer_id: int) -> tuple[bool, str]:
        p = next((x for x in self.proposals if x["id"] == offer_id), None)
        if p is None:
            return False, "没有这个邀约"
        if p["kind"] == "联盟":
            if me not in p.get("invitees", []):
                return False, "没有这个给你的邀约"
            self.proposals.remove(p)
            self.log(f"💔 {me} 拒绝了 {p['a']} 的结盟提议——「{p['name']}」创始流产（全体创始成员须一致同意）",
                     phase="外交", parties=self._pact_parties(p))
            return True, f"你拒绝了 {p['a']} 的结盟提议「{p['name']}」（创始流产）"
        A, B = p.get("A"), p.get("B")
        if B is None or self.entity_of(me) != B:
            return False, "没有这个邀约"
        if is_bloc_ent(B) and self.entity_chief(B) != me:
            self.proposals.remove(p)
            self.log(f"💔 {self.entity_label(B)}（盟主 {self.entity_chief(B)}）拒绝了 "
                     f"{self.entity_label(A)} 的{p['kind']}", phase="外交",
                     parties=self._pact_parties(p))
            return True, (f"盟主 {self.entity_chief(B)} 代表 {self.entity_label(B)} 拒绝了 "
                          f"{self.entity_label(A)} 的{p['kind']}")
        self.proposals.remove(p)
        self.log(f"💔 {self.entity_label(B)} 拒绝了 {self.entity_label(A)} 的{p['kind']}",
                 phase="外交", parties=self._pact_parties(p))
        return True, f"你拒绝了 {self.entity_label(A)} 的{p['kind']}"

    def break_pact(self, kind: str, a: str, b: str) -> tuple[bool, str]:
        """解除共同防御。在盟国家须联盟投票。

        ★ **战争期间一律不准解除**（2026-09-18 改）：条约在战时**冻结**——平时缔结不了、
        战时也解不掉。原先是"断约顺带退出该条约带来的战线"（`_pact_exit_wars`），
        那等于留了一条「打不过就背弃盟友跑路」的脱战通道；现在只有**议和**能停战。"""
        if kind == "同盟":
            return False, "双边同盟已由多边联盟取代（bloc_found 结盟 / bloc_leave 退盟）"
        if kind != "共同防御":
            return False, f"未知盟约类型：{kind}（可选：共同防御）"
        if a == b or a not in self.nations or b not in self.nations:
            return False, "双方必须是两个现存国家"
        ok, why = self._diplo_authority(a)
        if not ok:
            return False, why
        A, B = self.entity_of(a), self.entity_of(b)
        if not self.has_pact("共同防御", A, B):
            return False, f"{self.entity_label(A)} 与 {self.entity_label(B)} 并无共同防御"
        if self.entity_at_war(A) or self.entity_at_war(B):
            who = A if self.entity_at_war(A) else B
            return False, (f"战争期间不能解除共同防御：{self._war_brief_ent(who)}"
                           "（**条约在战时冻结**，缔结与解除都不行——先议和停战）")
        bl = self.bloc_of(a)
        if bl is not None:
            v = self._new_vote("缔约", bl["name"], a,
                               {"pact": kind, "A": A, "B": B, "cancel": True})
            self.log(f"🗳 {a} 发起联盟投票（「{bl['name']}」）：解除与 {self.entity_label(B)} "
                     f"的共同防御（投票#{v['id']}）", phase="外交", nation=a)
            return True, (f"已发起联盟投票（投票#{v['id']}）：通过后解除与 "
                          f"{self.entity_label(B)} 的共同防御；成员用 vote {v['id']} true/false 表态")
        self._drop_pact(kind, A, B)
        exited = self._pact_exit_wars(self.entity_members(A), self.entity_members(B))
        extxt = f"，并退出 {self.entity_label(B)} 所在的 {len(exited)} 条战线" if exited else ""
        self.proclaim(f"💔 {self.entity_label(A)} 单方面解除与 {self.entity_label(B)} 的{kind}{extxt}"
                      f"（{'、'.join(self.entity_members(A))} 在他国境内的军队将全部撤出）")
        return True, (f"{self.entity_label(A)} 已解除与 {self.entity_label(B)} 的{kind}{extxt}。"
                      "如你在他国境内，会于回合末自动遣返回国")

    # ------------------------------------------------------------- 联盟
    def propose_bloc(self, a: str, name: str, invitees: list[str]) -> tuple[bool, str]:
        """发起结盟：起名 + 邀全体创始成员，所有人接受才成立（全体成员同意）。
        发起方即盟主；战争期间不得缔结同盟（避免战时抱团脱战）。"""
        if a not in self.nations:
            return False, "发起方必须是现存国家"
        ok, why = self._diplo_authority(a)
        if not ok:
            return False, why
        if self.at_war(a):
            return False, f"战争期间不能缔结同盟：{self._war_brief(a)}（先议和再谈结盟）"
        # ★ 休战（和约）**不拦**结盟（2026-10-07）：和约只拦"对休战对手宣战"，见 active_truce
        if self.bloc_of(a) is not None:
            return False, f"你已在联盟「{self.bloc_of(a)['name']}」中（一国同时只属一个联盟）"
        name = (name or "").strip()
        if not name or " " in name or len(name) > BLOC_NAME_MAX:
            return False, f"联盟名需为 1~{BLOC_NAME_MAX} 字、不含空格（name 参数）"
        if self.bloc_by_name(name) is not None:
            return False, f"联盟名「{name}」已被占用"
        inv = []
        for x in invitees:
            if x == a or x in inv:
                continue
            if x not in self.nations:
                return False, f"创始成员 {x} 不是现存国家"
            if self.bloc_of(x) is not None:
                return False, f"{x} 已在联盟「{self.bloc_of(x)['name']}」中"
            if self.polity.get(x) == "huns":
                return False, f"{x} 是游牧政体，不参与结盟（邀它只会让提议悬空）"
            if self.at_war(x):
                return False, f"创始成员 {x} 正在交战，战争期间不能缔结同盟（先议和）"
            inv.append(x)
        if not inv:
            return False, "至少邀请一个创始成员（tos=[国名,…]）；单国无需结盟"
        for i in range(len([a] + inv)):
            for j in range(i + 1, len([a] + inv)):
                x, y = ([a] + inv)[i], ([a] + inv)[j]
                if self.war_between(x, y):
                    return False, f"创始成员 {x} 与 {y} 正在交战，不能结盟（先议和）"
        if any(p["kind"] == "联盟" and p["a"] == a and p["name"] == name for p in self.proposals):
            return False, "该结盟提议已在桌上"
        self.proposals.append({"id": self._next_offer_id(), "kind": "联盟", "a": a, "b": "",
                               "name": name, "invitees": inv, "turn": self.turn})
        self.log(f"🕊 {a} 发起结盟「{name}」：邀 {'、'.join(inv)} 为创始成员（全体同意才成立）",
                 phase="外交", nation=a)
        return True, (f"已发起结盟「{name}」：等 {'、'.join(inv)} 全部 respond_proposal 接受后成立；"
                      f"任一拒绝即流产")

    def _accept_bloc_founding(self, p: dict, me: str) -> tuple[bool, str]:
        """创始成员接受结盟提议；全体接受即立盟。"""
        p.setdefault("accepted", [])
        if me in p["accepted"]:
            return False, "你已接受过该提议"
        p["accepted"].append(me)
        self.log(f"🕊 {me} 接受加入联盟「{p['name']}」", phase="外交", nation=me)
        pending = [x for x in p["invitees"] if x not in p["accepted"]]
        if pending:
            return True, f"你已接受结盟「{p['name']}」：还差 {'、'.join(pending)} 同意"
        # 全体同意 → 立盟
        self.proposals.remove(p)
        members = [p["a"]] + list(p["invitees"])
        for x in members:
            if x not in self.nations or self.bloc_of(x) is not None:
                return False, f"立盟失败：{x} 已不在可入盟状态（提议作废）"
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                if self.war_between(members[i], members[j]):
                    return False, f"立盟失败：{members[i]} 与 {members[j]} 已交战（提议作废）"
        self.blocs.append({"name": p["name"], "chief": p["a"], "members": members,
                           "turn": self.turn})
        # ★ 入盟即放弃个人条约：创始成员手里原有的保障/共同防御一律作废（它们本来就
        #   是"国家级"的，而入盟后这个国家不再是签约主体）。别想带着条约入伙。
        absorbed = self._absorb_personal_pacts(members)
        ab = f"（{'、'.join(absorbed)} 自动作废）" if absorbed else ""
        # ★ 和约随实体走（2026-10-11）：**本盟的对外和约＝盟主那一份**，成员自己的从这一刻
        #   起暂停（退盟/解散按原到期回合自动恢复）。表里那条一个字没动。
        sus = self._suspended_truces(members)
        sg = (f"；本盟的对外和约以**盟主 {p['a']}** 为准，成员自己的以下和约在盟内暂停"
              f"（退盟即恢复原到期回合）：{'、'.join(sus)}") if sus else \
             f"；本盟的对外和约以**盟主 {p['a']}** 为准（成员自己的和约在盟内暂停，退盟恢复）"
        self.proclaim(f"🕊 联盟「{p['name']}」成立！成员：{'、'.join(members)}（盟主 {p['a']}）{ab}{sg}")
        return True, (f"联盟「{p['name']}」成立！成员：{'、'.join(members)}，盟主 {p['a']}"
                      f"（你为创始成员）{ab}{sg}")

    def _absorb_personal_pacts(self, members: list[str]) -> list[str]:
        """入盟清账：把成员手里的**个人**条约全部作废（成员不再是签约主体）。
        返回人话描述，供日志与提示。"""
        out = []
        for m in members:
            out.extend(self.drop_pacts_of(ent_nation(m)))
        if out:
            self.proclaim(f"💔 入盟即放弃个人条约：{'、'.join(out)} 作废")
        return out

    def bloc_leave(self, a: str) -> tuple[bool, str]:
        """退盟：普通成员单方面退出，立即生效。**战争期间一律不准退**——盟员在战时被锁死
        （2026-09-18 外交改革：坚壁到底，不给"打不过就跑"的通道），直到整盟停战。"""
        bloc = self.bloc_of(a)
        if bloc is None:
            return False, "你不在任何联盟中"
        if self.bloc_chief(bloc) == a:
            return False, ("你是盟主，不能退盟——请用 bloc_transfer(to=成员) 移交盟主之位，"
                           "或 bloc_dissolve 解散联盟")
        fighting = [m for m in bloc["members"] if self.at_war(m)]
        if fighting:
            return False, (f"战争期间不能退盟：{'、'.join(fighting)} 正在交战"
                           "（盟员在战时被锁死，直到整盟停战——先议和）")
        bloc["members"].remove(a)
        self.proclaim(f"💔 {a} 单方面退出联盟「{bloc['name']}」")
        if len(bloc["members"]) < 2:   # 只剩盟主一人 → 联盟自动解散
            chief = self.bloc_chief(bloc)
            self.blocs.remove(bloc)
            for _v in [v for v in self.votes if v["bloc"] == bloc["name"]]:
                self._cancel_vote(_v, "联盟解散")   # ★ 当事人（含盟外申请人）要收到
            self.proclaim(f"💔 联盟「{bloc['name']}」仅剩盟主 {chief}，自动解散")
            return True, f"你已退出「{bloc['name']}」——联盟只剩盟主，随之解散"
        return True, (f"你已单方面退出「{bloc['name']}」。"
                      "（滞留他国领土的军队将自回合末起自动遣返）")

    def bloc_transfer(self, a: str, to: str) -> tuple[bool, str]:
        """盟主移交：把盟主之位让给本联盟另一成员（只有现任盟主能调）。"""
        bloc = self.bloc_of(a)
        if bloc is None:
            return False, "你不在任何联盟中"
        chief = self.bloc_chief(bloc)
        if chief != a:
            return False, f"只有盟主能移交（现任盟主是 {chief}）"
        if to == a:
            return False, "不能把盟主之位移交给自己"
        if to not in bloc["members"]:
            return False, f"{to} 不是本联盟成员（成员：{'、'.join(bloc['members'])}）"
        bloc["chief"] = to
        self.proclaim(f"👑 {a} 把联盟「{bloc['name']}」盟主之位移交给 {to}")
        return True, f"已把「{bloc['name']}」盟主之位移交给 {to}"

    def bloc_rename(self, a: str, new_name: str) -> tuple[bool, str]:
        """盟主给联盟改名（只有盟主能改）。命名规则与立盟一致：1~12 字、不含空格、全局唯一。"""
        bloc = self.bloc_of(a)
        if bloc is None:
            return False, "你不在任何联盟中"
        chief = self.bloc_chief(bloc)
        name = (new_name or "").strip()
        if chief != a:
            return False, f"只有盟主能给联盟改名（现任盟主是 {chief}）"
        if not name or " " in name or len(name) > BLOC_NAME_MAX:
            return False, f"联盟名需为 1~{BLOC_NAME_MAX} 字、不含空格（name 参数）"
        if name == bloc["name"]:
            return False, f"你的联盟已经叫「{name}」了"
        if self.bloc_by_name(name) is not None:
            return False, f"联盟名「{name}」已被占用"
        old = bloc["name"]
        bloc["name"] = name
        self._rename_bloc_refs(old, name)
        self.proclaim(f"🏷 盟主 {a} 把联盟「{old}」改名为「{name}」")
        return True, f"联盟已改名：「{old}」→「{name}」"

    def _rename_bloc_refs(self, old: str, new: str) -> None:
        """联盟改名 → 把按**实体 id** 索引的引用整体同步（条约表），顺手同步按联盟名索引的
        投票。实体 id 里嵌着联盟名（"盟:<名>"），漏一处就会出现指向不存在实体的条约。"""
        for p in self.pacts:
            for k in ("a", "b"):
                if p[k] == ent_bloc(old):
                    p[k] = ent_bloc(new)
        for v in self.votes:        # 进行中的投票按联盟名索引，一并改掉，免得面板/日志对不上
            if v["bloc"] == old:
                v["bloc"] = new
        for k in list(self.truce):  # ★ 休战表也是按实体 id 存的（2026-10-11）：漏这条＝改名即失约
            if ent_bloc(old) in k:
                u = self.truce.pop(k)
                self.truce[_pair(*[ent_bloc(new) if x == ent_bloc(old) else x
                                   for x in sorted(k)])] = u

    def bloc_dissolve(self, a: str) -> tuple[bool, str]:
        """盟主解散联盟（只有盟主能调）。**战争期间一律不准解散**（盟员在战时被锁死），
        防止盟主用解散脱战坑盟友。"""
        bloc = self.bloc_of(a)
        if bloc is None:
            return False, "你不在任何联盟中"
        chief = self.bloc_chief(bloc)
        if chief != a:
            return False, f"只有盟主能解散联盟（现任盟主是 {chief}）"
        fighting = [m for m in bloc["members"] if self.at_war(m)]
        if fighting:
            return False, (f"战争期间不能解散联盟：{'、'.join(fighting)} 正在交战"
                           "（坚壁到底——先议和停战再谈解散）")
        members = list(bloc["members"])
        self.blocs.remove(bloc)
        for _v in [v for v in self.votes if v["bloc"] == bloc["name"]]:
            self._cancel_vote(_v, "联盟解散")   # ★ 当事人（含盟外申请人）要收到
        self.proclaim(f"💔 盟主 {a} 解散联盟「{bloc['name']}」（原成员：{'、'.join(members)}）")
        return True, (f"已解散联盟「{bloc['name']}」：原成员 {'、'.join(members)} 恢复各自独立"
                      "（他们此后才是各自的外交实体）")

    def bloc_join(self, a: str, bloc_name: str) -> tuple[bool, str]:
        """申请入盟：联盟现成员投票（赞成 > 反对，盟主可否决），通过即入盟。
        战争期间不能入盟（先议和）。"""
        if a not in self.nations:
            return False, "申请方必须是现存国家"
        ok, why = self._diplo_authority(a)
        if not ok:
            return False, why
        if self.at_war(a):
            return False, f"战争期间不能缔结同盟：{self._war_brief(a)}（先议和再谈入盟）"
        bloc = self.bloc_by_name(bloc_name)
        if bloc is None:
            return False, f"联盟「{bloc_name}」不存在（可用面板查联盟列表）"
        if self.bloc_of(a) is not None:
            return False, f"你已在联盟「{self.bloc_of(a)['name']}」中（一国同时只属一个联盟）"
        if any(self.war_between(a, m) for m in bloc["members"]):
            return False, "你与该联盟成员正在交战，不能入盟（先议和）"
        v = self._new_vote("入盟", bloc["name"], a, {"candidate": a})
        self.log(f"🗳 {a} 申请加入联盟「{bloc_name}」（投票#{v['id']}，赞成>反对通过，未投算反对）",
                 phase="外交", nation=a)
        return True, (f"已向「{bloc_name}」申请入盟（投票#{v['id']}）：成员用 "
                      f"vote {v['id']} yes/no/abstain 表态（下一回合生效）；赞成多于反对即通过（未投算反对）")

    # ------------------------------------------------------------- 联盟投票
    def _new_vote(self, kind: str, bloc: str, proposer: str, payload: dict) -> dict:
        self._vote_id += 1
        v = {"id": self._vote_id, "kind": kind, "bloc": bloc, "proposer": proposer,
             "payload": payload, "votes": {}, "turn": self.turn,
             # main：T 期发起、T+1 期投票、T+1 结算最前（cycle.start）统一计票。
             "deadline": self.turn + 1}
        self.votes.append(v)
        return v

    def cast_vote(self, me: str, vote_id: int, choice) -> tuple[bool, str]:
        """联盟成员在**投票期**表态：True 赞成 / False 反对 / None 弃权（可改票）。

        main 口径：T 期发起、T+1 期才能投（deadline）；投票不即时结算，统一在
        下一回合结算最前的 cycle.start 计票。**发起人无默认票、盟主无否决权**。
        """
        v = next((x for x in self.votes if x["id"] == vote_id), None)
        if v is None:
            return False, "没有这个投票（diplomacy 面板查看进行中的投票）"
        bloc = self.bloc_by_name(v["bloc"])
        if bloc is None or self.bloc_of(me) is not bloc:
            return False, "该投票不属于你所在的联盟"
        if v["kind"] == "入盟" and v["payload"].get("candidate") == me:
            return False, "入盟投票由现成员表决，申请人不投票"
        if self.turn != v.get("deadline", v["turn"] + 1):
            return False, (f"投票期是第 {v.get('deadline', v['turn'] + 1)} 回合"
                           f"（本回合是第 {self.turn} 回合）：发起当期只登记，"
                           "下一回合才能表态；结算最前统一计票")
        v["votes"][me] = choice
        label = "赞成" if choice is True else ("反对" if choice is False else "弃权")
        self.log(f"🗳 {me} 在「{v['bloc']}」投票#{v['id']}（{v['kind']}）：{label}",
                 phase="外交", nation=me)
        members = [m for m in bloc["members"] if m in self.nations]
        yes, no, abst, pending = self._vote_counts(v, members)
        return True, (f"已记票（赞成 {yes}/反对 {no}/弃权 {abst}/未投 {pending}）："
                      f"第 {v.get('deadline', v['turn'] + 1)} 回合结算最前计票（未投算反对）")

    @staticmethod
    def _vote_counts(v: dict, members: list[str]) -> tuple[int, int, int, int]:
        """(赞成, 反对, 弃权, 未投)。未投 = 到期即弃权。"""
        yes = sum(1 for m in members if v["votes"].get(m) is True)
        no = sum(1 for m in members if v["votes"].get(m) is False)
        abst = sum(1 for m in members if m in v["votes"] and v["votes"][m] is None)
        return yes, no, abst, len(members) - yes - no - abst

    def _pass_vote(self, v: dict, members: list[str], yes: int, no: int, abst: int) -> tuple[bool, str]:
        """投票通过：移出投票列表、记账、执行。"""
        self.votes.remove(v)
        # ★ 只给**盟内**（含发起人）：对外那一方由"投票通过后发生的动作"本身通知
        #   （发出邀约 / 入盟公告 / 宣战），计票不外泄给盟外（商议过程仍不公开）
        self.log(f"🗳 「{v['bloc']}」投票#{v['id']}（{v['kind']}）通过：赞成 {yes}/反对 {no}/弃权 {abst}",
                 phase="外交", parties=sorted(set(members) | {v["proposer"]}))
        # main：计票在周期开头，通过的议案进待办，到外交挂点（生产之后）与其他命令一起按优先级执行
        self.diplo_approved.append(v)
        return True, f"投票通过（赞成 {yes}/反对 {no}）——将在本回合外交结算时执行"

    def _tally(self, v: dict) -> tuple[bool, str]:
        """计票：赞成 > 反对 → 通过并立即执行（弃权不计入分母）；结果已无悬念时提前定论。"""
        bloc = self.bloc_by_name(v["bloc"])
        if bloc is None:
            self._cancel_vote(v, "联盟已不存在")
            return False, "联盟已不存在，投票作废"
        members = [m for m in bloc["members"] if m in self.nations]
        yes, no, abst, pending = self._vote_counts(v, members)
        if yes > no + pending:          # 未投的全投反对也追不上 → 通过
            return self._pass_vote(v, members, yes, no, abst)
        if yes + pending <= no:         # 未投的全赞成也超不过 → 未通过
            self._cancel_vote(v, "未通过（票数已无悬念）")
            return False, f"投票未通过（赞成 {yes}/反对 {no}，反对已不可能被超过）"
        return True, (f"已记票（赞成 {yes}/反对 {no}/弃权 {abst}/未投 {pending}，需赞成 > 反对）："
                      f"等其余成员表态")

    def _expire_votes(self) -> None:
        """cycle.start 计票：deadline ≤ 当前回合的投票统一结算（main 口径）。

        赞成 > 反对 通过；**未投自动算反对**；显式弃权（None）保留、不进分母；
        发起人无默认票；盟主无否决权。
        """
        for v in list(self.votes):
            if self.turn < v.get("deadline", v["turn"] + 1):
                continue
            bloc = self.bloc_by_name(v["bloc"])
            if bloc is None:
                self._cancel_vote(v, "联盟已不存在")
                continue
            members = [m for m in bloc["members"] if m in self.nations]
            yes, no, abst, pending = self._vote_counts(v, members)
            no += pending               # 未投自动反对
            if yes > no:
                self._pass_vote(v, members, yes, no, abst)
            else:
                self._cancel_vote(v, "未通过（未投的算反对）")

    def _execute_vote(self, v: dict) -> tuple[bool, str]:
        """投票通过后的实际执行。"""
        pl = v["payload"]
        if v["kind"] == "宣战":
            bloc = self.bloc_by_name(v["bloc"])
            if bloc is None:
                return False, "联盟已散，宣战落空"
            target = pl.get("target")          # ★ 实体 id（不是国名）
            if not self.entity_members(ent_bloc(v["bloc"])) or not self.entity_members(target):
                return False, f"目标 {self.entity_label(target)} 已不在，宣战落空"
            return self._declare_war_internal(ent_bloc(v["bloc"]), target, v["proposer"])
        if v["kind"] == "缔约":
            return self._execute_pact_vote(v)
        if v["kind"] == "入盟":
            bloc = self.bloc_by_name(v["bloc"])
            cand = pl.get("candidate")
            if bloc is None or cand not in self.nations:
                return False, "入盟条件已变，申请落空"
            if self.bloc_of(cand) is not None or any(self.war_between(cand, m) for m in bloc["members"]):
                return False, f"{cand} 已入他盟/与成员交战，入盟落空"
            absorbed = self._absorb_personal_pacts([cand])
            bl = f"（入盟即放弃个人条约：{'、'.join(absorbed)} 作废）" if absorbed else ""
            sus = self._suspended_truces([cand])
            sg = (f"；{cand} 自己的和约在盟内暂停（退盟即恢复）：{'、'.join(sus)}") if sus else ""
            bloc["members"].append(cand)
            self.proclaim(f"🕊 {cand} 加入联盟「{bloc['name']}」{bl}{sg}")
            return True, f"{cand} 正式加入「{bloc['name']}」{bl}{sg}"
        if v["kind"] == "议和":
            if pl.get("type") == "offer":
                w = next((x for x in self.wars if x["id"] == pl.get("war_id")), None)
                if w is None:
                    return False, "战争已结束，议和投票落空"
                a_side = "atk" if v["proposer"] in self._war_sides(w)[0] else "def"
                if self._peace_rep(w, a_side) != v["proposer"]:
                    return False, "你已不是本方谈判代表，议和落空"
                return self._record_peace_offer(w, v["proposer"], pl["to"], pl["kind"],
                                                pl["gold"], pl.get("note", ""), pl.get("truce", 0))
            if pl.get("type") == "accept":
                p = next((x for x in self.peace_offers if x["id"] == pl.get("offer_id")), None)
                if p is None:
                    return False, "求和提议已不在，接受落空"
                return self._do_accept_peace(p)
        return False, f"未知投票类型 {v['kind']}"

    def _execute_pact_vote(self, v: dict) -> tuple[bool, str]:
        """联盟「缔约」投票通过后的执行：签保障 / 签共同防御 / 撤回保障 / 解除共同防御 /
        对外发出共同防御邀约。**条约的表决与执行都只走这条路径**——成员个人签不了。"""
        pl = v["payload"]
        kind, A, B = pl["pact"], pl["A"], pl["B"]
        if not self.entity_members(A):
            return False, f"{self.entity_label(A)} 已不存在，{kind}表决落空"
        if not self.entity_members(B):
            return False, f"{self.entity_label(B)} 已不存在，{kind}表决落空"
        if pl.get("cancel"):                       # 撤回保障 / 解除共同防御
            if self.entity_at_war(A) or self.entity_at_war(B):
                return False, "战争期间条约冻结：表决通过也失效了（先议和停战）"
            if self._drop_pact(kind, A, B):
                self.proclaim(f"💔 {self.entity_label(A)} 经联盟表决解除与 "
                              f"{self.entity_label(B)} 的{kind}")
                return True, f"{self.entity_label(A)} 已解除与 {self.entity_label(B)} 的{kind}"
            return False, f"条约已不在，解除{kind}落空"
        if pl.get("offer"):                        # 我方实体对外提议共同防御
            p = {"id": self._next_offer_id(), "kind": kind, "A": A, "B": B,
                 "asker": v["proposer"], "turn": self.turn}
            self.proposals.append(p)
            self.log(f"🗳 {self.entity_label(A)} 经联盟表决，向 {self.entity_label(B)} "
                     f"提议{kind}（邀约#{p['id']}）", phase="外交")
            return True, (f"已以 {self.entity_label(A)} 的名义向 {self.entity_label(B)} 发出"
                          f"{kind}邀约（#{p['id']}），等对方回应")
        oid = pl.get("offer_id")                   # 对方邀约的表决通过 → 落条约
        if oid is not None:
            self.proposals = [x for x in self.proposals if x["id"] != oid]
        bad = self._pact_block(kind, A, B)
        if bad:
            return False, bad
        return self._conclude_pact(kind, A, B)

    # ------------------------------------------------------------- 核心领土
    def _snapshot_cores(self, participants: list[str]) -> None:
        """战争结束：参战各国（含跟随方）实际持有的地块重算为其核心领土（议和即对现状追认）。"""
        for p in set(participants):   # 序无关：每格只有一个 owner，写入键互斥（区别于战争闭包/弃城那两处需 sorted 的 set 迭代）
            if p not in self.nations:
                continue
            for (x, y) in self.own_tiles(p):
                self.tiles[(x, y)]["core"] = p

    def _same_front(self, a: str, b: str) -> bool:
        """a 与 b 是否处于同一场战争的同一侧（同战线，含跟随方）。"""
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if (a in atk and b in atk) or (a in dfs and b in dfs):
                return True
        return False

    def _return_core(self, x: int, y: int, by: str) -> str:
        """同战线盟友自动归还核心领土：by 刚占领 (x,y)，若此地是同联盟且同战线的
        盟友的核心，则立即归还盟友（驻军原地不动，盟国领土合法停留）。返回附加说明。"""
        t = self.tiles.get((x, y))
        core = t.get("core") if t else None
        if not core or core == by or core not in self.nations or core == t.get("owner"):
            return ""
        if self.bloc_of(by) is None or self.bloc_of(by) is not self.bloc_of(core):
            return ""
        if not self._same_front(by, core):
            return ""
        t["owner"] = core
        return f"——此乃盟友 {core} 的核心领土，已自动归还（同战线·联盟「{self.bloc_of(core)['name']}」）"

    def declare_guarantee(self, a: str, b: str) -> tuple[bool, str]:
        """a 宣布保障 b 独立。**签约方是外交实体**：a 在盟 → 由它的联盟出面，须联盟投票通过；
        a 独立 → 直接生效（它自己就是实体）。"""
        if a not in self.nations or b not in self.nations:
            return False, "双方必须是两个现存国家"
        A, B = self.entity_of(a), self.entity_of(b)
        bad = self._pact_block("保障", A, B)
        if bad:
            return False, bad
        if self.entity_at_war(A):
            return False, f"战争期间不能提供保障独立：{self._war_brief_ent(A)}（先议和）"
        if self.entity_at_war(B):
            return False, f"{self.entity_label(B)} 正在交战，战争期间不能保障它（先议和）"
        bl = self.bloc_of(a)
        if bl is not None:
            v = self._new_vote("缔约", bl["name"], a, {"pact": "保障", "A": A, "B": B})
            self.log(f"🗳 {a} 发起联盟投票（「{bl['name']}」）：{self.entity_label(A)} 保障 "
                     f"{self.entity_label(B)} 独立（投票#{v['id']}）", phase="外交", nation=a)
            return True, (f"已发起联盟投票（投票#{v['id']}）：通过后由 {self.entity_label(A)} "
                          f"保障 {self.entity_label(B)} 独立；成员用 vote {v['id']} true/false 表态")
        return self._conclude_pact("保障", A, B)

    def cancel_guarantee(self, a: str, b: str) -> tuple[bool, str]:
        """撤回保障（方向敏感：只有保障方能撤）。在盟国家须联盟投票。"""
        if a not in self.nations or b not in self.nations:
            return False, "双方必须是两个现存国家"
        A, B = self.entity_of(a), self.entity_of(b)
        if A == B:
            return False, "你与它同属一个实体，没有保障可撤"
        if not self.has_pact("保障", A, B):
            return False, f"{self.entity_label(A)} 并未保障 {self.entity_label(B)}"
        if self.entity_at_war(A) or self.entity_at_war(B):
            who = A if self.entity_at_war(A) else B
            return False, (f"战争期间不能撤回独立保障：{self._war_brief_ent(who)}"
                           "（**条约在战时冻结**，缔结与撤回都不行——先议和停战）")
        bl = self.bloc_of(a)
        if bl is not None:
            v = self._new_vote("缔约", bl["name"], a,
                               {"pact": "保障", "A": A, "B": B, "cancel": True})
            self.log(f"🗳 {a} 发起联盟投票（「{bl['name']}」）：撤回对 {self.entity_label(B)} 的保障"
                     f"（投票#{v['id']}）", phase="外交", nation=a)
            return True, (f"已发起联盟投票（投票#{v['id']}）：通过后撤回对 "
                          f"{self.entity_label(B)} 的独立保障")
        self._drop_pact("保障", A, B)
        self.proclaim(f"{self.entity_label(A)} 撤回对 {self.entity_label(B)} 的独立保障")
        return True, f"{self.entity_label(A)} 已撤回对 {self.entity_label(B)} 的保障"

    def declare_war(self, a: str, b: str) -> tuple[bool, str]:
        """宣战。**交战方是外交实体**：在盟国家不能擅自开战，调用即转为联盟宣战投票
        （多数决通过后全盟参战）；独立国家直接开战。

        守侧传导 = 保障 / 共同防御 / 联盟，**以实体为单位、只传一跳**（被宣战实体的直接
        保障国与直接共同防御伙伴参战，它们自己的盟友不再跟着上）；"无限跳"只指**联盟
        收成一个点**——打盟员 = 打联盟，全盟一起上。"""
        if a == b or a not in self.nations or b not in self.nations:
            return False, "双方必须是两个现存国家"
        ok, why = self._diplo_authority(a)
        if not ok:
            return False, why
        if self.war_between(a, b):
            return False, "你们已经在交战"
        t = self.active_truce(a, b)      # 到期的顺手清掉；同属一个实体 ⇒ 和约已被联盟合并
        if t is not None:
            return False, f"休战中：你与 {b} 约定休战至第 {t} 回合（还剩 {t - self.turn} 回合），不得再宣战"
        A, B = self.entity_of(a), self.entity_of(b)
        if A == B:
            return False, (f"{b} 与你同属 {self.entity_label(A)}，不能宣战"
                           "（盟内互不攻击是联盟自带效果）")
        bl = self.bloc_of(a)
        if bl is not None:
            v = self._new_vote("宣战", bl["name"], a, {"target": B})
            self.log(f"🗳 {a} 发起联盟宣战投票（「{bl['name']}」）：对 {self.entity_label(B)} "
                     f"宣战（投票#{v['id']}，多数决）", phase="外交", nation=a)
            return True, (f"已发起联盟宣战投票（投票#{v['id']}）：多数同意后全盟对 "
                          f"{self.entity_label(B)} 宣战；成员用 vote {v['id']} true/false 表态")
        return self._declare_war_internal(A, B, a)

    def _declare_war_internal(self, atk_ent: str, def_ent: str,
                              proposer: str) -> tuple[bool, str]:
        """实际开战。atk_ent / def_ent 都是**外交实体**（独立国家或联盟）；proposer=发起国名。

        守侧传导：从 def_ent 出发的 保障/共同防御，**一跳不级联**（援军的盟友不动）——
        联盟成员整体落在守侧（打成员=打联盟，这是"无限跳"的唯一含义）。
        ★ 战线条目本身仍记为**国家**（atk=进攻主导国=盟主、def=目标实体代表、
        followers=守侧跟随国），作战/结算/遣返/迷雾那一堆既有代码不必换口径。
        """
        members = self.entity_members(atk_ent)
        def_members = self.entity_members(def_ent)
        if not members:
            return False, f"{self.entity_label(atk_ent)} 已不存在，宣战落空"
        if not def_members:
            return False, f"目标 {self.entity_label(def_ent)} 已灭亡，宣战落空"
        b = self.entity_chief(def_ent) or def_members[0]
        # 休战检查：**实体对实体**（2026-10-11）——实体的和约＝**盟主**的和约，
        # 成员的私约在盟内暂停（`truce_holder`）。旧版逐国对逐国，于是**一个成员的和约
        # 能给整个联盟挡刀**（楚 与 韩 休战 ⇒ 韩 连对「周天下」宣战都发不出去）。
        t = self.active_truce(b, self.entity_chief(atk_ent) or members[0])
        if t is not None:
            return False, (f"休战中：{self.entity_label(atk_ent)} 与 {self.entity_label(def_ent)}"
                           f"约定休战至第 {t} 回合（{b} 与 "
                           f"{self.entity_chief(atk_ent) or members[0]} 签的那一份），不得开战")
        # ★ 过了这一关就是**真的开打**了 ⇒ 战前未通过的外交条约当场作废（用户 2026-10-11）。
        #   放这里是因为往下三条路（守侧并入 / 随攻并入 / 开新战线）都算"发生战争"。
        self._void_pending_treaties(
            f"{self.entity_label(atk_ent)} 对 {self.entity_label(def_ent)} 开战")
        # 并入现有战线（不开平行战争）：目标实体正在攻打我方实体的盟友/共同防御对象 → 守侧并入
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if any(d in atk for d in def_members) and any(
                    self._same_camp(m, d) for m in members for d in dfs):
                self._break_pacts_between(atk_ent, def_ent)
                added = [m for m in members if m not in dfs
                         and not any(self.war_between(m, x) for x in atk)
                         # 与这条战线的攻方有和约 ⇒ 不并进去打自己的休战对手
                         and not self._truce_blocks_war_join([m], atk)]
                w["followers"].extend(added)
                for m in added:
                    self.proclaim(f"⚔ {m} 对 {self.entity_label(def_ent)} 宣战：盟友正被它攻打，"
                                  "并入该战线当防守方跟随方（不开第二场战争；跟随方不能单独议和）")
                return True, (f"对 {self.entity_label(def_ent)} 宣战：并入既有战线当防守方"
                              f"（新增 {'、'.join(added) or '无'}；跟随方不能单独议和，"
                              "主导者议和则整条战线停战）")
        # 目标实体正被我方实体的盟友/共同防御对象攻打 → 随攻并入
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if any(d in dfs for d in def_members) and any(
                    self._same_camp(m, x) for m in members for x in atk):
                self._break_pacts_between(atk_ent, def_ent)
                added = [m for m in members if m not in atk
                         and not any(self.war_between(m, x) for x in dfs)
                         # 同上：与守方有和约 ⇒ 不并进去随攻
                         and not self._truce_blocks_war_join([m], dfs)]
                w.setdefault("atk_followers", []).extend(added)
                for m in added:
                    self.proclaim(f"⚔ {m} 对 {self.entity_label(def_ent)} 宣战：盟友正在攻打它，"
                                  "并入该战线随攻（不开第二场战争；跟随方不能单独议和）")
                return True, (f"对 {self.entity_label(def_ent)} 宣战：并入既有战线随攻"
                              f"（新增 {'、'.join(added) or '无'}）")
        # 两实体之间的保障/共同防御自动解除（不打自己人）
        self._break_pacts_between(atk_ent, def_ent)
        # 守侧传导（**一跳，不级联**）：只有 def_ent 的**直接**保障国与**直接**共同防御
        # 伙伴被拉进守侧；这些援军**自己身上的条约不再往下传**——A 保 B、B 与 C 共防时，
        # 打 B 只有 C 上，C 的其它盟友不动。（用户 2026-10-07 定案：「不无限跳，无限跳指
        # 联盟」。旧实现在这里放了个 `while stack` 做传递闭包，于是"魏被打→韩参战→韩的
        # 共防伙伴楚也参战"——楚与魏之间根本没有条约。条约的触发条件是**它被打**，
        # 不是**它被卷进来**。）
        # ★ 「无限跳」在本作里只剩一个含义：**联盟收成一个点**——打盟员 = 打联盟，
        #   全盟一起上（`entity_members(def_ent)` 一次取齐），联盟内部没有双边条约、
        #   因而也不存在"经由某个成员把盟外国家串成一串"的链条。
        def_side = {def_ent}
        skipped: list[str] = []          # 因"和约在身"没被拖进来的援军（事后要通知）
        cands = set(self.guarantors_of(def_ent)) | set(self.defense_partners_of(def_ent))
        # ★ 必须 sorted：循环体读**增长中的 def_members**（下面的 war_between 剪枝），
        #   集合迭代序受 PYTHONHASHSEED 影响 → 同 seed 换进程可能收编不同的跟随方，
        #   整条历史分叉——"同种子同结果"就毁在这一行裸迭代上。
        for c in sorted(cands):
            if c in def_side or c == atk_ent:
                continue
            cm = self.entity_members(c)
            if not cm:
                continue
            if any(self.war_between(m, x2) for m in cm for x2 in members):
                continue        # 已与攻方交战，不并入守侧
            if any(self.war_between(m, d) for m in cm for d in def_members):
                continue        # 已与守侧某员交战，不并入
            if self._truce_blocks_war_join(cm, members):
                # ★ **已有的保障/共同防御在休战期内不触发**（用户 2026-09-20：
                #   「有和约时，防御条约和独立保障应该无法执行」）——它正与攻方某国
                #   休战中，就不把它拖进这场战争：**和约优先于盟约**，否则盟友一开战
                #   和约当场作废（那"和约"就白签了）。
                skipped.append(c)
                continue
            def_side.add(c)
            def_members = def_members + cm
        followers = [c for c in def_members if c != b]
        # 和约拦下的援军：**通知当事人与守方**（"预期中的援军为什么没来"——
        # 不说就成了第三个"结果不告诉当事人"的洞）
        for c in skipped:
            self.log(f"⚠ {self.entity_label(c)} 的保障/共同防御义务**未触发**：它与攻方有和约在身"
                     f"（和约优先，未参战）", phase="外交",
                     parties=self.entity_members(c) + [b])
        # 防守义务优先：守侧成员与进攻侧实体的保障/共同防御自动解除；逐国通知
        for c in followers:
            self._break_pacts_between(self.entity_of(c), atk_ent)
            self.proclaim(f"⚔ {c} 因联盟/共同防御/保障义务被拖入守侧，自动参战打 "
                          f"{'、'.join(members)}（跟随方不能单独议和，主导者议和则整条战线停战）")
        leader = self.entity_chief(atk_ent) or members[0]
        self.wars.append({"id": self._next_war_id(), "atk": leader, "def": b,
                          "followers": followers,
                          "atk_followers": [m for m in members if m != leader],
                          "turn": self.turn})
        mtxt = "、".join(members)
        self.proclaim(f"⚔ {proposer} 发起：{mtxt}（{self.entity_label(atk_ent)}）对 "
                      f"{self.entity_label(def_ent)} 宣战！")
        if leader == proposer and len(members) == 1:
            self.proclaim(f"⚔ {proposer} 对 {b} 宣战！{b} 必须应战")
        jtxt = f"；守侧传导参战：{'、'.join(followers)}" if followers else ""
        return True, f"对 {self.entity_label(def_ent)} 宣战（进攻侧：{mtxt}）{jtxt}"

    def _peace_rep(self, w: dict, side: str) -> str:
        """某侧的谈判代表：主导者本人；主导者属联盟时 = 联盟主体（盟主）——
        议和必须由联盟主体身份出面，普通成员/跟随方不能谈。"""
        leader = w["atk"] if side == "atk" else w["def"]
        if leader in self.nations:
            bloc = self.bloc_of(leader)
            if bloc is not None:
                chief = self.bloc_chief(bloc)
                if chief in self.nations and chief != leader:
                    return chief
        return leader

    def offer_peace(self, a: str, b: str, kind: str, gold: int = 0, note: str = "",
                    truce: int = 0) -> tuple[bool, str]:
        if kind not in ("pay", "demand", "white", "submit", "subjugate"):
            return False, "kind 须为 pay(我方赔款) / demand(要求对方赔款) / white(白和) / submit(称臣) / subjugate(要求对方称臣)"
        if not isinstance(truce, int) or truce < 0:
            return False, "休战回合数须为非负整数（0=不休战，自行约定）"
        if a == b or a not in self.nations or b not in self.nations:
            return False, "双方必须是两个现存国家"
        w = self._war_of(a, b)
        if w is None:
            return False, "你们并不在交战"
        # 谈判代表：每侧=主导者；主导者有联盟时=其盟主（联盟主体身份）
        a_side = "atk" if a in self._war_sides(w)[0] else "def"
        b_side = "def" if a_side == "atk" else "atk"
        rep_a, rep_b = self._peace_rep(w, a_side), self._peace_rep(w, b_side)
        if a != rep_a:
            hint = f"（你方主体是盟主 {rep_a}，由其出面并经联盟投票）" if rep_a != w["atk" if a_side == "atk" else "def"] else ""
            return False, f"议和必须由本方谈判代表 {rep_a} 出面{hint}"
        if b != rep_b:
            return False, f"求和对象须为对方谈判代表 {rep_b}（主导者或其盟主）"
        if kind in ("submit", "subjugate"):
            if gold:
                return False, "附庸和平不附带金钱赔款"
            overlord, subject = (b, a) if kind == "submit" else (a, b)
            bad = self._vassal_block(subject, overlord, peace=True)
            if bad:
                return False, bad
            if any(x["id"] != w["id"] and set(self._war_sides(x)[0] + self._war_sides(x)[1])
                   & set(self.entity_members(self.entity_of(a)) + self.entity_members(self.entity_of(b)))
                   for x in self.wars):
                return False, "须先结束其他战线，才能通过和约建立附庸关系"
        elif gold < 0 or (kind in ("pay", "demand") and gold == 0):
            if kind == "white":
                gold = 0
            else:
                return False, "赔款量需为正整数（white 则不带赔款）"
        bloc = self.bloc_of(a)
        # 判断"是否联盟主体出面"必须用权威 bloc_chief，不能用 members[0]——
        # bloc_transfer 后盟主已换人，members[0] 仍是创始旧盟主，会让新盟主绕过投票私签和平。
        if bloc is not None and self.bloc_chief(bloc) == a:
            # 联盟主体议和须先过联盟投票（多数决）
            v = self._new_vote("议和", bloc["name"], a,
                               {"type": "offer", "war_id": w["id"], "to": rep_b,
                                "kind": kind, "gold": gold, "note": note, "truce": truce})
            self.log(f"🗳 {a} 发起联盟议和投票（「{bloc['name']}」）：向 {rep_b} 求和（投票#{v['id']}，多数决）",
                     phase="外交", nation=a)
            return True, (f"已发起联盟议和投票（投票#{v['id']}）：多数同意后正式向 {rep_b} 提出；"
                          f"成员用 vote {v['id']} true/false 表态")
        return self._record_peace_offer(w, a, b, kind, gold, note, truce)

    def _record_peace_offer(self, w: dict, a: str, b: str, kind: str, gold: int,
                            note: str, truce: int) -> tuple[bool, str]:
        """记录求和提议（投票通过后或非联盟主体直接提出）。"""
        self.peace_offers.append({"id": self._next_offer_id(), "a": a, "b": b,
                                  "kind": kind, "gold": gold, "note": note, "turn": self.turn,
                                  "war_id": w["id"], "truce": truce})
        k = {"pay": f"{a} 愿赔 {gold} 金求和", "demand": f"{a} 要求 {b} 赔 {gold} 金",
             "white": "白和（不赔不索）",
             "submit": f"{a} 愿向 {b} 称臣", "subjugate": f"{a} 要求 {b} 称臣"}[kind]
        if truce > 0:
            k += f"，约定休战 {truce} 回合"
        self.log(f"🕊 求和提议：{k}" + (f"——{note}" if note else ""), phase="外交", nation=a)
        return True, f"已向 {b} 提出：{k}，等 {b} 在下一回合回应（accept/reject 议和 id）"

    def accept_peace(self, me: str, offer_id: int) -> tuple[bool, str]:
        p = next((x for x in self.peace_offers if x["id"] == offer_id and x["b"] == me), None)
        if p is None:
            return False, "没有这个给你的求和提议"
        bloc = self.bloc_of(me)
        # 同 offer_peace：认盟主用 bloc_chief，防 bloc_transfer 后新盟主绕过投票直接接受
        if bloc is not None and self.bloc_chief(bloc) == me:
            # 联盟主体接受议和须先过联盟投票（多数决）
            v = self._new_vote("议和", bloc["name"], me, {"type": "accept", "offer_id": offer_id})
            self.log(f"🗳 {me} 发起联盟议和投票（「{bloc['name']}」）：接受 {p['a']} 的求和（投票#{v['id']}）",
                     phase="外交", nation=me)
            return True, (f"已发起联盟议和投票（投票#{v['id']}）：多数同意后正式接受；"
                          f"成员用 vote {v['id']} true/false 表态")
        return self._do_accept_peace(p)

    def _do_accept_peace(self, p: dict) -> tuple[bool, str]:
        a, b, kind, gold = p["a"], p["b"], p["kind"], p["gold"]
        me = p["b"]
        w = self._war_of(a, b)
        if w is None:
            self.peace_offers.remove(p)
            return False, "你们已不在交战（提议作废）"
        if kind == "pay":
            if self.res(a, "黄金") < gold:
                return False, f"{a} 国库不足 {gold}，赔不起这个价"
            self.add_res(a, "黄金", -gold)
            self.add_res(b, "黄金", gold)
        elif kind == "demand":
            if self.res(b, "黄金") < gold:
                return False, f"你的国库不足 {gold}，付不起这笔赔款（可回提 pay 求和）"
            self.add_res(b, "黄金", -gold)
            self.add_res(a, "黄金", gold)
        self.peace_offers.remove(p)
        self.peace_offers = [x for x in self.peace_offers if x.get("war_id") != w["id"]]
        members = [w["atk"], w["def"]] + list(w["followers"]) + list(w.get("atk_followers", []))
        self.wars.remove(w)
        # 战争结束：参战各国实际持有的地块重算为核心领土（议和即对现状追认）
        self._snapshot_cores(members)
        # 自行约定休战期：主导者议和时定的 truce 覆盖整条战线（含跟随方）
        truce_n = int(p.get("truce") or 0)
        until = 0
        if truce_n > 0:
            until = self.turn + truce_n
            for x in [w["atk"]] + list(w.get("atk_followers", [])):
                for y in [w["def"]] + list(w["followers"]):
                    # ★ **只许延长、不许缩短**（用户 2026-10-11 报的洞：强制和平期间在途的
                    #   和平提议落地，会把「全天下强制休战」覆盖成它自己那条短的）。
                    #   2026-10-07 起"亡国 ⇒ 全天下强制休战"是防雪球的地基，谁都不该用
                    #   一纸短休战把它抹掉——那条路只能是 `max`（收在 `set_truce` 里）。
                    self.set_truce(x, y, until)
        for m in self.armies:
            # ★ 只清站在**有主地**上的军队（main `disengage`）：野地上打野人的仗不是「战争」，
            #   议和不该顺手把它掐掉
            if m["owner"] in members and m.get("engaged") and self.owned_by(m["x"], m["y"]) is not None:
                m["engaged"] = False  # 整条战线（含跟随方）一并解除交战
        if kind in ("submit", "subjugate"):
            overlord, subject = (b, a) if kind == "submit" else (a, b)
            bloc = self.bloc_of(subject)
            if bloc is not None:                       # main `_secede_for_submission`：称臣代表退出原联盟
                bloc["members"].remove(subject)
                if len(bloc["members"]) < 2:
                    self.blocs.remove(bloc)
                    for ent in (ent_bloc(bloc["name"]),):
                        self.drop_pacts_of(ent)
                    for _v in [v for v in self.votes if v["bloc"] == bloc["name"]]:
                        self._cancel_vote(_v, "联盟解散")
            self.vassals[subject] = {"overlord": overlord, "kind": "ordinary",
                                     "tribute_percent": self.ORDINARY_TRIBUTE}
            self.proclaim(f"🤝 {subject} 经和约向 {overlord} 称臣（附庸：上贡实际产出 "
                          f"{self.ORDINARY_TRIBUTE}%、并入其外交实体）")
        extra = {"pay": f"{a} 付 {b} {gold} 金", "demand": f"{b} 赔 {a} {gold} 金", "white": "白和",
                 "submit": f"{a} 向 {b} 称臣", "subjugate": f"{b} 向 {a} 称臣"}[kind]
        fls = list(w["followers"]) + list(w.get("atk_followers", []))
        who = ("（含跟随方 " + "、".join(fls) + "）") if fls else ""
        truce_txt = f"，休战 {truce_n} 回合（至第 {until} 回合）" if truce_n > 0 else ""
        self.proclaim(f"🕊 {a} 与 {b} 议和停战{who}{truce_txt}（{extra}）")
        return True, (f"停战议成：{extra}{truce_txt}。整条战线已停{who}，各方军队解除交战；"
                      f"各方实际持有地块重算为核心领土；滞留在对方领土的军队将于回合末遣返")

    def reject_peace(self, me: str, offer_id: int) -> tuple[bool, str]:
        p = next((x for x in self.peace_offers if x["id"] == offer_id and x["b"] == me), None)
        if p is None:
            return False, "没有这个求和提议"
        self.peace_offers.remove(p)
        # ★ 必须回到提议方（用户 2026-09-20：「外交拒绝不会回应到对应国家」）：
        #   原先这里**一条纪事都不写**，于是提议方既不知道被拒、也无法据"被拒"重估
        #   （面板里那条"你提的求和#N"下回合直接消失，等于无声无息）。拒绝**不广播**
        #   （"怎么谈的"不公开），只给桌上的两家。
        self.log(f"💔 {p['b']} 拒绝了 {p['a']} 的求和提议（战争继续）", phase="外交",
                 parties=[p["a"], p["b"]])
        return True, f"你拒绝 {p['a']} 的求和（战争继续）"

    # ------------------------------------------------------------- 关系查询
    def allied_between(self, a: str, b: str) -> bool:
        """a、b 是否同属一个外交实体（同一联盟的成员，或本来就是同一个国家）。"""
        return self.entity_of(a) == self.entity_of(b)

    def _war_sides(self, w: dict) -> tuple[list[str], list[str]]:
        """进攻方名单 / 防御方名单（含跟随方；atk_followers=随攻的进攻侧跟随方）。"""
        return ([w["atk"]] + list(w.get("atk_followers", [])),
                [w["def"]] + list(w["followers"]))

    def _war_of(self, a: str, b: str) -> dict | None:
        """a 与 b 处于对立双方的战争冲突；不在交战返回 None。"""
        for w in self.wars:
            atk, dfs = self._war_sides(w)
            if (a in atk and b in dfs) or (a in dfs and b in atk):
                return w
        return None

    def _next_war_id(self) -> int:
        self._war_id += 1
        return self._war_id

    def war_between(self, a: str, b: str) -> bool:
        return self._war_of(a, b) is not None

    def dp_between(self, a: str, b: str) -> bool:
        """两国**所在实体**之间是否有共同防御。"""
        return self.has_pact("共同防御", self.entity_of(a), self.entity_of(b))

    def guarantee_of(self, b: str) -> list[str]:
        """保障 b 所在实体的实体 id 列表（面板用 entity_label 转人话）。"""
        return self.guarantors_of(self.entity_of(b))

    # ------------------------------------------------------------- 关系汇总（供面板）
    def rel_desc(self, me: str) -> str:
        """本国视角的全员关系一览（实体口径：条约挂在实体上，不挂在国家上）。"""
        my = self.entity_of(me)
        out = []
        for n in self.alive():
            if n == me:
                continue
            them = self.entity_of(n)
            tags = []
            if them == my:
                tags.append(f"联盟成员（同属{self.entity_label(my)}）")
            if self.war_between(me, n):
                tags.append("交战")
            if self.has_pact("共同防御", my, them):
                tags.append("共同防御")
            if self.has_pact("保障", my, them):
                tags.append("本实体保障它")
            if self.has_pact("保障", them, my):
                tags.append("它保障本实体")
            out.append(f"{n}=" + ("、".join(tags) if tags else "中立"))
        return "  ".join(out) if out else "（只有你一个国了）"

    # ------------------------------------------------------------- 存档
    def save(self, path: str | Path) -> None:
        data = {
            "version": SAVE_VERSION,
            "size": self.size, "seed": self.seed, "turn": self.turn,
            "rng_state": list(self.rng.getstate()),
            "nations": {n: nat.res for n, nat in self.nations.items()},
            "order": self.order,
            # ★ 按**插入序**（物化序）写，**不 sorted**：读回来之后 `self.tiles` 的遍历顺序
            #   才与"从没存过档"的进程一致。sorted 会让续跑进程按坐标序遍历，而
            #   `prod_value` 这类钱账是**逐格浮点累加**的 ⇒ 累加顺序一变就差 1 ULP
            #   （`test_resume_mid_game_equals_straight_run` 抓的就是这种病）。
            "tiles": {f"{x},{y}": t for (x, y), t in self.tiles.items()},
            # ★ 野人**不进存档**（main 2026-11）：它们按需生成、由 `guard_once` 记"生过"。
            "armies": [a for a in self.armies if a["owner"] != "野人"],
            "next_army_seq": self.next_army_seq,
            "diplo_built": self.diplo_built,
            "nation_code": self.nation_code,
            "guard_once": [list(k) for k in sorted(self.guard_once)],
            "wars": self.wars,
            "war_id": self._war_id,
            "truce": [[a, b, until] for (a, b), until in self.truce.items()],
            "pacts": self.pacts,
            "bank": self.bank,
            "blocs": self.blocs,
            "votes": self.votes,
            "vote_id": self._vote_id,

            "mail_pending": self.mail_pending,
            "mailbox": self.mailbox,
            "summaries": self.summaries,
            "summary_blocks": self.summary_blocks,
            "long_memory": self.long_memory,
            "turn_memory": self.turn_memory,
            "gift_pending": self.gift_pending,
            "map_pending": self.map_pending,
            "maps": self.maps,
            "spy_pending": self.spy_pending,
            "econ_intel": self.econ_intel,
            "plans": self.plans,
            "polity": self.polity,
            "vassals": self.vassals,
            "extra_prompt": self.extra_prompt,
            "opening_guide": self.opening_guide,
            "peace_offers": self.peace_offers,
            "proposals": self.proposals,
            "offer_id": self._offer_id,
            "prices": self.prices,
            "market_inv": self.market_inv,
            "market_ref": self.market_ref,
            "market_period": self.market_period,
            "market_trades": self.market_trades,
            "market_volume": [[list(k), v] for k, v in self.market_volume.items()],
            "grid_short": self.grid_short,
            "gold_carry": self.gold_carry,
            "tribute_carry": self.tribute_carry,
            "auto_rules": self.auto_rules,
            "auto_runs": self.auto_runs,
            "diplo_pending": self.diplo_pending,
            "diplo_approved": self.diplo_approved,
            "diplo_cmd_id": self._diplo_cmd_id,
            "energy_report": self.energy_report,
            "econ_summary": self.econ_summary,
            "econ_reports": self.econ_reports,
            "ledger": self.ledger,
            "spend": self.spend,
            "gdp_run": self.gdp_run,
            "history": self.history,
            "history_seen": self.history_seen,
            # ★ 按 `USAGE_FIELDS` 补齐**每个国家**的格子（缺的补 0），而不是原样倒出
            #   `self.token_usage`：`gen=False` 的空壳世界、或建号后中途才补的国家，
            #   它可能只有一部分键甚至全空。load 侧是按国家重建的 ⇒ 不补齐就会出现
            #   "存的是 {}、读回来是 {秦:{...零...}}" 这种不对称，字节级往返立刻失败。
            "token_usage": {n: {k: int(self.token_usage.get(n, {}).get(k, 0) or 0)
                                for k in USAGE_FIELDS}
                            for n in self.nations},
        }
        # 契约断言：save 的键集合必须与 SAVE_KEYS 严丝合缝——忘了登记的新字段
        # 在第一次存档就炸（开发期），而不是变成静默丢档（运行时才发现=惨案）
        keys, want = set(data), set(SAVE_KEYS)
        if keys != want:
            raise RuntimeError(
                f"存档契约漂移：save 多出 {sorted(keys - want)}、少写 {sorted(want - keys)}"
                f"——新增状态字段请同步 SAVE_KEYS 清单与 load 搬运")
        # 原子写（tmp+rename）：turn_memory 使存档变大近一倍，避免写一半中断损坏档
        tmp = Path(str(path) + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, path: str | Path) -> "World":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        ver = data.get("version")
        if ver is None:
            raise SaveFormatError(
                f"存档没有版本号（无版本号＝上古档，没法判断该按哪套语义读）：请用 --new 重开，"
                f"或删掉 {path}")
        if not (SAVE_MIN_VERSION <= int(ver) <= SAVE_VERSION):
            raise SaveFormatError(
                f"存档版本超出可读区间（档内 {ver}，本代码可读 {SAVE_MIN_VERSION}~{SAVE_VERSION}）："
                f"比代码新的档读不懂；比 {SAVE_MIN_VERSION} 老的档属于「删过字段」的那几版、"
                f"语义对不上。请用 --new 重开，或删掉 {path}")
        # ★ 追加式兼容：老档缺的**追加字段**按默认补齐（只加不删 ⇒ 老档永远开得起来）
        for k, dv in SAVE_DEFAULTS.items():
            if k not in data:
                data[k] = copy.deepcopy(dv)
        missing = [k for k in SAVE_KEYS if k not in data]
        if missing:
            raise SaveFormatError(
                f"存档缺字段：{missing}（这些不是已知的追加字段——文件被截断或改坏），请重开一局")
        w = cls(size=data["size"], seed=data["seed"], gen=False)   # 空壳：世界由存档整体还原（不预建默认三国，否则残出幽灵地块）
        w.turn = data["turn"]
        ver, internal, gauss = data["rng_state"]
        w.rng.setstate((ver, tuple(internal), gauss))
        # 以下全部按"版本已核对、键已核对齐"直读：只重建序列化丢掉的容器类型
        # （tuple/frozenset/set），不再有任何旧格式迁移分支。
        w.nations = {n: Nation(n, res) for n, res in data["nations"].items()}
        w.order = data["order"]
        w.mailbox = {n: data["mailbox"].get(n, []) for n in w.nations}
        # ★ 记忆 vs 在局状态的取舍**与 `_eliminate_if_dead` 逐条对齐**（两边不一致就会出现
        #   "存一次档亡国之君就失忆"这种只在重启后现形的 bug）：
        #   · **记忆**（summaries / summary_blocks / long_memory / polity）**含已亡国**——
        #     结算厅要请他们入场（2026-10-08 用户：「结算厅要结算所有国家」）。
        #   · **在局状态**（turn_memory 逐字缓冲区 / maps / econ_intel / plans / extra_prompt /
        #     mailbox）只留存活国——死了就不再行动，用不上，且 turn_memory 是存档里最大的一块。
        # summaries 条目恒为 {turn,text}（旧字符串格式随版本锁死一并退休）
        w.summaries = {n: [{"turn": int(it["turn"]), "text": str(it["text"])}
                           for it in lst] for n, lst in data["summaries"].items()}
        w.summary_blocks = {n: list(v) for n, v in data["summary_blocks"].items()}
        w.long_memory = {n: str(v) for n, v in data["long_memory"].items()}
        w.turn_memory = {n: list(v) for n, v in data["turn_memory"].items() if n in w.nations}
        w.gift_pending = data["gift_pending"]
        w.map_pending = data["map_pending"]
        w.maps = {n: list(v) for n, v in data["maps"].items() if n in w.nations}
        w.spy_pending = data["spy_pending"]
        w.econ_intel = {n: list(v) for n, v in data["econ_intel"].items() if n in w.nations}
        w.plans = {n: dict(v) for n, v in data["plans"].items() if n in w.nations}
        w.polity = dict(data["polity"])       # 身份：亡国之君的匈奴口吻也靠它（见上）
        w.extra_prompt = {n: dict(v) for n, v in data["extra_prompt"].items() if n in w.nations}
        w.opening_guide = bool(data["opening_guide"])
        w.armies = data["armies"]
        # 野地索取顺序计数器：从档内现有最大入场序号续起（未参战军队无此键，按 0 计）
        w._engage_seq = max((int(a.get("engage_seq", 0) or 0) for a in w.armies), default=0)
        # 军队编号：各国独立番号(AI 所见) + 国家码×1e8 全局唯一 gid(内部)
        w.nation_code = {k: int(v) for k, v in data["nation_code"].items()}
        w._next_code = max(w.nation_code.values(), default=0) + 1
        w.next_army_seq = {k: int(v) for k, v in data["next_army_seq"].items()}
        w.diplo_built = {k: int(v) for k, v in data["diplo_built"].items() if k in w.nations}
        # 战争恒为冲突对象 {id,atk,def,followers,atk_followers,turn}（旧 [a,b] 边对已随版本退休）
        w.wars = []
        w._war_id = int(data["war_id"])
        for item in data["wars"]:
            w.wars.append({"id": int(item["id"]), "atk": item["atk"], "def": item["def"],
                           "followers": list(item.get("followers", [])),
                           "atk_followers": list(item.get("atk_followers", [])),
                           "turn": int(item["turn"])})
            w._war_id = max(w._war_id, int(item["id"]) + 1)
        # ★ 休战表 2026-10-11 起按**实体 id**存（与条约表同口径）；旧档写的是裸国名，
        #   读进来一律迁成 `国:名字`——不迁的话老档续局时**所有和约凭空消失**。
        w.truce = {_pair(_truce_key_id(ab[0]), _truce_key_id(ab[1])): int(ab[2])
                   for ab in data["truce"]}
        # 联盟：members 已过滤亡国，chief 权威
        w.blocs = []
        for b in data["blocs"]:
            members = [m for m in b["members"] if m in w.nations]
            if members:
                w.blocs.append({"name": str(b["name"]), "members": members,
                                "chief": b["chief"], "turn": int(b["turn"])})
        w.votes = [dict(v) for v in data["votes"]]
        w._vote_id = int(data["vote_id"])
        w.pacts = [dict(p) for p in data["pacts"]]
        # 世界央行：on/rate/loans 全在档里（开关也持久化——续局不该把央行开了又关）
        _bk = data["bank"]
        w.bank = {"on": bool(_bk.get("on")), "rate": float(_bk.get("rate", 0.0)),
                  "loans": {k: dict(v) for k, v in (_bk.get("loans") or {}).items()}}
        w.mail_pending = data["mail_pending"]
        w.peace_offers = data["peace_offers"]
        w.proposals = data["proposals"]
        w._offer_id = data["offer_id"]
        w.prices = {g: float(data["prices"][g]) for g in TRADEABLE}
        w.market_inv = {g: int(data["market_inv"][g]) for g in TRADEABLE}
        w.market_ref = {g: float(data["market_ref"][g]) for g in TRADEABLE}
        w.market_period = int(data["market_period"])
        w.market_trades = [dict(t) for t in data["market_trades"]]
        w.market_volume = {tuple(k): int(v) for k, v in data["market_volume"]}
        w.history = data["history"]
        w.history_seen = data["history_seen"]
        # 电网/结算摘要也持久化：否则续档后第一回合 all 面板电力 0、上回合结算丢失
        w.grid_short = {n: bool(v) for n, v in data["grid_short"].items() if n in w.nations}
        w.gold_carry = {n: float(v) for n, v in data["gold_carry"].items() if n in w.nations}
        w.tribute_carry = {k: int(v) for k, v in data.get("tribute_carry", {}).items()}
        w.auto_rules = data.get("auto_rules", {})
        w.auto_runs = data.get("auto_runs", {})
        w.diplo_pending = list(data.get("diplo_pending", []))
        w.diplo_approved = list(data.get("diplo_approved", []))
        w._diplo_cmd_id = int(data.get("diplo_cmd_id", 0))
        w.energy_report = {n: tuple(v) for n, v in data["energy_report"].items() if n in w.nations}
        w.econ_summary = {n: s for n, s in data["econ_summary"].items() if n in w.nations}
        w.econ_reports = {n: list(v) for n, v in data["econ_reports"].items() if n in w.nations}
        # ★ ledger 按 LEDGER_FIELDS 归一：追加式政策下新加的账目字段在老档里不存在，
        #   而 `_ledger(n)[新键] += x` 是直接取键 ⇒ 不补就会 KeyError。缺的补 0，有的原样。
        w.ledger = {n: {**{k: float(v.get(k, 0.0) or 0.0) for k in LEDGER_FIELDS},
                        "_since": max(1, int(v["_since"]))}
                    for n, v in data["ledger"].items() if n in w.nations}
        w.spend = {n: {k: float(v[k]) for k in SPEND_FIELDS}
                   for n, v in data["spend"].items() if n in w.nations}
        # 每回合的 GDP run-rate（央行授信口径）。旧档（v4 之前）没有这个键 ⇒ 空表，
        # `nation_gdp` 会退回最新一期报表的 GDP——不许把"缺字段"读成"GDP=0、授信=0"。
        w.gdp_run = {n: float(v) for n, v in (data.get("gdp_run") or {}).items()
                     if n in w.nations}
        # 全期累计 token 用量：**统计字段，不参与结算**。按存档里的国家重建零值骨架，
        # 再把档内已有的数搬进来 —— 老档（没有这个键）也能正常开，只是从 0 起算。
        w.token_usage = {
            n: {k: int((data.get("token_usage") or {}).get(n, {}).get(k, 0) or 0)
                for k in USAGE_FIELDS}
            for n in w.nations
        }
        # 地块：存档即完整（recruited/built/buildings/pending/core 与全部建筑键都在），
        # 只做 "x,y" 字符串键 → (x,y) 元组键的还原，不再补字段
        for k, t in data["tiles"].items():
            x, y = map(int, k.split(","))
            w.tiles[(x, y)] = t
        w.guard_once = {tuple(k) for k in data["guard_once"]}
        # ★ 野人按需生成（main 2026-11）：读档不预铺、也不补齐——只要 guard_once。
        # ★ 2026-09-21 规则改版（灭国条件：领土尽失 → 市政厅尽失）对**老档**的迁移：
        #   老档里的国家一座市政厅都没有（那时不送），照新规则**第一次丢地就当场亡国**，
        #   哪怕它还握着二十块地——那不是新规则的意思，是它没赶上新开局。
        #   ⇒ 给每个还活着的国家补发一座（`_seed_townhall` 落在它的核心格）。
        #   只补**活着**的国家：死国没有国祚可言，它的地早就归了别人。
        for nm in list(w.nations):
            if not w.has_townhall(nm):
                w._seed_townhall(nm)
        return w



# ---------------------------------------------------------------------------
# 外交命令队列 + 手续费（main：外交命令在行动期提交并预扣费，经「干跑校验」才入队；
# 全体行动结束后在 relations 挂点按优先级统一重验、生效或退款）。
# legacy 原是即时生效 ⇒ 同回合先后动作、互相宣战、上贡起算期都与 main 不同。
# 做法：保留原方法当「立即执行版」（`_diplo_now=True` 时直通），对外的同名方法改为提交到队列。
# ---------------------------------------------------------------------------
DIPLO_PRIORITY = {
    "accept_peace": 10, "reject_peace": 11, "offer_peace": 12,
    "bloc_dissolve": 20, "bloc_leave": 21, "bloc_transfer": 22, "bloc_rename": 23,
    "bloc_found": 24, "bloc_join": 25, "cancel_guarantee": 30, "break_defense": 31,
    "guarantee": 32, "propose_defense": 33, "reject_proposal": 34, "accept_proposal": 35,
    "propose_vassalage": 26, "submit_vassalage": 27, "release_vassal": 20,
    "independence_war": 90, "declare_war": 100,
}
# 方法名 → (动作名, actor 位置, target 位置, 目标有外交中心则免费, 固定费用)；固定费用 None=按外交费公式
DIPLO_QUEUED = {
    "declare_war": ("declare_war", 0, 1, False, None),
    "offer_peace": ("offer_peace", 0, 1, True, None),
    "accept_peace": ("accept_peace", 0, None, False, 0),
    "reject_peace": ("reject_peace", 0, None, False, 0),
    "declare_guarantee": ("guarantee", 0, 1, False, None),
    "cancel_guarantee": ("cancel_guarantee", 0, 1, False, None),
    "propose_pact": ("propose_defense", 1, 2, True, None),
    "break_pact": ("break_defense", 1, 2, False, None),
    "accept_pact": ("accept_proposal", 0, None, False, 0),
    "reject_pact": ("reject_proposal", 0, None, False, 0),
    "propose_bloc": ("bloc_found", 0, None, False, 100),
    "bloc_join": ("bloc_join", 0, None, False, None),
    "bloc_leave": ("bloc_leave", 0, None, False, None),
    "bloc_transfer": ("bloc_transfer", 0, None, False, 0),
    "bloc_rename": ("bloc_rename", 0, None, False, 0),
    "bloc_dissolve": ("bloc_dissolve", 0, None, False, 0),
    "propose_vassalage": ("propose_vassalage", 0, 1, False, None),
    "submit_vassalage": ("submit_vassalage", 0, 1, False, None),
    "release_vassal": ("release_vassal", 0, 1, False, None),
    "independence_war": ("independence_war", 0, None, False, None),
}
# 立即生效但收费的情报/金融动作
DIPLO_IMMEDIATE_FEE = {"gift": (0, 1), "share_map": (0, 1), "bank_loan": (0, None)}


def _vote_action(v: dict) -> str:
    """投票议案对应的外交动作名（决定执行优先级）。"""
    pl, kind = v["payload"], v["kind"]
    if kind == "宣战":
        return "declare_war"
    if kind == "入盟":
        return "bloc_join"
    if kind == "议和":
        return "offer_peace" if pl.get("type") == "offer" else "accept_peace"
    if pl.get("cancel"):
        return "cancel_guarantee" if pl["pact"] == "保障" else "break_defense"
    if pl.get("offer"):
        return "propose_defense"
    return "guarantee" if pl.get("pact") == "保障" and pl.get("offer_id") is None else "accept_proposal"


def _install_diplo_queue(cls):
    import functools

    def centers(self, n):
        return self.nation_building_count(n, "外交中心") if n in self.nations else 0

    def base_fee(self, actor, target=None, *, free_if_target_center=False):
        if target and target in self.nations and actor in self.nations \
                and self.entity_of(actor) == self.entity_of(target):
            return 0
        if free_if_target_center and target and centers(self, target):
            return 0
        fee = DIPLO_COST
        for _ in range(centers(self, actor)):
            fee = max(DIPLO_CENTER_MIN_COST, fee // 2)
        return fee

    def draft(self, light: bool = False):
        """干跑用的世界副本：地图生成器与历史不拷贝（只读/只追加，不影响校验）。
        light=True（RL 候选的外交可执行性）：另外**共享**地块与军队表——外交类方法在干跑里只动外交字典，
        不碰地块/军队（`rl/candidates` 的自检会校验共享对象前后逐位不变）。深拷贝从 ~36 ms 降到 ~几 ms。"""
        memo = {id(self.history): []}
        if self._mapgen is not None:
            memo[id(self._mapgen)] = self._mapgen
        if light:
            memo[id(self.tiles)] = self.tiles
            memo[id(self.armies)] = self.armies
            for _a in ("troops_cache", "_troops", "guardians_cache"):
                _o = getattr(self, _a, None)
                if _o is not None:
                    memo[id(_o)] = _o
        d = copy.deepcopy(self, memo)
        d._diplo_now = True
        return d
    cls._draft = draft

    def queue(name, spec):
        action, a_i, t_i, free_c, fixed = spec
        inner = getattr(cls, name)
        setattr(cls, "_now_" + name, inner)

        @functools.wraps(inner)
        def run(self, *args, **kw):
            if self._diplo_now:
                return inner(self, *args, **kw)
            actor = args[a_i]
            if actor not in self.nations:
                return False, f"国家 {actor} 不存在"
            key = [actor, action, [repr(x) for x in args], sorted((k, repr(v)) for k, v in kw.items())]
            if any(c["key"] == key for c in self.diplo_pending):
                return True, "该命令已在本回合待结算队列中"
            target = args[t_i] if t_i is not None else None
            fee = fixed if fixed is not None else base_fee(self, actor, target, free_if_target_center=free_c)
            if fee and self.res(actor, "黄金") < fee:
                return False, f"现金不足以支付外交手续费：需 {fee} 金，现有 {self.res(actor, '黄金')} 金"
            ok, msg = getattr(self._draft(), name)(*args, **kw)      # 干跑校验（不改本世界）
            if not ok:
                return False, msg
            if fee:
                self.add_res(actor, "黄金", -fee)
            self._diplo_cmd_id += 1
            self.diplo_pending.append({"id": self._diplo_cmd_id, "actor": actor, "action": action, "method": name,
                                       "args": list(args), "kw": kw, "fee": fee, "key": key, "turn": self.turn})
            return True, f"已提交：{action}（回合结算时统一生效，失败退款）" + (f"；预扣外交费 {fee} 金" if fee else "")
        setattr(cls, name, run)

    for _n, _sp in DIPLO_QUEUED.items():
        queue(_n, _sp)

    def resolve_diplomacy(self):
        """外交结算：提交的命令 + 已通过的联盟议案，按 (优先级, 发起国, 编号) 统一重验并执行；失败退费。"""
        tasks = []
        for c in self.diplo_pending:
            tasks.append((DIPLO_PRIORITY[c["action"]], c["actor"], c["id"], "cmd", c))
        for v in self.diplo_approved:
            self._diplo_cmd_id += 1
            tasks.append((DIPLO_PRIORITY[_vote_action(v)], v["proposer"], self._diplo_cmd_id, "vote", v))
        self.diplo_pending, self.diplo_approved = [], []
        self._diplo_now = True
        try:
            for _p, _a, _i, kind, c in sorted(tasks, key=lambda t: t[:3]):
                if kind == "vote":
                    ok, msg = self._execute_vote(c)
                    continue
                if c["actor"] not in self.nations:
                    continue            # 提交国已亡：命令作废（费用随国家消失）
                ok, msg = getattr(self, c["method"])(*c["args"], **c["kw"])
                if not ok and c["fee"]:
                    self.add_res(c["actor"], "黄金", c["fee"])          # 结算时重验失败 → 退款
                    self.log(f"↩ {c['actor']} 的外交命令 {c['action']} 在结算时失效，退还 {c['fee']} 金：{msg}",
                             phase="外交", nation=c["actor"])
        finally:
            self._diplo_now = False
    cls.resolve_diplomacy = resolve_diplomacy

    def end_turn(self, name):
        """结束本国行动（main `finish`）：本国未回应的邀约/和平提议自动拒绝（免费），未投的到期表决记反对。"""
        answered = {(c["action"], c["args"][1]) for c in self.diplo_pending
                    if c["actor"] == name and c["action"] in ("accept_peace", "reject_peace", "accept_proposal", "reject_proposal")}
        out = []
        for p in list(self.peace_offers):
            if p["b"] == name and not ({("accept_peace", p["id"]), ("reject_peace", p["id"])} & answered):
                out.append(self.reject_peace(name, p["id"]))
        for p in list(self.proposals):
            if {("accept_proposal", p["id"]), ("reject_proposal", p["id"])} & answered:
                continue
            if p["kind"] == "联盟":
                if name in p.get("invitees", []) and name not in p.get("accepted", []):
                    out.append(self.reject_pact(name, p["id"]))
            elif p["kind"] == "附庸":
                if p.get("B") == ent_nation(name):
                    out.append(self.reject_pact(name, p["id"]))
            elif p.get("B") == self.entity_of(name) and self.entity_chief(p["B"]) == name:
                out.append(self.reject_pact(name, p["id"]))
        for v in list(self.votes):
            bloc = self.bloc_by_name(v["bloc"])
            if bloc and name in bloc["members"] and v.get("deadline", v["turn"] + 1) == self.turn \
                    and name not in v["votes"] and not (v["kind"] == "入盟" and v["payload"].get("candidate") == name):
                out.append(self.cast_vote(name, v["id"], False))
        return True, f"{name} 结束行动；自动处理 {len(out)} 项未回应事项"
    cls.end_turn = end_turn

    # ---- 立即生效但收费的动作（赠礼/换图/借款）与来信 ----
    def immediate_fee(name, a_i, t_i):
        inner = getattr(cls, name)

        @functools.wraps(inner)
        def run(self, *args, **kw):
            actor = args[a_i]
            target = args[t_i] if t_i is not None else None
            fee = base_fee(self, actor, target) if actor in self.nations else 0
            if fee:
                if self.res(actor, "黄金") < fee:
                    return False, f"现金不足以支付外交手续费：需 {fee} 金，现有 {self.res(actor, '黄金')} 金"
                self.add_res(actor, "黄金", -fee)
            ok, msg = inner(self, *args, **kw)
            if not ok and fee:
                self.add_res(actor, "黄金", fee)
            return ok, msg
        setattr(cls, name, run)

    # 普通附庸没有对外外交权：赠礼/通信/换图/谍报只能在宗主外交实体内部
    def vassal_gate(name):
        inner = getattr(cls, name)

        @functools.wraps(inner)
        def run(self, *args, **kw):
            frm, to = args[0], args[1]
            v = self.vassals.get(frm)
            if v and v.get("kind", "ordinary") == "ordinary" and frm in self.nations and to in self.nations \
                    and self.entity_of(frm) != self.entity_of(to):
                return False, "普通附庸没有对外外交权，只能在宗主外交实体内部通信"
            return inner(self, *args, **kw)
        setattr(cls, name, run)

    for _n in ("gift", "share_map", "send_mail", "spy"):
        vassal_gate(_n)
    for _n, (_a, _t) in DIPLO_IMMEDIATE_FEE.items():
        immediate_fee(_n, _a, _t)

    inner_mail = cls.send_mail

    @functools.wraps(inner_mail)
    def send_mail(self, frm, to, text):
        fee = 0
        if frm in self.nations and to in self.nations:
            fee = letter_cost(text, self.entity_of(frm) == self.entity_of(to), centers(self, frm))
        if fee:
            if self.res(frm, "黄金") < fee:
                return False, f"现金不足以支付信件费用：需 {fee} 金"
            self.add_res(frm, "黄金", -fee)
        ok, msg = inner_mail(self, frm, to, text)
        if not ok and fee:
            self.add_res(frm, "黄金", fee)
        return ok, msg
    cls.send_mail = send_mail


_install_diplo_queue(World)


# ---------------------------------------------------------------------------
# 自动交易（main `market.automation`）：常设条件，本国**成功结束行动后**、世界结算前执行一次；
# 先卖后买，同一套曲线/零头/原子成交，没有额外货源或资金。
# ---------------------------------------------------------------------------
def _install_auto_trade(cls):
    import functools

    def set_auto_trade(self, name, good, enabled=True, buy_below=None, sell_above=None, buy_limit=50,
                       sell_limit=50, reserve_gold=0, max_buy_price=None, min_sell_price=None):
        if name not in self.nations:
            return False, f"国家 {name} 不存在"
        if good not in TRADEABLE:
            return False, f"「{good}」不可交易"
        if not isinstance(enabled, bool):
            return False, "自动交易开关须为布尔值"
        for k, v in (("buy_below", buy_below), ("sell_above", sell_above), ("reserve_gold", reserve_gold)):
            if v is not None and (type(v) is not int or v < 0):
                return False, f"{k} 须为非负整数"
        for k, v in (("buy_limit", buy_limit), ("sell_limit", sell_limit)):
            if type(v) is not int or v < 1:
                return False, f"{k} 须为正整数"
        for k, v in (("max_buy_price", max_buy_price), ("min_sell_price", min_sell_price)):
            if v is not None and (not isinstance(v, (int, float)) or isinstance(v, bool) or v < 0):
                return False, f"{k} 须为非负数或 null"
        if buy_below is not None and sell_above is not None and buy_below > sell_above:
            return False, "自动购买目标不能高于自动出售保留量"
        self.auto_rules.setdefault(name, {})[good] = dict(
            enabled=enabled, buy_below=buy_below, sell_above=sell_above, buy_limit=buy_limit,
            sell_limit=sell_limit, reserve_gold=reserve_gold, max_buy_price=max_buy_price,
            min_sell_price=min_sell_price)
        return True, f"已设置 {good} 自动交易"

    def remove_auto_trade(self, name, good):
        if name not in self.nations or good not in TRADEABLE:
            return False, "国家或商品不存在"
        removed = self.auto_rules.get(name, {}).pop(good, None)
        if not self.auto_rules.get(name):
            self.auto_rules.pop(name, None)
        return True, "已删除" if removed is not None else "没有该自动交易设置"

    def _auto_quantity(self, name, rule, good, side, requested):
        stock = self.res(name, good)
        cap = min(requested, self.market_inv[good]) if side == "buy" else min(requested, math.floor(stock))
        budget = max(0, self.res(name, "黄金") - rule["reserve_gold"])

        def allowed(q):
            unit, exact = self.market_walk(good, q, side, name)
            gold, _ = self._market_cash(name, exact, side)
            avg = exact / q
            if side == "buy":
                return gold <= budget and (rule["max_buy_price"] is None or avg <= rule["max_buy_price"])
            return rule["min_sell_price"] is None or avg >= rule["min_sell_price"]
        lo, hi = 0, cap
        while lo < hi:                  # 整单均价随量单调变差：取最大的可行整数量
            mid = (lo + hi + 1) // 2
            if allowed(mid):
                lo = mid
            else:
                hi = mid - 1
        return lo

    def run_auto_trades(self, name):
        prev = self.auto_runs.get(name)
        if prev is not None and prev["period"] == self.turn:
            return {"period": self.turn, "orders": [], "already_executed": True}
        rules = self.auto_rules.get(name, {})
        if not rules:
            return {"period": self.turn, "orders": []}
        orders = []
        for side in ("sell", "buy"):                 # 先卖后买；商品按市场上架顺序
            for good in TRADEABLE:
                rule = rules.get(good)
                if rule is None or not rule["enabled"]:
                    continue
                target = rule["buy_below"] if side == "buy" else rule["sell_above"]
                if target is None:
                    continue
                stock = self.res(name, good)
                gap = target - stock if side == "buy" else stock - target
                requested = min(math.ceil(gap) if side == "buy" else math.floor(gap),
                                rule["buy_limit"] if side == "buy" else rule["sell_limit"])
                if requested < 1:
                    continue
                o = {"resource": good, "side": side, "requested": requested, "quantity": 0, "status": "blocked"}
                q = self._auto_quantity(name, rule, good, side, requested)
                if q:
                    ok, msg = (self.buy if side == "buy" else self.sell)(name, good, q)
                    if ok:
                        o.update(status="filled" if q == requested else "partial", quantity=q)
                    else:
                        o["reason"] = msg
                else:
                    o["reason"] = "市场缺货、可用资金或整单均价不满足限制" if side == "buy" else "整单均价低于出售底价"
                orders.append(o)
        res = {"period": self.turn, "orders": orders}
        self.auto_runs[name] = {"period": self.turn}
        return res

    cls.set_auto_trade, cls.remove_auto_trade = set_auto_trade, remove_auto_trade
    cls._auto_quantity, cls.run_auto_trades = _auto_quantity, run_auto_trades

    inner_end = cls.end_turn

    @functools.wraps(inner_end)
    def end_turn(self, name):
        auto = self.run_auto_trades(name) if name in self.nations else {"orders": []}   # 先自动交易，再处理外交未回应项
        ok, msg = inner_end(self, name)
        return ok, msg + (f"；自动交易 {len(auto['orders'])} 单" if auto["orders"] else "")
    cls.end_turn = end_turn


_install_auto_trade(World)

class Nation:
    def __init__(self, name: str, res: dict[str, int] | None = None):
        self.name = name
        # 构造即全键：传部分字典也补齐 START_RES（缺键国家首次结算 add_res 会 KeyError）
        self.res = {**START_RES, **(res or {})}

    def __repr__(self):
        return f"<Nation {self.name}>"
