#include "rollout.hpp"
#include <charconv>
#include <stdexcept>

namespace rl {

const OpponentPool& default_opponents() {
    static const OpponentPool pool{{Opponent::Rule, 0.25},
        {Opponent::W1_25_2, 0.25 + 0.30}, {Opponent::W1_40_3, 0.25 + 0.30 + 0.25},
        {Opponent::W2, 1.0}};
    return pool;
}

OpponentPool parse_opponent_pool(std::string_view specification) {
    OpponentPool pool;
    double total = 0;
    for (;;) {
        const auto comma = specification.find(',');
        const auto entry = specification.substr(0, comma);
        const auto colon = entry.find(':');
        if (colon == std::string_view::npos)
            throw std::invalid_argument("opponents must be specified as name:weight");
        const auto opponent = parse_opponent(entry.substr(0, colon));
        if (!opponent) throw std::invalid_argument("unknown opponent " + std::string(entry.substr(0, colon)));
        if (std::any_of(pool.begin(), pool.end(), [&](const auto& row) { return row.opponent == *opponent; }))
            throw std::invalid_argument("duplicate opponent " + std::string(opponent_name(*opponent)));
        double weight = 0;
        const auto token = entry.substr(colon + 1);
        const char* end = token.data() + token.size();
        const auto [rest, error] = std::from_chars(token.data(), end, weight);
        if (error != std::errc{} || rest != end || !std::isfinite(weight) || weight <= 0 ||
            !std::isfinite(total + weight) || total + weight <= total)
            throw std::invalid_argument("opponent weights must be finite and positive");
        total += weight;
        pool.push_back({*opponent, total});
        if (comma == std::string_view::npos) break;
        specification.remove_prefix(comma + 1);
    }
    return pool;
}

Episode::Episode(uint64_t seed, int size, int max_turns, const OpponentPool& opponents, Scenario scenario)
    : scenario_(scenario) {
    world.seed = seed;
    world.size = size;
    world.max_turns = max_turns;
    world.national_wars = !market4();
    world.setup(market4() ? 4 : 2, {});
    world.begin_turn();
    if (self_play()) {
        for (int i = 0; i < static_cast<int>(world.nations.size()); ++i) {
            auto& p = players_[i];
            p.initial_land = std::count_if(world.tiles.begin(), world.tiles.end(),
                                          [i](const Tile& tile) { return tile.owner == i; });
            p.peak_land = p.initial_land;
        }
        seat = first_player(world.turn);
        return;
    }
    if (opponents.empty()) throw std::invalid_argument("opponent pool is empty");
    PyRandom random;
    random.seed(seed);
    auto a = random.getrandbits(27), b = random.getrandbits(26);
    double draw = (a * 67108864.0 + b) / 9007199254740992.0;
    const double scaled = draw * opponents.back().cumulative_weight;
    auto choice = std::upper_bound(opponents.begin(), opponents.end(), scaled,
        [](double point, const auto& row) { return point < row.cumulative_weight; });
    opponent = choice == opponents.end() ? opponents.back().opponent : choice->opponent;
    uint32_t chosen;
    do { chosen = random.getrandbits(2); } while (chosen >= 2);
    seat = chosen;
    opponents_.fill(opponent);
    if (market4()) {
        seat = static_cast<int>(seed % 4);
        constexpr std::array styles{Opponent::Rule, Opponent::RuleEconomy, Opponent::W3};
        for (int offset = 1; offset < 4; ++offset)
            opponents_[(seat + offset) % 4] = styles[(offset - 1 + seed / 16) % styles.size()];
    }
    for (int i = 0; i < static_cast<int>(world.nations.size()); ++i) {
        auto& p = players_[i];
        p.initial_land = std::count_if(world.tiles.begin(), world.tiles.end(),
                                      [i](const Tile& tile) { return tile.owner == i; });
        p.peak_land = p.initial_land;
    }
    advance(true);
}

int Episode::first_player(int turn) const {
    if (!market4()) return 0;
    return static_cast<int>((world.seed / 4 + turn - 1) % 4);
}

void Episode::advance(bool starting) {
    const int count = static_cast<int>(world.nations.size());
    if (self_play()) {
        seat = (seat + 1) % count;
        if (seat == first_player(world.turn)) {
            settle();
            if (!done) seat = first_player(world.turn);
        }
        return;
    }
    auto play_opponents = [&](bool before) {
        const int first = first_player(world.turn);
        const int position = (seat + count - first) % count;
        for (int i = before ? 0 : position + 1; i < (before ? position : count); ++i) {
            const int actor = (first + i) % count;
            if (!world.alive(actor)) continue;
            opponent_turn(world, actor, opponents_[actor], opponent_state_[actor]);
            world.end_actions(actor);
        }
    };
    if (!starting) {
        play_opponents(false);
        settle();
        if (done) return;
    }
    play_opponents(true);
}

void Episode::settle() {
    world.resolve_turn();
    if (market4()) {
        for (int i = 0; i < static_cast<int>(world.nations.size()); ++i) {
            if (!self_play() && i != seat) continue;
            const auto& nation = world.nations[i];
            auto& p = players_[i];
            p.last_fixed_gdp = nation.fixed_gdp_last;
            p.last_current_gdp = world.alive(i) ? nation.gdp_last : 0.0;
            p.total_fixed_gdp += p.last_fixed_gdp;
            p.total_current_gdp += p.last_current_gdp;
            p.blackout_turns += world.alive(i) && nation.grid_short;
            const int land = std::count_if(world.tiles.begin(), world.tiles.end(),
                                          [i](const Tile& tile) { return tile.owner == i; });
            p.peak_land = std::max(p.peak_land, land);
            if (!p.first_capture && land > p.initial_land) p.first_capture = world.turn;
            if (!p.first_two && land >= p.initial_land + 2) p.first_two = world.turn;
        }
    }
    done = world.turn >= world.max_turns || (!market4() && (!world.alive(seat) || !world.alive(1 - seat)));
    if (!done) world.begin_turn();
}

View Episode::observe() {
    auto& p = players_[seat];
    View view;
    view.choices = candidates(world, seat, true, &p.diplo);
    view.obs = p.observer.encode(world, seat, view.choices);
    view.new_turn = (p.step == 0);
    if (view.new_turn) {
        ++p.turn_index;
        view.summary = turn_features(view.obs, p.hist, p.turn_invalid, p.last_steps);
        view.lost = aggregate_lost(p.previous_sight, p.observer.sight(), world.size);
        p.previous_sight = p.observer.sight();
        p.hist.fill(0);
        p.turn_invalid = 0;
    }
    return view;
}

void Episode::act(const Candidate& candidate) {
    auto& p = players_[seat];
    ++p.decisions;
    ++p.hist[static_cast<int>(candidate.type)];
    if (candidate.type == Type::EndTurn || p.step >= 30) {
        p.last_steps = p.step;
        p.step = 0;
        world.end_actions(seat);
        advance(false);
        return;
    }
    ++p.step;
    ++p.steps;
    if (!apply(world, seat, candidate)) {
        ++p.invalid;
        ++p.turn_invalid;
    } else {
        if (candidate.type == Type::Recruit) {
            ++p.recruits;
            if (!p.first_recruit) p.first_recruit = world.turn;
        }
        if (candidate.type == Type::Attack) {
            ++p.attacks;
            if (!p.first_attack) p.first_attack = world.turn;
        }
    }
}

bool Episode::takeover_action(const Candidate& candidate) {
    auto& p = players_[seat];
    if (p.step >= 30 || candidate.type == Type::EndTurn || !apply(world, seat, candidate))
        return false;
    ++p.step;
    ++p.steps;
    ++p.decisions;
    ++p.hist[static_cast<int>(candidate.type)];
    if (candidate.type == Type::Recruit) {
        ++p.recruits;
        if (!p.first_recruit) p.first_recruit = world.turn;
    }
    if (candidate.type == Type::Attack) {
        ++p.attacks;
        if (!p.first_attack) p.first_attack = world.turn;
    }
    return true;
}

void Episode::suppress_action(const Candidate& candidate) {
    auto& p=players_[seat];
    ++p.decisions;++p.step;++p.steps;
    ++p.hist[static_cast<int>(candidate.type)];
}

int Episode::winner() const {
    if (market4()) return -1;
    if (world.alive(0) == world.alive(1)) return -1;
    return world.alive(0) ? 0 : 1;
}

double Episode::reward() const {
    return reward(seat);
}

double Episode::reward(int index) const {
    if (market4()) return players_.at(index).total_fixed_gdp;
    double own = power_score(world, index);
    double top = std::max(own, power_score(world, 1 - index));
    return own / (top == 0 ? 1 : top);
}

}  // namespace rl
